# 📊 Paid Advertising Suite — Cowork Plugin

A comprehensive paid advertising plugin for Claude Cowork containing **13 specialized skills** and **7 slash commands** for end-to-end campaign management across Google Ads, Meta Ads, and LinkedIn Ads.

---

## 🚀 Quick Start

1. Open **Claude Desktop** → navigate to **Cowork**
2. Click the **Plugins** tab (bottom-left of the Cowork interface)
3. Click **Upload Plugin** and select `paid-advertising-suite.zip`
4. The plugin is now active — try typing `/audit` to start your first campaign audit

---

## 📁 What's Inside

### 13 Skills (Expertise Modules)

| # | Skill | What It Does |
|---|-------|--------------|
| 1 | Ad Performance Diagnostic | Full campaign analysis with benchmarks, root cause diagnosis, and prioritized recommendations |
| 2 | Google Ads Copy Generator | Policy-compliant headlines, descriptions, and extensions with character optimization |
| 3 | Negative Keyword Miner | Extract negatives from search term reports with savings estimates |
| 4 | Meta Ads Creative Brief | Designer-ready briefs with audience insights, visual direction, and format specs |
| 5 | Creative Testing Framework | A/B test matrices with hypotheses, sample sizes, and success criteria |
| 6 | Creative Testing Insights Reporter | Translate test results into actionable design principles |
| 7 | Ad Creative Performance Predictor | Score creative concepts (0-100) before launch |
| 8 | Performance Max Auditor | Google PMax campaign audit for wastage and missed opportunities |
| 9 | Search Terms Analyzer | Identify high-intent winners, wasted spend, and new keyword opportunities |
| 10 | Meta Ads Andromeda Auditor | Deep Meta audit using Andromeda delivery system insights |
| 11 | Meta Ads Audience Builder | Build prospecting, lookalike, and retargeting audiences for Meta |
| 12 | LinkedIn Ads Audience Builder | B2B audience segments with ABM, title stacking, and matched audiences |
| 13 | Competitive Ads Extractor | Extract and analyze competitor ads from ad libraries |

### 7 Slash Commands (Quick Triggers)

| Command | Description |
|---------|-------------|
| `/audit` | Run a full campaign audit (Google, Meta, LinkedIn, or PMax) |
| `/optimize` | Get quick-fire optimization recommendations from campaign data |
| `/creative` | Generate ad copy, creative briefs, test plans, or predict performance |
| `/audience` | Build or refine audiences for Meta or LinkedIn |
| `/spy` | Extract and analyze competitor advertising strategies |
| `/search-terms` | Analyze search term reports and mine negative keywords |
| `/predict` | Score creative concepts before they go live |

---

## 🔗 Optional Connectors (MCPs)

For live data access, connect these optional integrations:

- **Google Ads** — Pull campaign data directly
- **Meta Ads** — Access campaign metrics and Ad Library
- **Google Sheets** — Export reports and audit results

> These are optional. The plugin works fully with uploaded CSV/Excel files.

---

## 📊 Example Workflows

### Campaign Audit
```
/audit → Select "Google Ads" → Upload 30-day CSV → Get full audit report
```

### Competitive Intelligence
```
/spy → Enter competitor "Salesforce" → Get messaging themes, creative patterns, and gaps
```

### Audience Building
```
/audience → Select "LinkedIn" → Describe ICP → Get segmented audiences with overlap management
```

### Creative Pipeline
```
/creative → "Test Plan" → Get A/B matrix → Run test → /creative → "Analyze Results" → Get design principles
```

---

## 📂 Plugin Structure

```
paid-advertising-suite/
├── manifest.json                        # Plugin configuration
├── README.md                            # This file
├── skills/
│   ├── ad-performance-diagnostic/       # Skill + references
│   ├── google-ads-copy-generator/
│   ├── negative-keyword-miner/
│   ├── meta-ads-creative-brief/
│   ├── creative-testing-framework/
│   ├── creative-testing-insights-reporter/
│   ├── ad-creative-performance-predictor/
│   ├── performance-max-auditor/
│   ├── search-terms-analyzer/
│   ├── meta-ads-andromeda-auditor/
│   ├── meta-ads-audience-builder/
│   ├── linkedin-ads-audience-builder/
│   └── competitive-ads-extractor/
├── commands/
│   ├── audit.md
│   ├── optimize.md
│   ├── creative.md
│   ├── audience.md
│   ├── spy.md
│   ├── search-terms.md
│   └── predict.md
└── connectors/
    └── (optional MCP configs)
```

---

## ⚙️ Requirements

- **Subscription**: Claude Pro, Max, Team, or Enterprise
- **Platform**: macOS Desktop App
- **Feature**: Cowork (Research Preview)

---

## 🔄 Skill Interconnections

The skills are designed to work together in chains:

```
/spy (Competitive Intel)
    → /creative (Write Ad Copy or Brief based on gaps)
        → /predict (Score concepts before launch)
            → /creative (Set up A/B test plan)
                → /creative (Analyze test results)

/audit (Campaign Diagnostic)
    → /search-terms (Deep dive into search queries)
        → /optimize (Quick fixes)
            → /audience (Rebuild underperforming audiences)
```

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02 | Initial release with 13 skills, 7 commands |
