# /search-terms — Search Term Analysis & Negative Mining

## Trigger
When the user types `/search-terms`, analyze search query reports and extract negative keywords.

## Workflow

### Step 1: Accept Data
Accept a search terms report as:
- CSV export from Google Ads
- Excel file
- Pasted data table

### Step 2: Dual Analysis
Run two skills in sequence:

**Phase 1: `search-terms-analyzer`**
- Categorize queries by intent (high-intent, research, irrelevant)
- Identify top converting search terms
- Flag wasted spend queries
- Discover new keyword opportunities
- Analyze match type effectiveness

**Phase 2: `negative-keyword-miner`**
- Extract negative keyword candidates from irrelevant queries
- Group negatives by theme/pattern
- Calculate potential savings per negative keyword
- Recommend match type for each negative (exact, phrase, broad)
- Generate campaign-level vs. account-level negative lists

### Step 3: Output → `search-terms-report-{date}.md` + `negative-keywords-{date}.csv`

**Analysis Report**:
- Top 10 high-intent converting terms (scale these)
- Top 10 wasted spend terms (block these)
- New keyword discoveries (test these)
- Match type recommendations
- Estimated monthly savings from negatives

**Negative Keyword List** (CSV):
- Ready to upload directly into Google Ads
- Columns: Keyword, Match Type, Estimated Savings, Reason
