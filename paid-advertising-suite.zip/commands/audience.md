# /audience — Audience Builder

## Trigger
When the user types `/audience`, build or optimize ad audiences.

## Workflow

### Step 1: Select Platform
- **Meta Ads** → `meta-ads-audience-builder`
- **LinkedIn Ads** → `linkedin-ads-audience-builder`

### Step 2: Gather ICP (Ideal Customer Profile)
Ask for:
- Product/service description
- Target job titles, industries, company size
- Geographic targeting
- Existing customer data or CRM segments (if available)
- Campaign objective (prospecting, retargeting, ABM)
- Monthly budget range

### Step 3: Build Audiences

**Meta Ads Output** → `meta-audiences-{date}.md`
- Prospecting audiences (interest + behavior stacks)
- Lookalike audiences (seed recommendations + percentages)
- Retargeting audiences (funnel stage segments)
- Exclusion lists
- Overlap analysis & management plan
- Signal quality optimization recommendations

**LinkedIn Ads Output** → `linkedin-audiences-{date}.md`
- Prospecting segments (title + function + seniority stacks)
- Account-Based Marketing (ABM) segments
- Retargeting segments
- Matched audience recommendations
- Exclusion strategy
- Estimated audience sizes & CPL ranges

### Step 4: Funnel Mapping
Map each audience to the correct funnel stage:
```
TOFU (Awareness) → [Broad prospecting audiences]
MOFU (Consideration) → [Engaged/Lookalike audiences]
BOFU (Conversion) → [Retargeting/ABM audiences]
```
