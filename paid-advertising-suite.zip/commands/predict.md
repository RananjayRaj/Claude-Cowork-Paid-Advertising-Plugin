# /predict — Creative Performance Prediction

## Trigger
When the user types `/predict`, score ad creative concepts before they go live.

## Workflow

### Step 1: Accept Creatives
Accept one or more creative concepts as:
- Image files or mockups
- Ad copy drafts
- Video storyboards or scripts
- Creative brief descriptions

### Step 2: Gather Context
Ask for:
- Platform (Google, Meta, LinkedIn, TikTok)
- Campaign objective
- Target audience description
- Historical campaign data (if available, for calibration)
- Industry/vertical

### Step 3: Execute
Using `ad-creative-performance-predictor`:
1. Score each concept (0-100) against historical patterns
2. Predict CTR, engagement rate, conversion probability ranges
3. Identify strengths and risk factors per concept
4. Rank concepts from strongest to weakest
5. Provide specific improvement recommendations

### Step 4: Output → `creative-predictions-{date}.md`

**For Each Creative Concept**:
- Overall Score (0-100)
- Predicted CTR range
- Predicted engagement range
- Predicted conversion probability
- Top 3 Strengths
- Top 3 Risk Factors
- Specific Improvement Actions

**Comparative Summary**:
- Side-by-side ranking of all concepts
- Recommended launch order
- Test-vs-control pairings for A/B testing
- Budget allocation per concept
