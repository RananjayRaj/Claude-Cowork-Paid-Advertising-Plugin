# /spy — Competitive Ad Intelligence

## Trigger
When the user types `/spy`, extract and analyze competitor advertising strategies.

## Workflow

### Step 1: Identify Targets
Ask for:
- Competitor name(s) or brand(s) (up to 5)
- Platform focus (Facebook Ad Library, LinkedIn, Google)
- Industry/vertical
- Geographic market

### Step 2: Execute
Using `competitive-ads-extractor`:
1. Search ad libraries for active competitor ads
2. Categorize ads by objective (awareness, lead gen, conversion)
3. Extract messaging themes, CTAs, creative formats
4. Identify patterns in offer positioning

### Step 3: Output → `competitive-intel-{competitor}-{date}.md`

**Report Sections**:
- **Ad Volume**: How many active ads, estimated spend indicators
- **Messaging Themes**: Top 3-5 recurring angles/pain points
- **Creative Patterns**: Formats used (video, carousel, static), visual styles
- **CTA Strategy**: What actions they drive (demo, trial, download, purchase)
- **Offer Analysis**: Promotions, lead magnets, pricing strategies
- **Landing Page Insights**: Where ads drive traffic, page structure
- **Gaps & Opportunities**: What they're NOT doing that you could exploit
- **Swipe File**: Best-performing ad examples with annotations

### Step 4: Strategic Recommendations
- Counter-positioning opportunities
- Creative formats to test against competitors
- Messaging angles competitors have overlooked
- Budget allocation suggestions based on competitive intensity
