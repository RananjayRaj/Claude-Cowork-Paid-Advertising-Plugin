# /optimize — Quick Optimization Pass

## Trigger
When the user types `/optimize`, provide rapid-fire optimization recommendations.

## Workflow

### Step 1: Accept Input
Accept one of:
- A CSV/Excel file with campaign data
- A screenshot of campaign metrics
- Pasted metrics (CTR, CPC, CPA, ROAS, etc.)

### Step 2: Quick Diagnosis
Using the `ad-performance-diagnostic` skill:
1. Identify the 3 highest-impact issues in under 60 seconds
2. Skip deep analysis — focus on actionable fixes

### Step 3: Output Format
Deliver a concise optimization plan:

```
## ⚡ Quick Optimization Report

### 🔴 Critical Issues
1. [Issue] → [Specific Fix] → [Expected Impact]
2. [Issue] → [Specific Fix] → [Expected Impact]
3. [Issue] → [Specific Fix] → [Expected Impact]

### 🟡 Watch List
- [Metric trending in wrong direction]
- [Emerging opportunity]

### ✅ What's Working
- [Top performing element to scale]

### 💰 Budget Move
- Shift $X from [Campaign A] → [Campaign B]
- Expected improvement: +X% ROAS
```

Save as `quick-optimize-{date}.md` in workspace.

## Skill Dependencies
- `ad-performance-diagnostic` (primary)
- `search-terms-analyzer` (if search data provided)
