# /creative — Ad Creative Workflow

## Trigger
When the user types `/creative`, initiate creative generation or testing workflows.

## Workflow

### Step 1: Select Mode
Ask the user which creative workflow they need:

1. **Write Ad Copy** → Google Ads headlines, descriptions, extensions
2. **Creative Brief** → Meta Ads creative brief for designers
3. **Test Plan** → A/B test matrix with hypothesis and metrics
4. **Analyze Results** → Interpret test data into design principles
5. **Predict Performance** → Score creative concepts before launch

### Step 2: Route to Skill

| Mode | Skill |
|------|-------|
| Write Ad Copy | `google-ads-copy-generator` |
| Creative Brief | `meta-ads-creative-brief` |
| Test Plan | `creative-testing-framework` |
| Analyze Results | `creative-testing-insights-reporter` |
| Predict Performance | `ad-creative-performance-predictor` |

### Step 3: Gather Requirements
Based on the mode, collect:

**Ad Copy**: Keywords, landing page URL, unique selling points, character limits
**Creative Brief**: Campaign objective, target audience, brand guidelines, formats needed
**Test Plan**: What to test, current creative, success metrics, budget for testing
**Analyze Results**: Test data (CSV or pasted), variant descriptions
**Predict Performance**: Creative concepts/mockups, platform, historical campaign data

### Step 4: Execute & Output

**Ad Copy Output** → `ad-copy-{campaign}-{date}.md`
- 15 headline variations (30 char)
- 4 description variations (90 char)
- Extension recommendations
- Policy compliance checklist

**Creative Brief Output** → `creative-brief-{campaign}-{date}.md`
- Audience profile
- Visual direction
- Copy direction
- Format specifications
- Do's and Don'ts

**Test Plan Output** → `test-plan-{date}.md`
- Test matrix (variants × metrics)
- Hypothesis per variant
- Sample size requirements
- Duration estimate
- Success criteria

**Results Analysis Output** → `test-insights-{date}.md`
- Winning patterns
- Design principles extracted
- Statistical significance
- Updated creative guidelines

**Prediction Output** → `creative-score-{date}.md`
- Score per creative concept (0-100)
- Predicted CTR, engagement, conversion ranges
- Risk factors
- Improvement recommendations
