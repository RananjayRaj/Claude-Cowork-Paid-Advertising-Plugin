# /audit — Full Campaign Audit

## Trigger
When the user types `/audit`, initiate a comprehensive paid advertising audit.

## Workflow

### Step 1: Gather Context
Ask the user:
1. **Platform**: Google Ads, Meta Ads, LinkedIn Ads, or Performance Max?
2. **Data Source**: Upload a CSV export, share a screenshot, or paste metrics?
3. **Time Period**: Last 7, 30, or 90 days?
4. **Campaign Objective**: Awareness, traffic, leads, conversions, or ROAS?

### Step 2: Route to Correct Skill(s)
Based on the platform selected:

| Platform | Primary Skill | Supporting Skills |
|----------|--------------|-------------------|
| Google Ads | `ad-performance-diagnostic` | `search-terms-analyzer`, `negative-keyword-miner` |
| Meta Ads | `meta-ads-andromeda-auditor` | `meta-ads-audience-builder`, `ad-performance-diagnostic` |
| LinkedIn Ads | `ad-performance-diagnostic` | `linkedin-ads-audience-builder` |
| Performance Max | `performance-max-auditor` | `ad-performance-diagnostic` |

### Step 3: Execute the Audit
1. Run the primary diagnostic skill against the provided data
2. Compare metrics against platform benchmarks from reference files
3. Identify top 5 issues ranked by impact
4. Generate specific, actionable recommendations

### Step 4: Output
Generate a structured audit report saved to the workspace:

**File**: `audit-report-{platform}-{date}.md` (or `.xlsx` if data is tabular)

**Report Sections**:
- Executive Summary (3-5 bullet points)
- Performance Scorecard (metrics vs. benchmarks)
- Issue Diagnosis (ranked by impact)
- Recommendations (quick wins → core optimizations → advanced tactics)
- Budget Reallocation Suggestions (if multi-campaign)
- Next Steps & Testing Plan

## Example Usage
```
/audit
> Platform: Google Ads
> [User uploads campaign CSV]
> Period: Last 30 days
> Objective: Lead generation
```
