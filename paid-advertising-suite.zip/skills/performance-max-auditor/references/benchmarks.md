# Performance Max Benchmarks & Standards

Industry benchmarks, performance standards, and diagnostic thresholds for Performance Max campaign auditing.

## Conversion Rate Benchmarks by Industry

### eCommerce
- **Fashion/Apparel**: 1.5-2.5% (excellent: 3.5%+)
- **Electronics**: 1-2% (excellent: 3%+)
- **Home & Garden**: 2-3% (excellent: 4%+)
- **Beauty/Cosmetics**: 2.5-4% (excellent: 5%+)
- **Food & Beverage**: 1-2% (excellent: 2.5%+)

### B2B Lead Generation
- **SaaS (Low-ticket <$100/mo)**: 4-6% (excellent: 8%+)
- **SaaS (Mid-ticket $100-500/mo)**: 2-4% (excellent: 6%+)
- **Professional Services**: 3-5% (excellent: 7%+)
- **Enterprise Software**: 1-3% (excellent: 4%+)
- **Manufacturing**: 2-4% (excellent: 5%+)

### Other Verticals
- **Travel & Hospitality**: 1-3% (excellent: 4%+)
- **Education**: 3-5% (excellent: 7%+)
- **Healthcare**: 2-4% (excellent: 6%+)
- **Financial Services**: 2-5% (excellent: 7%+)
- **Real Estate**: 2-4% (excellent: 6%+)

## ROAS Benchmarks by Business Model

### eCommerce
- **High-margin (>50%)**: 4-6x target, 8x+ excellent
- **Medium-margin (30-50%)**: 3-4x target, 6x+ excellent
- **Low-margin (<30%)**: 2-3x target, 4x+ excellent
- **Dropshipping**: 3-5x target, 7x+ excellent

### Lead Generation
- Calculate target ROAS based on:
- Lead value × close rate × customer LTV = Revenue per lead
- Target ROAS = Revenue per lead / Target CPA
- B2B typical: 3-8x depending on lead quality and sales cycle

## Cost Per Acquisition Benchmarks

### Consumer Products
- **Beauty**: $15-35
- **Apparel**: $10-25
- **Electronics**: $20-50
- **Furniture**: $30-75
- **Supplements**: $25-60

### Services
- **Legal Services**: $100-500
- **Home Services**: $50-150
- **Financial Advisory**: $75-300
- **Fitness/Wellness**: $30-80
- **Online Education**: $25-75

## Asset Group Performance Standards

**Distribution Thresholds:**
- Healthy: Top asset group <60% spend, bottom >5% spend
- Warning: Top asset group 60-80% spend
- Critical: Top asset group >80% spend or bottom <2% spend

**Asset Strength Distribution:**
- Excellent: 80%+ groups rated "Good" or "Excellent"
- Good: 60-80% groups rated "Good" or "Excellent"
- Fair: 40-60% groups rated "Good" or "Excellent"
- Poor: <40% groups rated "Good" or "Excellent"

**Creative Performance Indicators:**
- CTR decline threshold: >20% drop over 30 days = fatigue
- Asset refresh cadence: Every 30-45 days recommended
- Minimum assets per group: 15 headlines, 4 descriptions, 10 images, 2+ videos

## Audience Signal Benchmarks

**Customer List Standards:**
- Minimum size: 1,000 matched users
- Ideal size: 10,000+ matched users
- Match rate: >60% excellent, 40-60% good, <40% poor
- Recency: 30-90 day customer window optimal

**Signal Mix Recommendations:**
- Warm audiences: 40-60% of signal weight
- Interest/demographic: 30-50% of signal weight
- Expansion/lookalike: 10-20% of signal weight

**Performance Expectations:**
- Warm audience ROAS: 1.5-2.5x vs cold
- Customer list ROAS: 2-4x vs cold
- Video engagers: 1.3-1.8x vs cold

## Budget & Bid Strategy Benchmarks

**Minimum Budget Guidelines:**
- Target CPA campaigns: 10x target CPA per day
- Target ROAS campaigns: $100/day minimum, $500/day preferred
- Learning phase: Budget for 50+ conversions in 14 days
- Stable optimization: Budget for 100+ conversions per week

**Impression Share Standards:**
- Excellent: 70%+ search impression share
- Good: 50-70% search impression share
- Fair: 30-50% search impression share
- Poor: <30% search impression share

**Budget Status Frequency:**
- Healthy: "Limited by budget" <2 days per week
- Concerning: "Limited by budget" 3-5 days per week
- Critical: "Limited by budget" 6-7 days per week

## Search Term Quality Benchmarks

**Relevance Distribution (Ideal):**
- High relevance queries: >60% of spend
- Medium relevance: 20-30% of spend
- Low relevance: <10% of spend (5% or less excellent)

**Negative Keyword Coverage:**
- Starter: 25-50 negatives
- Good: 50-100 negatives
- Excellent: 100-200+ negatives
- Industry leader: 200-500+ with regular updates

**Query Intent Mix:**
- Branded searches: 10-30% (varies by brand awareness)
- High-intent commercial: 40-60%
- Informational: <20% (lower is better)
- Navigational: <10%

## Landing Page Performance Standards

**Load Time Benchmarks:**
- Excellent: <2 seconds
- Good: 2-3 seconds
- Fair: 3-4 seconds
- Poor: 4-5 seconds
- Critical: >5 seconds (40%+ abandonment)

**Mobile vs Desktop Performance:**
- Excellent: Mobile CVR >80% of desktop
- Good: Mobile CVR 60-80% of desktop
- Fair: Mobile CVR 40-60% of desktop
- Poor: Mobile CVR <40% of desktop

**Page Engagement Metrics:**
- Bounce rate (good): <40% for eCommerce, <50% for B2B
- Time on page (good): >90 seconds eCommerce, >120s B2B
- Scroll depth (good): >75% reach below fold

## Diagnostic Thresholds

### When to Flag Issues

**Conversion Tracking:**
- Tag firing rate <95%: Investigate tracking
- Enhanced conversion match <60%: Improve data quality
- Value variance (high/low) <2x: Review value assignment
- Offline import delay >7 days: Accelerate import cadence

**Asset Performance:**
- Asset strength decline >1 level in 30 days: Creative refresh needed
- CTR decline >20% with stable impressions: Fatigue detected
- Same combinations >80% of impressions: Diversity issue
- Asset group ROAS variance >5x: Investigate/consolidate

**Audience Signals:**
- No signals added: Critical priority to add
- Customer list match <40%: Data quality issue
- Single signal type >90% weight: Diversification needed
- Expansion ratio >50%: Signal strength insufficient

**Bidding & Budget:**
- Learning phase >30 days: Volume or stability issue
- Daily spend variance >30%: Bid strategy problem
- Limited by budget >5 days/week: Scale opportunity
- IS lost (rank) >50%: Quality/relevance issue

**Search Terms:**
- Irrelevant spend >15%: Negative keyword opportunity
- Competitor terms >5% spend: Wastage issue
- Job/career searches >2%: Add negatives
- Zero-conversion queries >10% spend: Relevance problem

**Landing Pages:**
- Page CVR <50% of avg with >10% traffic: Critical fix
- Load time >5 seconds: Technical optimization
- Mobile CVR <40% desktop: Mobile UX issue
- Form abandonment >60%: Friction problem

## Performance Trending Analysis

**Healthy Trends (Month-over-Month):**
- ROAS: Stable (±10%) or improving
- Conversion volume: Growing with maintained efficiency
- CPA: Declining or stable
- CTR: Stable or improving
- Impression share: Growing

**Warning Trends:**
- ROAS: Declining 10-20%
- CPA: Rising 15-25%
- CTR: Declining 10-20%
- Conversion rate: Declining 15-25%
- Impression share: Declining

**Critical Trends:**
- ROAS: Declining >20%
- CPA: Rising >25%
- CTR: Declining >20%
- Conversion rate: Declining >25%
- Impression share: Declining >20 percentage points

## Competitive Benchmarking

### Share of Voice Indicators
- Category leader: >40% SOV
- Strong player: 20-40% SOV
- Challenger: 10-20% SOV
- Niche player: <10% SOV

### Growth Stage Expectations
**Startup/Launch Phase (0-6 months):**
- Focus: Learning and signal building
- ROAS target: 2-3x (may operate at lower margin)
- Conversion volume: Building to 100+/week
- Optimization: Asset testing, audience discovery

**Growth Phase (6-18 months):**
- Focus: Scaling with maintained efficiency
- ROAS target: 3-5x (profitable)
- Conversion volume: 200-500+/week
- Optimization: Refinement, expansion, testing

**Mature Phase (18+ months):**
- Focus: Efficiency and market share
- ROAS target: 4-8x (highly optimized)
- Conversion volume: 500+/week
- Optimization: Incremental gains, competitive defense

## Seasonal Adjustment Factors

**Retail/eCommerce:**
- Q4 (Nov-Dec): 1.5-3x normal volume
- Back to School (Aug-Sep): 1.3-1.8x
- Summer (Jun-Aug): 0.7-0.9x
- Post-holiday (Jan-Feb): 0.6-0.8x

**B2B:**
- Q4: 0.8-0.9x (budget depletion or freeze)
- Q1: 1.1-1.3x (new budgets)
- Summer (Jul-Aug): 0.7-0.8x (vacations)
- Sep-Oct: 1.1-1.2x (year-end push)

**Adjust benchmarks by these factors when auditing campaigns during seasonal periods.**

---

**Use these benchmarks as diagnostic baselines. Actual performance varies by business model, market maturity, competitive intensity, and brand strength.**
