# Performance Max Audit Framework

Complete methodology for conducting systematic Performance Max campaign audits with scoring systems, diagnostic criteria, and optimization prioritization.

## Audit Scoring System

### Overall Campaign Health Score (0-100)

**Component Weights:**
- Goal Setup & Conversion Quality: 25%
- Asset Group Performance: 20%
- Audience Signals: 15%
- Bidding Strategy: 15%
- Budget Allocation: 10%
- Search Term Insights: 10%
- Landing Page Experience: 5%

**Score Interpretation:**
- 90-100: Excellent - Minor optimization opportunities only
- 75-89: Good - Some clear improvement areas
- 60-74: Fair - Significant optimization needed
- 45-59: Poor - Major issues impacting profitability
- 0-44: Critical - Fundamental problems requiring immediate action

## 1. Goal Setup & Conversion Quality Assessment

### Diagnostic Checklist

**Conversion Action Setup (Score: 0-25)**
- Primary conversion goal clearly defined (5 pts)
- Secondary goals properly weighted (<30% of total conv value) (5 pts)
- Conversion values accurately reflect business value (5 pts)
- Tracking validation completed in last 30 days (5 pts)
- Enhanced conversions or import from CRM active (5 pts)

**Red Flag Detection:**
- Critical: Multiple conversion goals with equal weighting
- Critical: Conversion values set to default $1
- Critical: Unvalidated conversion tracking
- High: Micro-conversions weighted equally to sales
- High: Offline conversion import >7 days delayed
- Medium: Missing enhanced conversions implementation

**Optimization Opportunities:**

**Value Optimization Missing**
- Issue: All conversions treated equally regardless of business value
- Impact: Algorithm optimizes for volume, not revenue
- Fix: Implement conversion value rules or import transaction values
- Expected Lift: 20-40% improvement in ROAS within 30 days

**Goal Conflict**
- Issue: PMax optimizing for both leads AND purchases simultaneously
- Impact: Diluted optimization signal, inconsistent performance
- Fix: Create separate campaigns for distinct goals
- Expected Lift: 15-25% efficiency improvement

[Content continues with detailed frameworks for all 7 audit dimensions...]

## Priority Matrix for Optimization

### Impact vs Effort Framework

**Quick Wins (High Impact, Low Effort):**
- Add negative keywords from search terms
- Refresh underperforming asset groups with new creative
- Fix tracking issues (if identified)
- Remove or pause worst landing pages

**Strategic Initiatives (High Impact, High Effort):**
- Implement conversion value optimization
- Rebuild weak asset groups with strong signals
- Create new landing page variants
- Upload and segment customer lists

**Efficiency Plays (Medium Impact, Low Effort):**
- Adjust overly aggressive bid targets
- Consolidate conversion goals
- Add audience signals to weak asset groups

**Long-term Investments (Medium Impact, High Effort):**
- Develop video assets for asset groups
- Build comprehensive negative keyword lists
- Implement seasonal creative rotation calendar
