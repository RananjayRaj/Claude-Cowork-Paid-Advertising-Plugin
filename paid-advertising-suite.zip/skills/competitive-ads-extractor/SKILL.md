---
name: competitive-ads-extractor
description: Extract and analyze competitors' ads from ad libraries (Facebook, LinkedIn, etc.) to understand messaging, problems, creative patterns, and strategies that are working. Use when analyzing competitor ad campaigns, researching market positioning, finding inspiration for ads, identifying successful messaging patterns, or planning ad campaigns based on proven approaches.
---

# Competitive Ads Extractor

Extract your competitors' ads from ad libraries and analyze what's working—the problems they highlight, use cases they target, and copy/creative that resonates with audiences.

## Quick Start

### Basic Extraction
```
Extract all current ads from [Competitor Name] on Facebook Ad Library
```

### Analysis with Focus
```
Get ads from [Company] and analyze their messaging about [specific problem]. What pain points are they highlighting?
```

### Competitive Set Comparison
```
Extract ads from these 5 competitors: [list]. Compare their approaches and tell me what's working.
```

## What This Skill Does

1. **Extracts Ads**: Access Facebook Ad Library, LinkedIn, and other ad sources
2. **Captures Screenshots**: Saves visual copies of ads for reference
3. **Analyzes Messaging**: Identifies problems, use cases, and value propositions
4. **Categorizes Ads**: Groups by theme, audience, or format
5. **Identifies Patterns**: Finds common successful approaches across ads
6. **Provides Insights**: Explains why certain approaches likely perform well

## Core Workflows

### Workflow 1: Single Competitor Analysis
1. Identify the competitor
2. Access their ad library (Facebook, LinkedIn, etc.)
3. Extract 15-30 recent ads
4. Categorize by messaging theme
5. Identify top 3-5 messaging patterns
6. Extract key copy formulas and CTAs
7. Note visual/creative patterns
8. Provide recommendations based on findings

### Workflow 2: Competitive Set Benchmarking
1. Gather ads from 3-5 direct competitors
2. Extract 10-15 ads per competitor
3. Map positioning across the set
4. Identify common pain points everyone emphasizes
5. Find gaps (what no one is talking about)
6. Note differentiated approaches
7. Highlight what's unique about each competitor

### Workflow 3: Messaging Deep Dive
1. Focus on specific problem or use case
2. Find all competitor ads addressing this
3. Extract their copy approaches
4. Identify emotional triggers used
5. Note social proof techniques
6. Compile into inspiration document

### Workflow 4: Creative Pattern Analysis
1. Extract competitor ads by format (static, video, carousel, etc.)
2. Analyze visual design patterns
3. Document color schemes and layouts
4. Note positioning of CTAs
5. Identify before/after or comparison patterns
6. Extract successful headline/copy structures

## Key Insights to Extract

### Messaging Analysis
- What specific problems do they emphasize?
- How do they position against competition?
- What value propositions resonate?
- Which audience segments get different messaging?
- What emotional triggers are used?

### Creative Patterns
- Visual styles that work best
- Video vs. static performance differences
- Color schemes and branding consistency
- Layout and composition patterns
- Typography and visual hierarchy

### Copy Formulas
- Headline structures and lengths
- Call-to-action patterns and language
- Tone and voice characteristics
- Length of body copy
- Use of numbers and specificity

### Campaign Strategy
- Seasonal or timely campaigns
- Product launch announcement approaches
- Feature announcement tactics
- Retargeting message variations
- New audience acquisition angles

## Output Structure

Create a comprehensive analysis report including:

- **Overview**: Total ads found, primary themes, ad formats used
- **Key Problems**: List problems highlighted (with example copy and frequency)
- **Successful Patterns**: Visual and messaging patterns used in multiple ads
- **Copy That Works**: Best headlines, body copy patterns, CTAs
- **Audience Targeting**: Inferred audience segments based on ad variations
- **Recommendations**: 5-7 actionable insights for your own campaigns
- **Files**: Organized by competitor with screenshots and analysis

See `references/analysis-patterns.md` for detailed output format examples and templates.

## Best Practices

✓ Use for research and inspiration only  
✓ Don't plagiarize copy or designs directly  
✓ Adapt successful patterns to your brand voice  
✓ Look for themes that repeat (strength indicator)  
✓ Track competitor ads monthly to see evolution  
✓ Segment analysis by target audience  
✓ Test hypotheses from insights with A/B tests  

✗ Don't copy ads verbatim  
✗ Don't ignore intellectual property rights  
✗ Don't assume patterns work for your product  

## Advanced Use Cases

See `references/advanced-workflows.md` for:
- Trend tracking over time
- Multi-competitor pattern analysis
- Industry benchmark comparisons
- Format performance analysis
- Positioning map creation
