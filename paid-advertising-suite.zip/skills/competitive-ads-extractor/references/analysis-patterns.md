# Analysis Patterns & Output Templates

## Standard Analysis Report Structure

### 1. Overview Section
```
# [Competitor Name] Ad Analysis

## Overview
- **Total Active Ads**: [number]
- **Analysis Period**: [dates]
- **Primary Themes**: [theme 1] (X%), [theme 2] (X%), [theme 3] (X%)
- **Ad Formats Used**: Static Images (X%), Video (X%), Carousel (X%)
- **Primary Platforms**: Facebook, LinkedIn, Instagram
```

### 2. Key Problems Section
```
## Key Problems Highlighted

### Problem 1: [Problem Title]
- **Frequency**: [X ads]
- **Example Copy**: "[Quote from ad]"
- **Why It Works**: [Analysis of why this resonates]
- **Emotional Trigger**: [Primary emotion: frustration, fear, aspiration]
- **Target Audience Signal**: [Who this appeals to]

### Problem 2: [Problem Title]
[Same structure as above]
```

### 3. Successful Patterns Section
```
## Successful Creative Patterns

### Pattern: Before/After Split
- **Description**: Visual shows problem state → solution state
- **Frequency**: Used in 6 ads
- **Effectiveness**: High (clear visual contrast)
- **Example**: Chaotic workspace → organized Notion dashboard

### Pattern: Feature GIF Showcase
- **Description**: Quick 3-5 second product feature demonstration
- **Frequency**: Used in 4 ads
- **Effectiveness**: High (shows product in action)
- **Best For**: Feature announcements, new capabilities

### Pattern: Social Proof/Numbers
- **Description**: Customer count, growth metrics, trust signals
- **Frequency**: Used in 3 ads
- **Effectiveness**: Medium-High
- **Example**: "Join 20M+ users"
```

### 4. Copy That's Working Section
```
## Copy Formulas That Work

### Headlines
1. "[Benefit-focused headline]"
   - **Type**: Outcome-focused
   - **Length**: [X words]
   - **Why It Works**: Direct benefit statement
   
2. "[Problem-first headline]"
   - **Type**: Problem-focused
   - **Length**: [X words]
   - **Why It Works**: Speaks to pain point directly

### Body Copy Patterns
- **Sentence Length**: Mostly 5-10 words
- **Structure**: Problem → Solution → CTA
- **Tone**: [Tone descriptor]
- **Use of Numbers**: Specific metrics (e.g., "Cut time by 50%")
- **Power Words**: [List of common words used]

### Call-to-Action Analysis
| CTA Button Text | Frequency | Performance Signal |
|---|---|---|
| "Try for free" | 8 ads | High CTR |
| "Get started" | 6 ads | High CTR |
| "Learn more" | 4 ads | Medium |
| "See demo" | 3 ads | High CTR |
```

### 5. Audience Targeting Insights Section
```
## Audience Segmentation

### Segment: [Audience Type]
- **Ad Variations**: [X different versions]
- **Problem Focus**: [What problems resonate]
- **Copy Tone**: [Formal/Casual/Technical]
- **Visual Style**: [Description]
- **Example Ad**: [Specific ad details]

### Segment: [Audience Type]
[Same structure above]
```

### 6. Comparative Insights Section (for multiple competitors)
```
## Competitive Set Comparison

### Common Themes Across All Competitors
- **Shared Pain Point**: All emphasize [problem]
- **Positioning Gap**: No one mentions [potential opportunity]
- **Common Approach**: Most use [pattern]

### Differentiated Approaches
| Competitor | Unique Angle | Frequency |
|---|---|---|
| Company A | [Unique message] | X ads |
| Company B | [Unique message] | X ads |

### Market Positioning Map
- **Company A**: Emphasizes [axis 1], [axis 2]
- **Company B**: Emphasizes [axis 1], [axis 2]
- **Gap/Opportunity**: [Unserved positioning]
```

### 7. Recommendations Section
```
## Actionable Recommendations

1. **Test the [Problem Type] Angle**
   - **Why**: Competitor uses in X ads (frequent signals effectiveness)
   - **Your Angle**: How you could differentiate
   - **Test Approach**: A/B test against current messaging

2. **Adopt [Pattern Name] Visual Format**
   - **Why**: High frequency + clear effectiveness
   - **How**: [Specific implementation]
   - **Caution**: Adapt to your brand, don't copy directly

3. **Experiment with Shorter Copy**
   - **Why**: Their highest-frequency ads use < 100 characters
   - **Current State**: Your ads average X characters
   - **Test**: Try reducing by 20%

4. **Segment Messaging by Audience**
   - **Observation**: Competitor uses different messages for [segments]
   - **Opportunity**: You could test separate ads for [your segments]

5. **Add Social Proof**
   - **Observation**: Most ads include [type of proof]
   - **Your Opportunity**: Highlight [relevant proof point]
```

## Analysis Depth Levels

### Level 1: Quick Overview (for rapid assessment)
- Ad count and themes
- 3-5 top messaging patterns
- Key recommendations
- **Time to complete**: 15-30 minutes

### Level 2: Standard Analysis (most common)
- Complete overview + problem analysis
- Creative patterns + copy formulas
- Audience insights
- 5-7 recommendations
- **Time to complete**: 1-2 hours

### Level 3: Deep Competitive Intelligence (comprehensive)
- All Level 2 content
- Comparative analysis across multiple competitors
- Positioning mapping
- Trend analysis (if data available)
- Detailed audience segmentation
- **Time to complete**: 3-4 hours

## Data Organization

### Spreadsheet Format
```
| Ad ID | Screenshot | Company | Theme | Problem | Audience | Copy | CTA | Format | Estimated Performance |
|---|---|---|---|---|---|---|---|---|---|
| AD-001 | [link] | Company | Productivity | Tool sprawl | Teams | "Stop switching..." | Try free | Static | High |
| AD-002 | [link] | Company | Collaboration | Async work | Managers | "Replace meetings..." | Get started | Video | High |
```

### File Organization Structure
```
competitor-analysis/
├── company-name/
│   ├── screenshots/
│   │   ├── ad-001-problem-focus.png
│   │   ├── ad-002-feature-demo.png
│   │   └── ...
│   ├── analysis.md
│   └── ads-data.csv
├── competitive-set/
│   ├── positioning-map.md
│   ├── common-themes.md
│   └── comparison-table.csv
└── insights-by-theme/
    ├── messaging-patterns.md
    ├── creative-patterns.md
    └── copy-formulas.md
```

## Quality Indicators

### Strong Signals of Effectiveness
- ✓ Ad appears in multiple variations (platform is testing it)
- ✓ Similar message used across different audience segments
- ✓ Specific numbers/metrics included
- ✓ Visual metaphor that's easy to understand
- ✓ Short, punchy copy
- ✓ Clear problem statement

### Weak Signals (be cautious)
- ✗ Ad appears only once or twice
- ✗ Vague or abstract messaging
- ✗ No clear CTA
- ✗ Generic value proposition
- ✗ Long paragraphs of copy
