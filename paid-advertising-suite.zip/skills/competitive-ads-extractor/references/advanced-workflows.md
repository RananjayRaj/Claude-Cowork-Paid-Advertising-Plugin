# Advanced Workflows

## Workflow 1: Trend Tracking Over Time

Track how competitor messaging evolves by collecting ads at regular intervals.

### Setup
1. Create baseline snapshot (collect all current ads from competitor)
2. Set monthly check-in schedule (same date each month)
3. Track in spreadsheet with date column
4. Compare messaging shifts quarter-over-quarter

### Analysis Focus
- **New problems introduced**: What pain points are they suddenly emphasizing?
- **Messaging removed**: What stopped resonating or became outdated?
- **Feature focus evolution**: How does feature emphasis change?
- **Seasonal patterns**: Do messaging themes change by season?
- **Response to market**: Are they reacting to competitive or market changes?

### Example Insight
```
Q1: Focused on "tool sprawl" problem (6 ads)
Q2: Still emphasizing tool sprawl (5 ads) but added "AI-powered" angle (3 new ads)
Q3: Dramatically increased AI messaging (7 ads), tool sprawl down to 2 ads
Interpretation: Market shifted focus to AI; they're following the trend
```

### Deliverable
- Timeline document showing messaging evolution
- Month-over-month comparison table
- Hypothesis about market/competitive drivers
- Projection of next likely messaging shift

## Workflow 2: Multi-Competitor Pattern Analysis

Analyze 5+ competitors simultaneously to find industry-wide patterns.

### Step-by-Step Process

**Phase 1: Data Collection (Day 1)**
1. Identify 5-7 direct competitors
2. Extract 10-15 ads from each
3. Create master spreadsheet with all ads
4. Screenshot and save all visuals

**Phase 2: Individual Analysis (Days 2-3)**
1. Analyze each competitor individually
2. Identify their top 3-4 themes
3. Extract their top messaging patterns
4. Note their unique differentiators

**Phase 3: Comparative Analysis (Day 4)**
1. Create master theme list (combine all)
2. Count frequency across competitors
3. Identify commonalities (signals market consensus)
4. Identify gaps (what no one emphasizes)
5. Map positioning differences

**Phase 4: Synthesis (Day 5)**
1. Create competitive positioning map
2. Identify market opportunities (gaps)
3. Highlight winner's positioning
4. Create strategic recommendations

### Positioning Map Example
```
                    Horizontal Axis: Enterprise ←→ SMB
                    Vertical Axis: Feature-Rich ←→ Simple/Easy
                    
Competitor A: Enterprise focus, feature-rich (emphasizes "all-in-one")
Competitor B: SMB focus, simple (emphasizes "easy to use")
Competitor C: Enterprise focus, simple (gap opportunity!)
Competitor D: SMB focus, feature-rich (positioning conflict)

Opportunity: Enterprise customers wanting simplicity
```

### Output Structure
1. Competitive landscape map
2. Theme frequency analysis (what matters most)
3. Positioning matrix (how competitors differentiate)
4. Gap analysis (underserved positions)
5. Recommendations (where to position your company)

### Key Questions to Answer
- What problem is EVERYONE emphasizing?
- What problem is NO ONE mentioning?
- Which competitor has the most differentiated position?
- What audience segments are underserved?
- What's the emerging trend (what are leaders emphasizing)?

## Workflow 3: Industry Benchmark Analysis

Compare your own ads against industry norms.

### Preparation
1. Extract your recent ads (10-15)
2. Extract competitor ads (10-15 each from 3-5 competitors)
3. Create comparative analysis

### Analysis Dimensions

**Messaging Comparison**
- Do you emphasize the same problems?
- Where do you differentiate?
- Are you addressing underserved angles?

**Creative Comparison**
- Video vs. static formats (who uses what % split?)
- Color palette trends
- Imagery style (lifestyle vs. product vs. abstract)
- Headline/copy length norms

**Copy Tone Comparison**
- Formal vs. casual (industry norm?)
- Emotional vs. rational
- Feature-focused vs. benefit-focused
- Your tone vs. competitors

**CTA Strategy Comparison**
- Most common CTAs in industry
- Your CTA vs. norms
- CTA button text trends

### Benchmark Report Structure
```
# Industry Benchmarks vs. Your Ads

## Messaging Analysis
- Industry average focuses on: [themes]
- You focus on: [themes]
- Gap analysis: [where you differ]
- Recommendation: [strengthen/differentiate]

## Creative Analysis
- Video adoption: [X]% of ads
- Your video usage: [X]%
- Recommendation: [increase/maintain]

## Copy Performance Signals
- Average headline length: [X] words
- Your headlines: [X] words
- Industry standard CTA: "[CTA]"
- Your CTA: "[CTA]"
- Recommendation: [align/differentiate]

## Strength Areas (you vs. competition)
- [Area where you excel]
- [Area where you're differentiated]

## Opportunity Areas
- [Where competitors are beating you]
- [Where you could add messaging]
```

## Workflow 4: Format-Specific Deep Dive

Analyze specific ad formats separately for deeper insights.

### Video Ad Analysis
1. Extract all video ads (from competitor or set)
2. Note video length (typically 6-15 seconds)
3. Analyze hook (first 2 seconds)
4. Identify story structure:
   - Problem intro (2-3 sec)
   - Solution demo (3-5 sec)
   - CTA (1-2 sec)
5. Extract copy that accompanies video
6. Note captions/text overlays

### Carousel Ad Analysis
1. Extract carousel ads
2. Count average card count (typically 3-5)
3. Analyze card progression (story flow)
4. Note copy on each card
5. Identify CTA placement
6. Extract targeting signals from card sequence

### Static Image Analysis
1. Extract static ads
2. Analyze visual hierarchy
3. Note copy-to-image ratio
4. Identify design patterns
5. Extract headline positioning
6. Note CTA button treatment

### Performance Signals by Format
```
Format: Video Ads
- Typically used for: Product demos, storytelling
- Engagement signal: Usually multiple variations = testing
- Best for: Feature announcements, complex value props

Format: Static Image
- Typically used for: Quick messaging, brand awareness
- Engagement signal: Longevity (same ad appears in multiple checks)
- Best for: Simple, clear messaging, problem focus

Format: Carousel
- Typically used for: Step-by-step processes, multiple features
- Engagement signal: Indicates multi-angle messaging strategy
- Best for: Complex products, multiple use cases
```

## Workflow 5: Audience Segmentation Deep Dive

Understand how competitors message differently to different audiences.

### Identify Audience Segments
1. Look for multiple ad variations with same brand
2. Note messaging differences
3. Infer target audience from messaging
4. Categorize variations

### Common Segments
- **Role-based**: Manager vs. Individual Contributor vs. C-suite
- **Company-size based**: Enterprise vs. Mid-market vs. SMB
- **Use-case based**: Sales vs. Marketing vs. Product
- **Stage-based**: New user vs. Existing customer vs. Competitor's customer
- **Pain-point based**: Team collaboration vs. Time savings vs. Quality

### Analysis Template
```
Segment: [Audience Type]
Example: Product Managers at Growth-Stage Companies

Ads Targeting This Segment:
1. "[Ad copy]"
   - Problem emphasized: [specific pain]
   - Value prop: [specific benefit for this group]
   - CTA: [action word choice]
   - Tone: [formal/casual]

2. "[Ad copy]"
   - Problem emphasized: [specific pain]
   - Value prop: [specific benefit for this group]
   - CTA: [action word choice]
   - Tone: [formal/casual]

Insights:
- This segment is concerned with: [pain point]
- Messaging approach: [strategy]
- Visual style preferred: [style]
- CTA resonance: [what works]

Your Opportunity:
- Do you have separate messaging for this segment?
- How could you differentiate your approach?
- What pain point could you own that they're not covering?
```

## Workflow 6: Emerging Trends Detection

Spot new messaging trends before they become mainstream.

### Process
1. Collect fresh ads from all competitors (weekly/bi-weekly)
2. Note new messaging themes appearing
3. Track which competitors adopt new themes first
4. Identify cross-competitor adoption patterns

### Trend Signals
- **Weak signal**: One competitor tries new angle (1-2 ads)
- **Medium signal**: Multiple competitors testing (3-5 ads across set)
- **Strong signal**: New angle becomes dominant (majority of new ads)

### Analysis Framework
```
Potential Trend: AI-Powered Features

Signal Strength: Medium (appearing in 3 of 5 competitors)
Adoption Timeline:
- Competitor A: Started 2 months ago (2 ads)
- Competitor B: Started 1 month ago (4 ads)
- Competitor C: Just started (1 ad)
- Competitors D, E: Not yet

Interpretation:
- Early adopters are testing the angle
- Trending upward (new entrants are trying it)
- Not yet dominant (doesn't crowd out existing messaging)

Your Decision:
- Wait for stronger signal? (More competitors + higher frequency)
- Get ahead of trend? (Test AI angle before it becomes oversaturated)
- Ignore? (Not relevant to your positioning)

Test Approach:
- Create 1-2 test ads emphasizing AI benefits
- Run against current messaging baseline
- Measure performance vs. standard ads
```

## Workflow 7: Positioning Consolidation

Create comprehensive positioning strategy based on competitive analysis.

### Steps
1. Complete multi-competitor analysis (see Workflow 2)
2. Complete trend tracking (see Workflow 6)
3. Review your current positioning
4. Identify opportunities and threats

### Output: Positioning Strategy Document
```
# Positioning Strategy Recommendations

## Current Competitive Landscape
- Industry emphasizes: [consensus theme]
- Leader positioning: [leader's unique angle]
- Emerging trends: [new themes]

## Gaps and Opportunities
1. **Opportunity**: [Underserved positioning]
   - Competitors emphasize X, no one emphasizes Y
   - Your potential: Own Y
   - Risk: Y might not resonate

2. **Threat**: [Emerging competitive threat]
   - Competitor A is gaining share by emphasizing X
   - Your response options: Match, differentiate, or ignore

## Recommended Positioning
- **Primary message**: [What you should own]
- **Why**: [Market opportunity]
- **How to message**: [Suggested copy approach]
- **Who to target**: [Primary audience]
- **Differentiation**: [How you differ from competition]

## Testing Roadmap
1. Test ads emphasizing new positioning
2. Measure performance vs. current baseline
3. Refine based on results
4. Scale winners
```
