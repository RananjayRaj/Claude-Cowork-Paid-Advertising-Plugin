# Negative Keyword Templates

Pre-built negative keyword lists organized by theme for quick implementation. Copy-paste ready for Google Ads.

## Universal Negative Lists

### Job Seeker Negatives (Phrase Match)
```
"jobs"
"job"
"careers"
"career"
"hiring"
"employment"
"salary"
"salaries"
"wage"
"wages"
"pay scale"
"compensation"
"internship"
"internships"
"apprentice"
"apprenticeship"
"entry level"
"job opening"
"job openings"
"work from home job"
"remote job"
"part time job"
"full time job"
"job application"
"apply for job"
"job interview"
"resume"
"cv"
"cover letter"
"job description"
"job posting"
"glassdoor"
"indeed"
"linkedin job"
```

### Informational Negatives (Phrase Match)
```
"how to"
"what is"
"what are"
"why do"
"why does"
"when to"
"where to find"
"guide"
"tutorial"
"tutorials"
"tips"
"advice"
"learn"
"learning"
"course"
"courses"
"class"
"classes"
"training"
"certification"
"certifications"
"definition"
"meaning"
"explained"
"explain"
"overview"
"introduction"
"beginner"
"beginners"
"101"
"basics"
"fundamentals"
```

### Free Seeker Negatives (Phrase Match)
```
"free"
"free download"
"free online"
"free trial"
"freeware"
"open source"
"no cost"
"complimentary"
"gratis"
"free version"
"free alternative"
"free software"
"free tool"
"free app"
"free template"
"free sample"
```

### DIY Negatives (Phrase Match)
```
"diy"
"do it yourself"
"homemade"
"make your own"
"build your own"
"create your own"
"how to make"
"how to build"
"how to create"
"yourself"
"at home"
"home remedy"
"home remedies"
"natural remedy"
"self help"
```

### Support/Login Negatives (Phrase Match)
```
"login"
"log in"
"sign in"
"signin"
"account"
"my account"
"support"
"customer support"
"help desk"
"customer service"
"contact"
"phone number"
"email address"
"cancel"
"cancellation"
"refund"
"return"
"password"
"reset password"
"forgot password"
```

### Cheap/Discount Negatives (Phrase Match)
*Use only if premium positioning*
```
"cheap"
"cheapest"
"budget"
"discount"
"discounted"
"coupon"
"coupons"
"promo code"
"deal"
"deals"
"bargain"
"clearance"
"sale"
"on sale"
"markdown"
"lowest price"
"best price"
```

### Research Phase Negatives (Phrase Match)
*Use selectively - may exclude valuable traffic*
```
"reviews"
"review"
"reddit"
"forum"
"forums"
"comparison"
"compare"
"vs"
"versus"
"alternative"
"alternatives"
"pros and cons"
"worth it"
"is it good"
"should i"
```

## Industry-Specific Negative Lists

### eCommerce Negatives

**Used/Secondhand (Phrase Match)**
```
"used"
"secondhand"
"second hand"
"pre-owned"
"preowned"
"refurbished"
"renewed"
"vintage"
"antique"
"thrift"
"consignment"
"ebay"
"craigslist"
"facebook marketplace"
```

**Repair/Parts (Phrase Match)**
```
"repair"
"fix"
"fixing"
"broken"
"replacement part"
"spare part"
"parts"
"manual"
"instructions"
"warranty"
"troubleshooting"
```

**Size/Fit (Phrase Match)**
```
"size chart"
"sizing chart"
"sizing guide"
"size guide"
"measurements"
"dimensions"
"what size"
"does it fit"
"will it fit"
"true to size"
```

### B2B/SaaS Negatives

**Student/Academic (Phrase Match)**
```
"student"
"students"
"student discount"
"academic"
"university"
"college"
"school"
"education"
"educational"
"scholarship"
"financial aid"
```

**Wrong Segment - Enterprise (Phrase Match)**
*Use if targeting SMB*
```
"enterprise"
"enterprise grade"
"fortune 500"
"large business"
"corporation"
"corporate"
"oracle integration"
"sap integration"
"salesforce enterprise"
```

**Wrong Segment - SMB (Phrase Match)**
*Use if targeting Enterprise*
```
"small business"
"startup"
"startups"
"freelancer"
"freelance"
"solopreneur"
"side hustle"
"personal use"
"individual"
"home office"
```

**Technical/Developer (Phrase Match)**
*Use if targeting business users*
```
"api"
"api documentation"
"sdk"
"github"
"source code"
"developer"
"developers"
"coding"
"programming"
"integration"
"webhook"
```

### Lead Generation Negatives

**Licensing/Becoming (Phrase Match)**
```
"license"
"licensing"
"become a"
"how to become"
"certification"
"certified"
"school"
"training program"
"degree"
"requirements"
"qualifications"
```

**Legal Issues (Phrase Match)**
```
"lawsuit"
"sue"
"suing"
"class action"
"complaint"
"complaints"
"scam"
"fraud"
"rip off"
"ripoff"
"bbb"
"better business bureau"
```

### Local Business Negatives

**Chain/Corporate (Phrase Match)**
```
"corporate"
"headquarters"
"franchise"
"franchising"
"franchise opportunity"
"owner"
"ownership"
"buy franchise"
"corporate office"
"head office"
```

**Hours/Basic Info (Phrase Match)**
```
"hours"
"open"
"closed"
"holiday hours"
"phone"
"address"
"location"
"directions"
"parking"
"menu"
"prices"
"price list"
```

### Healthcare Negatives

**Home Remedy (Phrase Match)**
```
"home remedy"
"home remedies"
"natural treatment"
"natural cure"
"holistic"
"alternative medicine"
"herbal"
"essential oil"
"cure"
"self treat"
"treat at home"
```

**Insurance/Cost (Phrase Match)**
```
"insurance"
"does insurance cover"
"covered by insurance"
"cost"
"how much"
"price"
"pricing"
"affordable"
"low cost"
"free clinic"
"sliding scale"
"payment plan"
```

**Symptom Research (Phrase Match)**
```
"symptoms"
"symptom"
"signs of"
"what causes"
"why do i have"
"is it serious"
"should i worry"
"webmd"
"mayo clinic"
"diagnosis"
"self diagnose"
```

## Negative Keyword Best Practices

### Match Type Selection

**Use Exact Match When:**
- Term is borderline (could be valuable in some contexts)
- You want surgical precision
- Query is very specific phrase

**Use Phrase Match When:**
- Theme is clearly irrelevant
- Multiple variations exist
- You want broader coverage

**Use Broad Match When:**
- Theme is universally irrelevant
- Single word captures the issue
- You're certain all variations are bad

### Implementation Checklist

- [ ] Start with Universal Negatives (jobs, informational, support)
- [ ] Add Industry-Specific lists relevant to your business
- [ ] Review exceptions (terms that look bad but convert)
- [ ] Apply at appropriate level (campaign vs ad group vs account)
- [ ] Document exclusions for team reference
- [ ] Schedule monthly review to catch new patterns

### Common Mistakes to Avoid

1. **Over-excluding**: Blocking terms that actually convert
2. **Wrong match type**: Using broad when phrase would suffice
3. **Applying too broadly**: Account-level when should be campaign-level
4. **Not reviewing**: Set-and-forget leads to missed opportunities
5. **Duplicate negatives**: Same negative at multiple levels

### Negative Keyword Limits

- **Campaign level**: 10,000 negatives max
- **Ad group level**: 5,000 negatives max
- **Shared lists**: 5,000 per list, 20 lists per account

### Priority Implementation Order

**Day 1 (Critical):**
1. Job seeker negatives
2. Support/login negatives
3. Obviously irrelevant industry terms

**Week 1 (High Priority):**
1. Free seeker negatives (if applicable)
2. DIY negatives (if applicable)
3. Competitor brands (if not targeting)

**Week 2 (Medium Priority):**
1. Informational negatives (selective)
2. Wrong segment negatives
3. Research phase negatives (selective)

**Ongoing:**
1. Review search terms weekly for new patterns
2. Add emerging negative themes
3. Refine match types based on data

## Negative Keyword Audit Template

### Monthly Review Questions

1. **New wastage patterns?**
   - Any new irrelevant queries appearing?
   - Seasonal wastage emerging?
   - New competitor terms?

2. **Over-exclusion check?**
   - Any negatives blocking valuable traffic?
   - Impression share changes after exclusions?
   - Search term report gaps?

3. **Coverage gaps?**
   - Variants of existing negatives missing?
   - New match type expansions causing issues?
   - Geographic or demographic patterns?

4. **List hygiene?**
   - Duplicate negatives across levels?
   - Outdated negatives (old competitors, etc.)?
   - Conflicting negatives?

---

**Copy these lists directly into Google Ads Editor or the web interface. Adjust based on your specific business model and validate against actual search term data before broad application.**
