# Creative Diversity Framework for Andromeda

## Why Creative Diversity Matters for Andromeda

Andromeda's retrieval engine asks "which ad should this person see?" rather than "who should see this ad?" This fundamental shift means:

- The algorithm needs creative options to match with micro-segments
- Minor variations (font, color tweaks) register as duplicates
- Meaningful diversity = different messages, angles, formats
- More quality options = better retrieval matching = lower CPMs

## Diversity Dimensions

### 1. Message Angle Diversity

Different ways to frame the value proposition:

| Angle Type | Description | Example (Fitness App) |
|------------|-------------|----------------------|
| Problem-focused | Lead with pain point | "Tired of gym intimidation?" |
| Solution-focused | Lead with benefit | "Your pocket personal trainer" |
| Social proof | Lead with credibility | "Join 2M+ who got fit at home" |
| Urgency/scarcity | Lead with timing | "Summer body challenge starts Monday" |
| Aspiration | Lead with outcome | "The best shape of your life awaits" |
| Fear of missing out | Lead with opportunity cost | "Don't let another year slip by" |
| Comparison | Lead with alternative | "Skip the $200/month gym membership" |
| Story/testimonial | Lead with narrative | "How Sarah lost 30lbs without a gym" |

**Minimum for Andromeda**: 4-6 distinct message angles

### 2. Visual Style Diversity

Different aesthetic approaches:

| Style | Characteristics | Best For |
|-------|-----------------|----------|
| Polished/branded | Clean, professional, brand colors | Brand awareness, luxury |
| UGC/authentic | Raw, real, phone-shot feel | Trust, relatability |
| Bold/graphic | Strong typography, high contrast | Attention, promotions |
| Lifestyle | In-context, aspirational | Emotional connection |
| Product-focused | Clean background, detail shots | Consideration, features |
| Meme/cultural | Trending formats, humor | Engagement, younger demos |
| Before/after | Transformation visualization | Results-driven products |
| Infographic | Data, statistics, comparison | Education, B2B |

**Minimum for Andromeda**: 3-4 distinct visual styles

### 3. Format Diversity

Different ad formats for placement optimization:

| Format | Specs | Placement Fit |
|--------|-------|---------------|
| Single image (1:1) | 1080x1080 | Feed, Marketplace |
| Single image (4:5) | 1080x1350 | Feed (mobile optimized) |
| Single image (9:16) | 1080x1920 | Stories, Reels |
| Video (15-30s) | 1080x1080/4:5/9:16 | All placements |
| Video (short 6-15s) | 9:16 | Reels, Stories |
| Carousel (3-10 cards) | 1080x1080 | Feed, detailed storytelling |
| Collection | Hero + product grid | Shopping, catalog |
| Instant Experience | Full-screen immersive | High-intent audiences |

**Minimum for Andromeda**: 3 formats (static, video, carousel)

### 4. Hook Diversity (Video)

Different opening approaches for video ads:

| Hook Type | First 3 Seconds | When to Use |
|-----------|-----------------|-------------|
| Question | "Ever wonder why...?" | Problem awareness |
| Statement | "This changed everything" | Bold claim |
| Visual shock | Unexpected imagery | Scroll stopping |
| Social proof | "5 million people..." | Credibility |
| Before/after | Transformation clip | Results focus |
| Direct address | "Hey [target], stop scrolling" | Personalization |
| Tutorial start | "Here's how to..." | Educational |
| Trending audio | Popular sound/music | Cultural relevance |

**Minimum for Andromeda**: 4-5 different hooks across video creative

### 5. CTA Diversity

Different calls to action:

| CTA Type | Examples | Psychology |
|----------|----------|------------|
| Direct purchase | "Shop Now", "Buy Today" | High intent |
| Soft engagement | "Learn More", "See How" | Lower commitment |
| Urgency | "Get It Before Gone", "Last Chance" | Scarcity |
| Value-focused | "Save 50%", "Get Your Free..." | Incentive |
| Social | "Join 50K+ Customers" | Belonging |
| Curiosity | "Discover Why", "See the Secret" | Information gap |
| Action | "Start Your Journey", "Transform Today" | Empowerment |

## Creative Diversity Scoring Matrix

### Scoring Methodology

Evaluate each creative against the 5 dimensions:

| Dimension | Weight | Scoring Criteria |
|-----------|--------|------------------|
| Message angle | 25% | 1pt per unique angle (max 8) |
| Visual style | 25% | 2pts per unique style (max 8) |
| Format | 20% | 3pts per format used (max 12) |
| Hook (video) | 15% | 2pts per unique hook (max 10) |
| CTA | 15% | 1pt per unique CTA (max 7) |

### Diversity Score Calculation

```
Diversity Score = (
  (Unique Angles / 8) × 25 +
  (Unique Styles / 4) × 25 +
  (Formats Used / 4) × 20 +
  (Unique Hooks / 5) × 15 +
  (Unique CTAs / 7) × 15
)
```

### Score Interpretation

| Score | Rating | Andromeda Impact |
|-------|--------|------------------|
| 85-100 | Excellent | Maximum retrieval options |
| 70-84 | Good | Strong diversity, minor gaps |
| 55-69 | Moderate | Missing key variations |
| 40-54 | Poor | Limited algorithm fuel |
| <40 | Critical | Severely constraining delivery |

## Diversity Audit Checklist

### Message Angles Present?
- [ ] Problem-focused (pain point lead)
- [ ] Solution-focused (benefit lead)
- [ ] Social proof (credibility lead)
- [ ] Urgency/scarcity
- [ ] Aspiration/outcome
- [ ] Story/testimonial
- [ ] Comparison/alternative
- [ ] Feature-focused

### Visual Styles Present?
- [ ] Polished/branded
- [ ] UGC/authentic
- [ ] Bold/graphic
- [ ] Lifestyle/aspirational
- [ ] Product-focused
- [ ] Educational/infographic

### Formats Utilized?
- [ ] Static image (1:1)
- [ ] Static image (4:5 or 9:16)
- [ ] Video (15-30s)
- [ ] Video short-form (<15s)
- [ ] Carousel
- [ ] Collection/Instant Experience

### Hooks Varied? (Video)
- [ ] Question hook
- [ ] Statement hook
- [ ] Visual surprise
- [ ] Social proof opener
- [ ] Before/after start
- [ ] Direct address
- [ ] Tutorial opening

### CTAs Diversified?
- [ ] Direct purchase CTA
- [ ] Soft engagement CTA
- [ ] Urgency CTA
- [ ] Value-focused CTA
- [ ] Social/community CTA

## Common Diversity Mistakes

### What Andromeda Considers "Same"

These variations DO NOT count as diverse:
- Same concept, different background color
- Same video, different thumbnail
- Same copy, different stock image
- Same ad, cropped for different placement
- Minor headline word changes
- Logo placement variations
- Font/color scheme changes only

### What Andromeda Considers "Different"

These variations COUNT as diverse:
- Same product, completely different message angle
- Same offer, different visual treatment (polished vs UGC)
- Same benefit, different format (static vs video vs carousel)
- Same audience pain point, different spokesperson
- Same outcome, different storytelling approach
- Same promotion, different emotional appeal

## Creative Diversity Roadmap

### Phase 1: Foundation (Week 1)
Create minimum viable diversity:
- 3 distinct message angles
- 2 visual styles (polished + UGC)
- 2 formats (static + video)
- **Result**: 12 creative variations minimum

### Phase 2: Expansion (Weeks 2-3)
Add breadth:
- 2 additional message angles
- 1 additional visual style
- Carousel format
- **Result**: 20+ creative variations

### Phase 3: Optimization (Weeks 4+)
Iterate on winners:
- Double down on winning angles
- Test hook variations on winning videos
- Refresh fatigued styles
- **Result**: 25-30+ variations with performance data

## Creative Brief Template for Diversity

When briefing creative, ensure coverage:

```
Campaign: [Name]
Objective: [Purchase/Lead/Install]

Required Message Angles:
1. Problem-focused: [Specific pain point to address]
2. Solution-focused: [Core benefit to highlight]
3. Social proof: [Testimonial/stat to feature]
4. [Additional angle based on brand]

Required Visual Styles:
1. Branded/polished: [Brand guidelines ref]
2. UGC-style: [Authenticity guidelines]
3. [Third style if appropriate]

Required Formats:
1. Static 4:5 for Feed
2. Video 15-30s (provide 3+ hook options)
3. Carousel for storytelling

Hooks to Test (Video):
1. [Question hook script]
2. [Statement hook script]
3. [Visual hook concept]
4. [Social proof hook script]

CTAs to Include:
1. Primary: [Main CTA]
2. Secondary: [Softer CTA]
3. Urgency: [Time-sensitive CTA]
```

## Measuring Diversity Effectiveness

### Metrics to Track

| Metric | Indicates | Target |
|--------|-----------|--------|
| Spend distribution across ads | Algo finding uses for diversity | <50% in top 3 ads |
| Impression share per creative | Balanced delivery | 5-20% each (with 10+ ads) |
| Unique reach by format | Format utilization | All formats contributing |
| CTR variance | Message resonance differences | 0.5-2.5x between ads |
| Conversion variance | Performance differentiation | Clear winners emerging |

### Healthy Diversity Signals

- Spend spreads across 6+ ads (not concentrated in 1-2)
- Different creatives win with different audiences
- Format mix contributes proportionally
- Clear performance tiers emerge (not all equal)
- Algorithm finds use for most variations

### Unhealthy Diversity Signals

- 80%+ spend on 1-2 ads = insufficient meaningful diversity
- All ads perform identically = variations too similar
- Some formats get zero spend = format not suited for placements
- Quick exhaustion of all ads = need more concepts

## Refresh Cadence by Creative Type

| Creative Type | Typical Lifespan | Refresh Signal |
|---------------|------------------|----------------|
| UGC testimonial | 30-45 days | CTR decline >25% |
| Polished brand | 45-60 days | Frequency >3.0 |
| Promotional/offer | 14-21 days | Offer end date |
| Seasonal | Until season ends | Calendar driven |
| Evergreen education | 60-90 days | CPM inflation >30% |
| Trending/cultural | 7-14 days | Trend lifecycle |
