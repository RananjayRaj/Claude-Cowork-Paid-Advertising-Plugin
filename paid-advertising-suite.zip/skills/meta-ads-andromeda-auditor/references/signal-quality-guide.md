# Signal Quality Guide for Andromeda Optimization

## Why Signal Quality Matters for Andromeda

Andromeda's 10,000x more complex models require high-quality input signals to function optimally:

- Better signals = more accurate retrieval matching
- Poor signals = algorithm optimizes toward noise
- CAPI is no longer optional—it's foundational
- Event quality directly impacts delivery efficiency

## Conversion API (CAPI) Implementation Assessment

### CAPI Status Levels

| Level | Description | Andromeda Impact |
|-------|-------------|------------------|
| **None** | Browser pixel only | Severe signal loss (30-50% events missed) |
| **Partial** | Some events via CAPI | Improved but inconsistent |
| **Full Browser + CAPI** | Redundant tracking | Optimal—deduplication handles overlap |
| **Server-Only** | CAPI without pixel | Good but loses real-time browser data |

### CAPI Audit Checklist

**Basic Setup**
- [ ] CAPI integration active in Events Manager
- [ ] Test events firing correctly
- [ ] Deduplication configured (event_id matching)
- [ ] All conversion events included

**Advanced Setup**
- [ ] Customer information parameters populated
- [ ] Purchase value and currency passed
- [ ] Content data (product IDs, categories) included
- [ ] Server-side events have user data attached

**Customer Information Parameters**

| Parameter | Importance | Match Impact |
|-----------|------------|--------------|
| Email (hashed) | Critical | +20-30% EMQ |
| Phone (hashed) | High | +10-15% EMQ |
| First name | Medium | +5-8% EMQ |
| Last name | Medium | +5-8% EMQ |
| City | Low-Medium | +3-5% EMQ |
| State | Low-Medium | +3-5% EMQ |
| Zip code | Medium | +5-10% EMQ |
| Country | Low | +1-2% EMQ |
| External ID | High | +10-15% EMQ |
| Client IP | Medium | +5-8% EMQ |
| User agent | Medium | +5-8% EMQ |
| FBC (click ID) | Critical | +15-25% EMQ |
| FBP (browser ID) | Critical | +15-25% EMQ |

### Event Match Quality (EMQ) Scoring

| EMQ Score | Rating | Action Required |
|-----------|--------|-----------------|
| 8.0+ | Excellent | Maintain current setup |
| 6.0-7.9 | Good | Minor optimizations available |
| 4.0-5.9 | Fair | Significant improvements needed |
| <4.0 | Poor | Critical—prioritize immediately |

### EMQ Improvement Tactics

**Quick Wins (+0.5-1.0 EMQ)**
- Add FBC and FBP parameters to CAPI events
- Include client IP and user agent
- Hash and send email with all events

**Medium Effort (+1.0-2.0 EMQ)**
- Add phone number collection to forms
- Include external_id from CRM
- Implement advanced matching parameters

**Significant Effort (+2.0+ EMQ)**
- Customer data platform integration
- Real-time customer info enrichment
- Full parameter coverage on all events

## Pixel Health Assessment

### Pixel Audit Checklist

**Basic Health**
- [ ] Pixel installed on all pages
- [ ] PageView firing on every page load
- [ ] No JavaScript errors blocking pixel
- [ ] Base code in <head> section

**Event Tracking**
- [ ] All conversion events configured
- [ ] Event parameters properly populated
- [ ] Value and currency on purchase events
- [ ] Content IDs matching catalog (if applicable)

**Technical Quality**
- [ ] Single pixel per site (no duplicates)
- [ ] Events fire once per action (no duplicates)
- [ ] Page load time not blocking pixel
- [ ] Mobile tracking functioning

### Common Pixel Issues

| Issue | Symptom | Impact | Fix |
|-------|---------|--------|-----|
| Duplicate events | 2x conversions in reports | Algorithm learns wrong patterns | Implement deduplication |
| Missing value | $0 purchase value | Can't optimize for value | Pass value parameter |
| Wrong event | Purchase fires on add to cart | Optimization misaligned | Fix trigger conditions |
| Partial coverage | Some pages missing pixel | Incomplete journey data | Install on all pages |
| Delayed firing | Events fire after redirect | Lost attribution | Fire before redirect |

## Conversion Event Optimization

### Event Priority Framework

**Primary Conversion (Optimize toward)**
- One clear event per campaign
- Highest business value action
- Sufficient volume (50+/week)
- Clean tracking, no duplicates

**Secondary Conversions (Inform algorithm)**
- Support primary optimization
- Don't set as campaign objective
- Track for reporting/analysis
- Include in funnel visibility

### Conversion Setup Best Practices

| Business Type | Primary Event | Secondary Events |
|---------------|---------------|------------------|
| Ecommerce | Purchase | Add to Cart, View Content, Initiate Checkout |
| Lead Gen | Lead (form submit) | View Content, Contact Click |
| SaaS | Trial Start / Subscribe | Sign Up, Add Payment Info |
| App | Purchase / Subscribe | App Install, Registration |
| Content | Subscription | Sign Up, Engagement |

### Conversion Value Optimization

**For Ecommerce**
- Pass actual purchase value
- Include currency code
- Track profit margins if possible
- Use value optimization bidding

**For Lead Gen**
- Assign lead values based on close rates
- Differentiate lead quality tiers
- Import offline conversion data
- Update values as you learn

**Value Assignment Framework**

```
Lead Value = (Average Deal Size × Close Rate) - Acquisition Cost Buffer

Example:
- Average deal: $5,000
- Close rate: 10%
- Buffer: 20%
Lead Value = ($5,000 × 0.10) × 0.80 = $400
```

## Attribution Setup

### Attribution Windows for Andromeda

| Attribution Type | Window | When to Use |
|------------------|--------|-------------|
| 7-day click, 1-day view | Short window | Quick purchase cycles, low consideration |
| 7-day click, 7-day view | Standard | Most ecommerce, lead gen |
| 28-day click, 1-day view | Extended click | High consideration, B2B |
| 1-day click | Short click only | Low-cost impulse products |

### Attribution Audit Questions

1. Does attribution window match actual customer journey?
2. Are view-through conversions appropriate for the product?
3. Is attribution consistent across campaigns?
4. Are offline conversions being imported?

## Aggregated Event Measurement (AEM) Optimization

### Event Prioritization (iOS 14.5+)

You can configure up to 8 conversion events per domain:

| Priority | Event | Rationale |
|----------|-------|-----------|
| 1 (Highest) | Purchase | Primary business outcome |
| 2 | Initiate Checkout | High-intent signal |
| 3 | Add Payment Info | Strong purchase intent |
| 4 | Add to Cart | Consideration signal |
| 5 | Lead / Complete Registration | Secondary conversion |
| 6 | View Content | Engagement signal |
| 7 | Search | Intent signal |
| 8 | Page View | Baseline engagement |

### AEM Configuration Checklist

- [ ] Domain verified in Business Manager
- [ ] Events prioritized in Events Manager
- [ ] All 8 slots utilized strategically
- [ ] Primary conversion in top 4 priorities
- [ ] Reviewed quarterly for optimization

## Data Freshness Assessment

### Customer List Health

| List Age | Quality | Action |
|----------|---------|--------|
| <30 days | Excellent | Use actively |
| 30-90 days | Good | Update when possible |
| 90-180 days | Fair | Refresh recommended |
| >180 days | Poor | Replace with fresh data |

### Audience Refresh Cadence

| Audience Type | Refresh Frequency | Rationale |
|---------------|-------------------|-----------|
| Website visitors | Auto-updated | Pixel handles |
| Customer lists | Monthly minimum | Purchase/behavior changes |
| Engagement audiences | Auto-updated | Platform handles |
| Lookalikes | Quarterly | Seed quality evolves |

## Signal Quality Score Calculation

### Component Weights

| Component | Weight | Max Points |
|-----------|--------|------------|
| CAPI Implementation | 30% | 30 |
| Event Match Quality | 25% | 25 |
| Pixel Health | 20% | 20 |
| Conversion Setup | 15% | 15 |
| Data Freshness | 10% | 10 |

### Scoring Rubric

**CAPI Implementation (30 points)**
- Full CAPI + Browser: 30 pts
- Partial CAPI: 15-20 pts
- Browser only: 5-10 pts
- None: 0 pts

**Event Match Quality (25 points)**
- EMQ 8.0+: 25 pts
- EMQ 6.0-7.9: 18-22 pts
- EMQ 4.0-5.9: 10-15 pts
- EMQ <4.0: 0-8 pts

**Pixel Health (20 points)**
- Clean, complete tracking: 20 pts
- Minor issues: 12-16 pts
- Significant issues: 6-10 pts
- Critical problems: 0-5 pts

**Conversion Setup (15 points)**
- Optimal configuration: 15 pts
- Good with minor gaps: 10-12 pts
- Suboptimal: 5-8 pts
- Poor: 0-4 pts

**Data Freshness (10 points)**
- All current (<30 days): 10 pts
- Mostly current: 6-8 pts
- Mixed freshness: 3-5 pts
- Stale data: 0-2 pts

### Score Interpretation

| Score | Grade | Andromeda Readiness |
|-------|-------|---------------------|
| 85-100 | A | Signals fully support Andromeda optimization |
| 70-84 | B | Good signals with improvement opportunities |
| 55-69 | C | Signal gaps limiting performance |
| 40-54 | D | Significant signal issues impacting delivery |
| <40 | F | Critical—signals severely constraining algorithm |

## Signal Quality Improvement Roadmap

### Week 1: Critical Fixes
- Implement CAPI if not present
- Fix any duplicate event issues
- Verify primary conversion tracking
- Estimated impact: +15-25% signal quality

### Weeks 2-3: Optimization
- Add customer information parameters
- Optimize EMQ toward 8.0+
- Configure proper attribution windows
- Estimated impact: +10-15% signal quality

### Weeks 4+: Advanced
- Import offline conversions
- Implement value optimization
- Set up enhanced matching
- Estimated impact: +5-10% signal quality

## Testing Signal Quality

### Verification Steps

1. **Test Mode Events**: Use Events Manager test tool
2. **Event Matching**: Check Event Match Quality score
3. **Deduplication**: Verify events aren't doubling
4. **Parameter Completeness**: Confirm all required params present
5. **Real Conversion Test**: Process test purchase end-to-end

### Monitoring Dashboard Metrics

- Event Match Quality (target: 8.0+)
- Events received vs expected (target: >95%)
- Deduplication rate (target: <5% duplicates)
- Parameter fill rates (target: >90%)
- Attribution coverage (target: >80% conversions attributed)
