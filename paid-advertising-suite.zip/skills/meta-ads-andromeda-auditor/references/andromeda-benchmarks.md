# Andromeda Performance Benchmarks

## Industry Benchmarks by Objective (Post-Andromeda 2025)

### Ecommerce - Purchase Optimization

| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| ROAS | <2.0 | 2.0-3.5 | 3.5-5.0 | >5.0 |
| CTR | <0.8% | 0.8-1.5% | 1.5-2.5% | >2.5% |
| CVR (Click) | <1.0% | 1.0-2.5% | 2.5-4.0% | >4.0% |
| CPM | >$25 | $15-25 | $8-15 | <$8 |
| Frequency | >4.0 | 2.5-4.0 | 1.5-2.5 | 1.0-1.5 |

### Lead Generation - Form Submission

| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| CPL | >$75 | $40-75 | $20-40 | <$20 |
| CTR | <0.6% | 0.6-1.2% | 1.2-2.0% | >2.0% |
| Form CVR | <2% | 2-5% | 5-10% | >10% |
| Lead Quality | <20% SQL | 20-40% | 40-60% | >60% |
| CPM | >$20 | $12-20 | $6-12 | <$6 |

### App Install Campaigns

| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| CPI | >$5 | $2.50-5 | $1-2.50 | <$1 |
| CTR | <0.5% | 0.5-1.0% | 1.0-1.8% | >1.8% |
| Install Rate | <20% | 20-35% | 35-50% | >50% |
| D7 Retention | <15% | 15-25% | 25-40% | >40% |
| CPM | >$15 | $8-15 | $4-8 | <$4 |

### Traffic/Awareness Campaigns

| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| CPC | >$2.00 | $0.80-2.00 | $0.30-0.80 | <$0.30 |
| CTR | <0.5% | 0.5-1.2% | 1.2-2.0% | >2.0% |
| CPM | >$18 | $10-18 | $5-10 | <$5 |
| Engagement Rate | <1% | 1-3% | 3-6% | >6% |

## Andromeda Readiness Score Components

### Structure Score (25 points max)

| Factor | Poor (0-5) | Average (6-12) | Good (13-20) | Excellent (21-25) |
|--------|------------|----------------|--------------|-------------------|
| Campaign count per objective | 10+ | 5-9 | 2-4 | 1-2 |
| Ad sets per campaign | 15+ | 8-14 | 4-7 | 1-3 |
| Audience overlap | >50% | 30-50% | 10-30% | <10% |
| Budget fragmentation | High | Moderate | Low | Minimal |

### Creative Diversity Score (25 points max)

| Factor | Poor (0-5) | Average (6-12) | Good (13-20) | Excellent (21-25) |
|--------|------------|----------------|--------------|-------------------|
| Distinct concepts | 1-3 | 4-7 | 8-12 | 13+ |
| Format variety | 1 format | 2 formats | 3 formats | 4+ formats |
| Message diversity | Same angle | 2-3 angles | 4-5 angles | 6+ angles |
| Visual variety | Minimal | Some | Moderate | High |

### Signal Quality Score (25 points max)

| Factor | Poor (0-5) | Average (6-12) | Good (13-20) | Excellent (21-25) |
|--------|------------|----------------|--------------|-------------------|
| CAPI status | None | Browser only | Partial CAPI | Full CAPI |
| Event Match Quality | <4.0 | 4.0-5.9 | 6.0-7.9 | 8.0+ |
| Conversion clarity | Multiple/confused | Some overlap | Clear primary | Single optimized |
| Data freshness | >90 days | 30-90 days | 7-30 days | Real-time |

### Optimization Score (25 points max)

| Factor | Poor (0-5) | Average (6-12) | Good (13-20) | Excellent (21-25) |
|--------|------------|----------------|--------------|-------------------|
| Learning status | Perpetual | Frequent resets | Occasional | Stable |
| Advantage+ adoption | None | Partial | Most features | Full utilization |
| Bid strategy alignment | Misaligned | Partially | Mostly | Fully optimized |
| Testing cadence | None | Sporadic | Monthly | Continuous |

### Overall Andromeda Readiness Grades

| Score | Grade | Interpretation |
|-------|-------|----------------|
| 85-100 | A | Fully optimized for Andromeda delivery |
| 70-84 | B | Well-aligned with minor optimization opportunities |
| 55-69 | C | Moderate alignment, significant improvements available |
| 40-54 | D | Poorly aligned, major restructuring needed |
| 0-39 | F | Pre-Andromeda structure, complete overhaul required |

## Creative Fatigue Thresholds

### By Audience Size

| Audience Size | Safe Frequency | Warning Zone | Critical Zone |
|---------------|----------------|--------------|---------------|
| <100K | 1.5 | 2.0-2.5 | >2.5 |
| 100K-500K | 2.0 | 2.5-3.5 | >3.5 |
| 500K-2M | 2.5 | 3.5-4.5 | >4.5 |
| >2M | 3.0 | 4.5-6.0 | >6.0 |

### Performance Decay Signals

| Metric | Early Warning | Moderate Fatigue | Severe Fatigue |
|--------|---------------|------------------|----------------|
| CTR decline from peak | 10-20% | 20-40% | >40% |
| CVR decline from peak | 15-25% | 25-45% | >45% |
| CPM increase from baseline | 10-25% | 25-50% | >50% |
| Days since launch | 30-45 | 45-75 | >75 |

## Learning Phase Requirements

### Minimum Events for Exit

| Objective | Events/Week Needed | Budget Implication |
|-----------|-------------------|-------------------|
| Purchases | 50 | Budget = 50 × CPA × 1.5 |
| Leads | 50 | Budget = 50 × CPL × 1.5 |
| Add to Cart | 50 | Budget = 50 × Cost per ATC × 1.5 |
| App Installs | 50 | Budget = 50 × CPI × 1.5 |

### Learning Phase Stability Factors

| Factor | Disrupts Learning | Maintains Stability |
|--------|-------------------|---------------------|
| Budget changes | >20% in 3 days | <10% weekly |
| Audience edits | Any targeting change | Stable targeting |
| Bid strategy | Any change | Consistent strategy |
| Creative additions | >50% new ads | <30% rotation |
| Objective change | Always resets | Never change mid-flight |

## Budget Allocation Guidelines

### By Objective (Daily Minimum)

| Objective | Minimum Daily | Recommended Daily | Scale Ready |
|-----------|---------------|-------------------|-------------|
| Conversions (Purchase) | 10 × CPA | 20 × CPA | 50+ × CPA |
| Lead Generation | 10 × CPL | 20 × CPL | 50+ × CPL |
| App Installs | 10 × CPI | 20 × CPI | 50+ × CPI |
| Traffic | $20 | $50 | $200+ |

### Budget Distribution Best Practices

- **Single campaign focus**: 70-80% to primary campaign
- **Testing budget**: 15-20% for creative/audience testing
- **Scaling threshold**: Only scale campaigns with 50+ conversions/week
- **Increment size**: 20-30% budget increases max per adjustment

## Advantage+ Performance Expectations

### Advantage+ Shopping Campaigns

| Metric | Without A+ | With A+ Optimized |
|--------|------------|-------------------|
| ROAS | Baseline | +10-25% |
| CPM efficiency | Baseline | -10-20% |
| Conversion volume | Baseline | +15-30% |
| Time to optimize | 14-21 days | 7-14 days |

### Advantage+ Creative Features Impact

| Feature | Typical Improvement |
|---------|---------------------|
| Text variations | +5-12% CTR |
| Image enhancements | +3-8% engagement |
| Music (Reels) | +10-20% completion rate |
| All placements | +15-25% reach efficiency |

## Seasonal Adjustment Factors

### CPM Multipliers by Season (US Market)

| Period | Multiplier | Strategy Adjustment |
|--------|------------|---------------------|
| January | 0.7-0.8x | Aggressive testing window |
| Q1 (Feb-Mar) | 0.9-1.0x | Baseline optimization |
| Q2 (Apr-Jun) | 1.0-1.1x | Summer prep |
| July-Aug | 0.85-0.95x | Secondary testing window |
| September | 1.1-1.2x | Q4 prep begins |
| October | 1.2-1.4x | Pre-holiday ramp |
| November | 1.5-2.0x | BFCM peak |
| December | 1.3-1.8x | Holiday season |

### Budget Planning for Seasons

- **Low season**: Test more, optimize creative, build audiences
- **Shoulder season**: Scale winners, refresh creative
- **Peak season**: Deploy proven creative, maximize spend on winners
- **Post-peak**: Retargeting emphasis, customer retention
