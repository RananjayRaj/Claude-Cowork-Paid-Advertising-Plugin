---
name: meta-ads-andromeda-auditor
description: Analyze Meta Ads campaigns using Andromeda delivery system insights to assess signal quality, creative diversity, budget distribution, audience overlap, learning stability, and campaign structure. Provides structural, creative, and bidding optimizations to improve efficiency, scale, and conversion outcomes. Use when auditing Facebook/Instagram ad performance, diagnosing declining ROAS, troubleshooting Advantage+ campaigns, or optimizing for Meta's AI-driven delivery system.
---

# Meta Ads Andromeda Auditor

Comprehensive audit framework for Meta advertising campaigns optimized for the Andromeda delivery system (rolled out late 2024-2025). Identifies misalignments between campaign structure and how Andromeda's AI-driven retrieval engine selects and delivers ads.

## What This Skill Does

Analyzes Meta Ads campaigns across 8 Andromeda-critical dimensions:

1. **Campaign Structure Efficiency** - Consolidation vs fragmentation assessment
2. **Creative Diversity Score** - Meaningful variation analysis for retrieval optimization
3. **Signal Quality Assessment** - Conversion API setup, pixel health, event quality
4. **Audience Configuration** - Broad vs narrow targeting alignment with Andromeda
5. **Budget Distribution** - Learning phase stability and spend allocation
6. **Bidding Strategy Alignment** - Cost controls and delivery optimization
7. **Creative Fatigue Detection** - Performance decay and refresh timing
8. **Advantage+ Utilization** - Automation feature adoption and effectiveness

**Output**: Executive audit report with Andromeda Readiness Score (0-100), prioritized action plan, and projected performance impact.

## Understanding Andromeda

Andromeda is Meta's AI-powered ad retrieval engine (2024-2025) that fundamentally changed ad delivery:

**Before Andromeda**: Rule-based system, advertiser-defined targeting, limited creative processing
**With Andromeda**: 10,000x model complexity, real-time behavioral matching, creative diversity as primary lever

Key implications:
- Broad targeting outperforms micro-segmentation
- Creative diversity > audience fragmentation
- 8-15 meaningfully different creatives per campaign recommended
- Consolidation wins over complex account structures

## Required Data

### Option 1: Meta Ads Manager Export (Preferred)
Export last 30-90 days covering:
- Campaign/ad set/ad level metrics (impressions, clicks, conversions, cost, ROAS)
- Breakdown by placement, device, age, gender
- Creative asset performance
- Conversion events and values

### Option 2: Spreadsheet/CSV
Include columns:
- Campaign metrics: campaign_name, impressions, clicks, CTR, conversions, cost, conv_value, ROAS
- Ad set data: ad_set_name, audience_type, targeting_details, budget, delivery_status
- Ad data: ad_name, creative_type, headline, primary_text, impressions, conversions
- Learning phase status per ad set

### Option 3: Screenshots/Manual
Describe campaign structure and I'll guide data collection.

## How to Use

### Quick Andromeda Audit
```
Audit this Meta Ads campaign for Andromeda optimization
[attach campaign data]
```

### Comprehensive Audit
```
Run full Andromeda audit with structure and creative analysis
[attach campaign data]

Context:
- Business type: [ecommerce/lead gen/app]
- Monthly spend: [$X]
- Target ROAS/CPA: [X]
- Conversion API status: [enabled/not enabled]
```

### Focused Analysis
```
Analyze creative diversity and fatigue for Andromeda optimization
[attach ad-level performance data]
```

## Audit Framework

### 1. Campaign Structure Efficiency (Critical for Andromeda)

**Assess**:
- Number of active campaigns/ad sets/ads
- Audience overlap between ad sets
- Budget fragmentation
- Consolidation opportunities

**Andromeda-Aligned Benchmarks**:
- 1-3 campaigns per objective (not 10+)
- Fewer ad sets with broader audiences
- 8-15+ ads per ad set with meaningful diversity
- Minimal audience overlap (<30%)

**Red Flags**: 10+ ad sets with narrow targeting, significant audience overlap, budget spread thin across many campaigns

### 2. Creative Diversity Score

**Assess**:
- Number of meaningfully different creative concepts
- Variation across: hook, visual style, format, CTA, emotional appeal
- Copy/headline diversity
- Format mix (static, video, carousel, UGC)

**Andromeda Requirements**:
- 8-15 distinct creative concepts minimum
- "Distinct" = different message/angle, not color/font tweaks
- Format variety for placement optimization
- Fresh creative within 4-6 week cycles

**Red Flags**: <5 ads, minor variations only, all same format, creative older than 60 days

### 3. Signal Quality Assessment

**Assess**:
- Conversion API (CAPI) implementation status
- Event Match Quality score
- Pixel health and event firing accuracy
- Primary vs secondary conversion setup

**Andromeda Requirements**:
- CAPI enabled with server-side events
- Event Match Quality >6.0 (ideally 8.0+)
- Primary conversion action clearly defined
- Value optimization enabled for ecommerce

**Red Flags**: No CAPI, EMQ <5.0, multiple conflicting conversion goals, micro-conversions as primary

### 4. Audience Configuration

**Assess**:
- Targeting breadth (broad vs detailed)
- Lookalike usage and seed quality
- Advantage+ audience expansion settings
- Custom audience freshness

**Andromeda-Aligned Approach**:
- Broader targeting recommended (country-wide, minimal exclusions)
- Lookalikes as signals, not hard boundaries
- Advantage+ expansion enabled
- Let algorithm find audiences within broad pools

**Red Flags**: Hyper-specific interest stacking, many exclusions, expansion disabled, outdated custom audiences

### 5. Budget Distribution & Learning

**Assess**:
- Daily budget vs minimum for learning phase
- Learning phase status across ad sets
- Budget-limited warnings
- Spend concentration patterns

**Andromeda Requirements**:
- Budget sufficient for 50+ conversions/week per ad set
- Stable budgets (no frequent changes disrupting learning)
- 5-7 days minimum before major adjustments
- Avoid budget-limited status on performing campaigns

**Red Flags**: Perpetual learning phase, frequent budget changes, <20 conversions/week, budget limited daily

### 6. Bidding Strategy Alignment

**Assess**:
- Bid strategy selection (lowest cost, cost cap, ROAS target, bid cap)
- Target CPA/ROAS realism
- Delivery optimization alignment with goals
- Cost control utilization

**Andromeda Context**:
- Lowest cost often preferred for Andromeda learning
- Cost caps can limit delivery in AI-driven system
- Aggressive targets reduce ad pool eligibility
- Let system optimize before constraining

**Red Flags**: Overly aggressive cost caps, ROAS targets >2x historical, bid caps limiting delivery

### 7. Creative Fatigue Detection

**Assess**:
- Performance trends over time (CTR, CVR decay)
- Frequency by ad
- Days since creative launch
- Winners vs fatigued assets

**Fatigue Indicators**:
- CTR declined >30% from peak
- Frequency >3.0 on same audience
- Creative running >45-60 days unchanged
- CPM increasing while CTR decreasing

**Red Flags**: Top ads running 90+ days, frequency >5, declining CTR with rising CPM

### 8. Advantage+ Utilization

**Assess**:
- Advantage+ campaign adoption
- Advantage+ creative features enabled
- Placement optimization settings
- Automation feature usage

**Andromeda Alignment**:
- Advantage+ Shopping/App campaigns for scale
- Advantage+ creative enhancements (text variations, image optimization)
- All placements enabled for maximum reach
- Automation features generally recommended

**Red Flags**: Manual placements only, Advantage+ features disabled, legacy campaign types for new objectives

## Output Format

### Executive Summary
- **Andromeda Readiness Score**: 0-100 with grade (A/B/C/D/F)
- **Top 3 Critical Issues**: With estimated performance impact
- **Top 3 Quick Wins**: Implement within 7 days
- **Overall Assessment**: Alignment with Andromeda delivery system

### Detailed Findings

For each of the 8 dimensions:
- Current state assessment
- Key metrics vs Andromeda benchmarks
- Issues identified (Critical/High/Medium)
- Specific recommendations
- Expected impact

### Action Plan

**Immediate (Week 1)**
1. [Action] - Impact: [%] - Effort: [hours]
2. [Action] - Impact: [%] - Effort: [hours]

**Short-term (Weeks 2-4)**
- Structural changes
- Creative refresh plan
- Signal quality improvements

**Long-term (Month 2+)**
- Testing roadmap
- Scaling strategy
- Monitoring framework

### Performance Projection
- Current waste identified: $X/month
- Quick win potential: +X% efficiency in 30 days
- Full optimization potential: +X% ROAS in 90 days

## Andromeda-Specific Best Practices

**Structure for Andromeda**:
- Consolidate to fewer, broader campaigns
- Let AI handle micro-targeting
- Trust Advantage+ automation
- Simplify account architecture

**Creative for Andromeda**:
- Volume + variety = algorithm fuel
- Test distinct concepts, not minor tweaks
- Mix formats (video, static, carousel, UGC)
- Refresh every 4-6 weeks

**Signals for Andromeda**:
- CAPI is non-negotiable
- Clean, accurate conversion events
- Single clear optimization goal per campaign
- Value data for ecommerce

**Patience with Andromeda**:
- 5-7 days minimum learning time
- Avoid frequent manual adjustments
- Trust the algorithm's learning
- Measure weekly, not daily

## Example Use Cases

**Ecommerce Brand with Declining ROAS**
- Situation: ROAS dropped 40% post-Andromeda rollout
- Audit found: 15 narrow ad sets, 3 similar creatives, no CAPI
- Actions: Consolidated to 3 ad sets, added 12 diverse creatives, implemented CAPI
- Result: ROAS recovered +65%, CPM -22%

**Lead Gen Agency Seeing Rising CPL**
- Situation: CPL doubled in 6 months
- Audit found: Hyper-targeted audiences, creative fatigue (90+ days), cost caps too aggressive
- Actions: Broadened targeting, refreshed creative, removed cost caps for learning
- Result: CPL -35%, lead volume +50%

**App Install Campaign Stuck in Learning**
- Situation: Perpetual learning phase, inconsistent delivery
- Audit found: Budget too low, frequent changes, limited creative variety
- Actions: Increased budget 3x, stabilized for 14 days, added 10 new creatives
- Result: Exited learning, CPI -28%, install volume 2.5x

## Reference Files

For detailed methodologies, access:
- `references/andromeda-benchmarks.md` - Performance benchmarks by industry and objective
- `references/creative-diversity-framework.md` - Scoring methodology for creative variation
- `references/signal-quality-guide.md` - CAPI implementation and event optimization

## Integration with Other Skills

Works well with:
- **meta-ads-creative-brief** - Generate diverse creative concepts post-audit
- **creative-testing-framework** - Design Andromeda-optimized testing strategy
- **landing-page-optimizer** - Improve post-click conversion
- **data-anomaly-detective** - Identify performance shifts

---

**Ready to audit your Meta Ads for Andromeda?** Share your campaign data and I'll identify structural issues, creative gaps, and optimization opportunities aligned with Meta's AI-driven delivery system.
