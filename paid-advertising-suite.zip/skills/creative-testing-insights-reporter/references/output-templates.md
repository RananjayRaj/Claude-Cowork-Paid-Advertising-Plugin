# Output Templates & Examples

## Template 1: Executive Summary

```
# Creative Testing Insights Report
**Test Period**: [Date range]
**Variants Tested**: [Number]
**Total Spend**: [Amount]
**Best Performer**: [Variant ID/Name] - [Key metric] of [Value]

## Key Findings
1. [Primary insight with impact]
2. [Secondary insight with impact]
3. [Tertiary insight with impact]

## Top Performance Drivers
- **[Element category]**: [Specific finding with % lift/impact]
- **[Element category]**: [Specific finding with % lift/impact]
- **[Element category]**: [Specific finding with % lift/impact]

## Recommendations
1. [Action item]: [Rationale]
2. [Action item]: [Rationale]
3. [Action item]: [Rationale]
```

## Template 2: Performance Matrix

Present findings as a structured comparison table:

| Creative Element | Variants Tested | Avg CTR | Avg CVR | Avg CPC | Avg ROAS | Performance Trend |
|-----------------|----------------|---------|---------|---------|----------|-------------------|
| [Element A]     | [Count]        | [%]     | [%]     | [$]     | [X]      | [↑/↓/→]          |

## Template 3: Pattern Analysis

```
## Pattern: [Name of pattern]
**Impact**: [High/Medium/Low]
**Confidence**: [Based on sample size/statistical significance]

### What We Tested
- Control: [Description]
- Variation: [Description]
- Sample size: [N variants]

### Results
- CTR: [Control %] vs [Variation %] ([% difference], [direction])
- CVR: [Control %] vs [Variation %] ([% difference], [direction])
- CPC: [Control $] vs [Variation $] ([% difference], [direction])
- ROAS: [Control X] vs [Variation X] ([% difference], [direction])

### Why It Matters
[Explanation of the insight and underlying psychology/principle]

### Application
[How to apply this finding to future creative development]
```

## Template 4: Visual Design Guidelines

```
# Creative Design Principles
*Based on [N] variants tested from [Date range]*

## ✅ Do This
### [Principle Name]
- **Finding**: [What performed well]
- **Impact**: [Metric improvement]
- **Example elements**: [Specific attributes]
- **Why it works**: [Psychological/strategic rationale]

## ❌ Avoid This
### [Anti-pattern Name]
- **Finding**: [What underperformed]
- **Impact**: [Metric decline]
- **Example elements**: [Specific attributes]
- **Why it failed**: [Explanation]

## Best Practices by Element
### Images
- ✓ [Recommendation with data]
- ✓ [Recommendation with data]
- ✗ [What to avoid with data]

### Copy
- ✓ [Recommendation with data]
- ✓ [Recommendation with data]
- ✗ [What to avoid with data]

### Layout
- ✓ [Recommendation with data]
- ✓ [Recommendation with data]
- ✗ [What to avoid with data]
```

## Template 5: Creative Brief for Next Campaign

```
# Creative Brief: [Campaign Name]
*Based on insights from [Source test/campaign]*

## Objective
[Goal and what we're optimizing for]

## Target Audience
[Based on which segments responded best]

## Key Message
[Core value proposition that resonated]

## Creative Strategy
### Winning Elements to Replicate
1. **[Element type]**: [Specific guidance from test data]
2. **[Element type]**: [Specific guidance from test data]
3. **[Element type]**: [Specific guidance from test data]

### Creative Variations to Test
- **Test 1**: [Hypothesis based on previous data]
  - Control: [Description]
  - Variation: [Description]
  - Expected impact: [Prediction]

- **Test 2**: [Hypothesis based on previous data]
  - Control: [Description]
  - Variation: [Description]
  - Expected impact: [Prediction]

## Production Specifications
- Format: [Based on what worked]
- Dimensions: [Based on what worked]
- Copy length: [Based on what worked]
- Visual style: [Based on what worked]

## Success Metrics
- Primary: [Metric and target based on benchmark]
- Secondary: [Metric and target based on benchmark]

## Do's and Don'ts
### Do:
- [Specific directive from test learnings]
- [Specific directive from test learnings]

### Don't:
- [Specific anti-pattern from test learnings]
- [Specific anti-pattern from test learnings]
```

## Template 6: Segment-Specific Insights

When data allows for segment analysis:

```
## Segment Performance Breakdown

### [Segment Name] (e.g., "Product-focused ads")
- **Volume**: [N variants, % of total]
- **Performance**:
  - CTR: [%] ([vs. average])
  - CVR: [%] ([vs. average])
  - CPC: [$] ([vs. average])
  - ROAS: [X] ([vs. average])
- **Top performer**: [Variant details]
- **Key attributes**: [What made this segment successful/unsuccessful]

### [Segment Name] (e.g., "Lifestyle ads")
[Same structure as above]
```

## Statistical Significance Notes

When presenting findings, indicate confidence level:
- **High confidence**: Sample size >30 variants, clear pattern, statistical significance at p<0.05
- **Medium confidence**: Sample size 10-30 variants, emerging pattern, directional evidence
- **Low confidence**: Sample size <10 variants, preliminary observation, requires validation

Example notation:
- "People-focused ads showed 32% higher CTR (High confidence, n=45, p<0.01)"
- "Gradient backgrounds trending positively (Medium confidence, n=12, directional)"
- "Question headlines show promise (Low confidence, n=6, requires testing)"
