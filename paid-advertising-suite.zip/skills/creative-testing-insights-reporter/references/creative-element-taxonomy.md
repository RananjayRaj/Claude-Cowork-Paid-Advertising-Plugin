# Creative Element Taxonomy

## Visual Elements

### Image Composition
- **Subject focus**: Product-only, person-only, person+product, lifestyle scene, abstract/conceptual
- **Shot type**: Close-up, medium shot, wide shot, flat lay, lifestyle in-use
- **Orientation**: Square (1:1), vertical (4:5, 9:16), horizontal (16:9, 1.91:1)
- **People presence**: No people, single person, multiple people, diverse representation
- **Background**: Plain/solid color, gradient, lifestyle setting, blurred, textured

### Visual Style
- **Color palette**: Bright/vibrant, muted/pastel, monochrome, brand colors, contrasting
- **Visual density**: Clean/minimal, moderate, busy/complex
- **Photography style**: Professional studio, user-generated, illustration/graphic, 3D render, mixed media
- **Mood/tone**: Energetic, calm, professional, playful, aspirational, authentic

### Text Overlays
- **Text presence**: No text overlay, minimal text, moderate text, text-heavy
- **Text placement**: Top, center, bottom, corner, full coverage
- **Typography style**: Bold/attention-grabbing, elegant/refined, playful, professional
- **Text readability**: High contrast, low contrast, color on color

## Copy Elements

### Headline Structure
- **Length**: Short (≤5 words), medium (6-10 words), long (11+ words)
- **Format**: Statement, question, command/CTA, statistic/number, benefit-focused
- **Hook type**: Problem-focused, solution-focused, curiosity/intrigue, social proof, urgency/scarcity
- **Tone**: Direct, conversational, formal, humorous, urgent, empathetic

### Value Proposition
- **Focus**: Feature-led, benefit-led, outcome-led, price/offer-led
- **Specificity**: Vague/general, specific numbers/details, ultra-specific
- **Differentiation**: Unique mechanism, comparison, category creation, social proof

### Call-to-Action
- **Type**: Learn more, sign up, buy now, get started, download, contact, try free
- **Urgency level**: None, soft (today, now), hard (limited time, countdown)
- **Friction**: High-commitment (buy, purchase), low-commitment (learn, explore, see)

## Format Elements

### Ad Format
- **Type**: Single image, carousel, video, collection, stories
- **Video length**: ≤6 sec, 7-15 sec, 16-30 sec, 31-60 sec, 60+ sec
- **Carousel slides**: 2-3, 4-5, 6-10

### Creative Approach
- **Concept**: Demo/how-it-works, testimonial/UGC, before/after, comparison, storytelling, educational, promotional
- **Messaging angle**: Problem-aware, solution-aware, product-aware, unaware
- **Emotional appeal**: Aspiration, fear/pain, joy/excitement, trust/safety, belonging

## Technical Elements

### Quality Indicators
- **Production value**: High-end/professional, mid-range, DIY/authentic
- **Brand consistency**: Strict guidelines, moderate, minimal/experimental
- **Platform optimization**: Native feel, generic/crossposted
