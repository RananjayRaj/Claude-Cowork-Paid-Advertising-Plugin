---
name: creative-testing-insights-reporter
description: Translate creative A/B test data from advertising platforms into actionable design principles and strategic recommendations. Use when analyzing ad creative performance data (from Meta, Google Ads, LinkedIn, or other platforms) to identify winning patterns, extract design principles, or develop creative guidelines. Key features include test synthesis, pattern identification, performance driver analysis, statistical validation, visual design guidelines creation, and creative brief development. Ideal for queries like "analyze these creative variants", "what patterns drove conversions", "create design guidelines from this test data", or "develop a creative brief based on test results".
---

# Creative Testing Insights Reporter

Transform raw creative A/B test data into strategic insights and actionable design principles.

## Overview

This skill analyzes advertising creative performance data to:
1. Identify high-impact creative elements and patterns
2. Extract statistically-valid design principles
3. Generate visual design guidelines
4. Create data-driven creative briefs for future campaigns

**Data sources supported**: CSV exports (Meta Ads Manager, LinkedIn Ads), Google Sheets, Excel, or structured data from any advertising platform.

**Key metrics**: CTR (Click-Through Rate), CVR (Conversion Rate), CPC (Cost Per Click), ROAS (Return on Ad Spend)

## Workflow

### Step 1: Data Intake & Preparation

**1.1 Receive and inspect the data**
- Identify the data source format (CSV, Google Sheets, structured text)
- Confirm presence of required fields: variant ID/name, creative description/attributes, performance metrics (CTR, CVR, CPC, ROAS)
- Note date range and total spend if available

**1.2 Normalize the data structure**
- Create a mental model mapping each variant to its creative elements and performance metrics
- If creative attributes aren't explicitly labeled, extract them from descriptions, file names, or visual inspection
- Flag any data quality issues (missing metrics, incomplete descriptions)

**1.3 Clarify analysis scope**
If the user's request is ambiguous, ask targeted questions:
- "Should I focus on any specific metric (CTR, CVR, CPC, ROAS) or analyze across all metrics?"
- "Are there specific creative elements you want me to examine (e.g., imagery, copy, format)?"
- "What's the primary goal - improving efficiency, scale, or both?"

### Step 2: Creative Element Extraction

**2.1 Load the taxonomy**
Read `references/creative-element-taxonomy.md` to understand the full range of creative elements to analyze.

**2.2 Tag each variant**
For each creative variant, identify and tag relevant elements across categories:
- Visual elements (composition, style, text overlays)
- Copy elements (headline structure, value proposition, CTA)
- Format elements (ad format, creative approach)
- Technical elements (quality indicators)

**2.3 Create element inventory**
Build a structured inventory showing:
- Which elements were tested
- How many variants included each element
- Which combinations appeared together

### Step 3: Pattern Analysis

**3.1 Segment by element**
Group variants by shared creative elements (e.g., all "people-focused" variants, all "question headline" variants)

**3.2 Calculate segment performance**
For each segment, calculate aggregate metrics:
- Average CTR, CVR, CPC, ROAS
- Performance vs. overall average (% lift or decline)
- Consistency (are results clustered or scattered?)
- Sample size (number of variants in segment)

**3.3 Identify patterns**
Look for patterns where:
- **High-impact winners**: Element consistently drives strong performance across multiple metrics
- **Efficiency drivers**: Element reduces CPC while maintaining or improving conversion rates
- **Conversion catalysts**: Element improves CVR significantly
- **Attention grabbers**: Element drives CTR but may not convert (awareness vs. conversion)
- **Anti-patterns**: Element consistently underperforms

**3.4 Validate significance**
Apply statistical rigor:
- **High confidence**: Sample size ≥30 variants, clear directional pattern, large effect size (>20% difference)
- **Medium confidence**: Sample size 10-29 variants, emerging pattern, moderate effect size (10-20% difference)
- **Low confidence**: Sample size <10 variants, preliminary observation, requires further testing

Always note confidence level when presenting findings.

**3.5 Explore interactions**
Look for combination effects:
- Do certain elements work better together? (e.g., "lifestyle images + benefit-focused headlines")
- Are there incompatible combinations? (e.g., "busy visuals + text-heavy copy")
- Do different combinations serve different funnel stages?

### Step 4: Insight Synthesis

**4.1 Prioritize findings**
Rank insights by:
1. **Impact magnitude**: Size of performance difference
2. **Statistical confidence**: Sample size and consistency
3. **Actionability**: Ease of implementation in future creative
4. **Strategic relevance**: Alignment with campaign goals

**4.2 Develop explanations**
For each key finding, provide:
- **What**: The observed pattern
- **Impact**: Quantified performance difference
- **Why**: Psychological or strategic rationale for why it works
- **How to apply**: Specific guidance for future creative development

**4.3 Identify testing gaps**
Note areas where:
- Sample sizes are too small for confident conclusions
- Important elements weren't adequately tested
- Confounding variables make interpretation difficult
- Additional testing would be valuable

### Step 5: Generate Deliverables

**5.1 Load output templates**
Read `references/output-templates.md` to understand the structure of each deliverable type.

**5.2 Select appropriate outputs**
Based on the user's request and data available, generate the most relevant deliverables:

**Executive Summary** (always include)
- High-level overview of test results
- 3-5 key findings with impact quantification
- Top performance drivers
- Strategic recommendations

**Performance Matrix** (include when analyzing multiple element categories)
- Structured table comparing performance across creative elements
- Shows trends and relative impact at a glance

**Pattern Analysis** (include for each major insight)
- Deep dive into specific patterns
- Control vs. variation comparison
- Statistical validation
- Strategic application guidance

**Visual Design Guidelines** (include when user needs creative direction)
- Dos and don'ts based on test data
- Best practices by creative element type
- Specific examples of winning attributes

**Creative Brief** (include when user needs next-campaign guidance)
- Data-driven creative strategy
- Winning elements to replicate
- New hypotheses to test
- Production specifications

**Segment-Specific Insights** (include when meaningful segments exist)
- Performance breakdown by creative segment
- Comparison of different creative approaches
- Audience-specific recommendations if data permits

**5.3 Format for clarity**
- Use tables for comparative data (performance matrices, segment breakdowns)
- Use clear headers and sections for scanability
- Bold key findings and numbers
- Include confidence levels for all statistical claims
- Provide specific examples and variant references

**5.4 Make it actionable**
Every insight should connect to a specific action:
- "Increase use of [element]" instead of "[Element] performed well"
- "Avoid [anti-pattern] because [reason]" instead of "[Element] performed poorly"
- "Test [hypothesis] next to validate [finding]" instead of "More testing needed"

## Analysis Best Practices

### Statistical Rigor
- Never make confident claims from small sample sizes (<10 variants per segment)
- Always note when findings are directional vs. statistically validated
- Consider confounding variables (e.g., did all "people-focused" ads also have longer copy?)
- Look for consistency across metrics (does CTR lift also translate to conversion lift?)

### Context Matters
- Consider the campaign objective (awareness vs. conversion campaigns have different success patterns)
- Account for platform differences (Meta vs. LinkedIn audiences behave differently)
- Note seasonality or external factors if relevant
- Respect budget allocation (high-spend variants have more statistical power)

### Segmentation Strategy
- Start with obvious segments (visual style, copy approach, format)
- Look for non-obvious patterns (e.g., emotional tone, specificity level)
- Avoid over-segmentation (too many micro-segments with tiny sample sizes)
- Test for interaction effects between elements

### Balanced Perspective
- Highlight both winners AND anti-patterns (knowing what doesn't work is valuable)
- Consider trade-offs (high CTR but poor CVR indicates targeting mismatch)
- Note when results are mixed or inconclusive
- Suggest additional testing for unclear areas

### Practical Application
- Prioritize insights that can be implemented quickly
- Provide specific creative direction (not just "use better images")
- Connect findings to broader creative strategy
- Balance proven winners with new hypotheses to test

## Common Pitfalls to Avoid

1. **Correlation vs. causation**: Just because top performers share an attribute doesn't mean that attribute caused the success
2. **Survivorship bias**: Don't ignore poor performers - understand why they failed
3. **Over-generalization**: Results from one campaign/audience may not apply universally
4. **Ignoring context**: Creative that works for awareness may not work for conversion
5. **False precision**: Don't report insights to excessive decimal places when sample sizes are small
6. **Analysis paralysis**: Focus on actionable insights, not exhaustive documentation of every micro-pattern

## Output Quality Standards

Every deliverable should be:
- **Data-driven**: Every claim backed by specific metrics
- **Actionable**: Clear guidance on what to do differently
- **Confident but honest**: Note limitations and confidence levels
- **Strategically relevant**: Aligned with campaign goals and business objectives
- **Scannable**: Easy to extract key insights quickly
- **Specific**: Concrete examples and recommendations, not vague generalizations

## Edge Cases

**Insufficient sample size**: 
- If <20 total variants, note that findings are preliminary
- Focus on directional insights and testing recommendations
- Avoid over-interpretation

**Inconsistent data quality**:
- Flag missing or unreliable data
- Work with what's available but note limitations
- Suggest data collection improvements

**Contradictory signals**:
- When an element drives CTR but hurts CVR (or vice versa), explain the trade-off
- Consider funnel stage and campaign objective to resolve
- May indicate targeting or landing page mismatch

**Narrow focus**:
- If all variants are very similar, findings will be limited
- Note the narrow testing scope
- Recommend broader testing for future campaigns

**Platform-specific quirks**:
- Different platforms have different norms and audience behaviors
- Note when findings may be platform-specific
- Avoid blanket recommendations that ignore platform context
