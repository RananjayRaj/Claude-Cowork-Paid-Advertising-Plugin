# Installation Guide - Meta Ads Creative Brief

## Quick Install (Recommended)

1. **Download the skill file**: `meta-ads-creative-brief.skill`
2. **In Claude.ai**, go to your profile → Settings → Features
3. **Enable "Skills"** if not already enabled
4. **Click "Add Skill"** and upload the `.skill` file
5. **Confirm installation** - the skill is now available!

## Manual Install (Advanced)

If you prefer to install manually or need to modify the skill:

### Step 1: Locate Skills Directory

**macOS/Linux:**
```bash
~/.config/claude/skills/user/
```

**Windows:**
```bash
%APPDATA%\Claude\skills\user\
```

### Step 2: Extract Skill Files

1. Download `meta-ads-creative-brief.skill` (it's a ZIP file)
2. Extract the contents
3. You should see this structure:
   ```
   meta-ads-creative-brief/
   ├── SKILL.md
   ├── README.md
   ├── EXAMPLES.md
   └── references/
       ├── creative-strategy-framework.md
       ├── format-specifications.md
       ├── audience-mapping.md
       └── brief-templates.md
   ```

### Step 3: Copy to Skills Directory

Copy the entire `meta-ads-creative-brief` folder into your skills directory:

```bash
cp -r meta-ads-creative-brief ~/.config/claude/skills/user/
```

### Step 4: Verify Installation

Restart Claude and ask:
```
Do you have the meta-ads-creative-brief skill?
```

Claude should confirm it has access to the skill.

## Verification Checklist

After installation, verify:

- [ ] Skill appears in Claude's available skills list
- [ ] You can request a creative brief and get a comprehensive response
- [ ] Reference materials are accessible (Claude may mention viewing them)
- [ ] Multiple output formats are available (Full Brief, Quick Brief, etc.)

## Testing the Skill

Try this test request:
```
Create a creative brief for a B2B SaaS product. 
We're targeting startup founders with a free trial offer.
Budget is $10K. Use the Quick Brief format.
```

You should receive a structured brief with campaign overview, audience insights, creative strategy, and format specifications.

## Troubleshooting

### Skill Not Showing Up

1. **Check file location**: Ensure files are in `~/.config/claude/skills/user/meta-ads-creative-brief/`
2. **Verify SKILL.md exists**: This file is required
3. **Restart Claude**: Close and reopen the application
4. **Check for errors**: Look in Claude's error logs if available

### YAML Errors

If you see YAML-related errors:

1. **Open SKILL.md** and check the frontmatter (first few lines)
2. **Verify format**:
   ```yaml
   ---
   name: meta-ads-creative-brief
   description: Generate creative briefs for designers based on campaign objectives
   ---
   ```
3. **Ensure only two keys**: `name` and `description`
4. **Check name format**: Must be lowercase with hyphens only

### Reference Files Not Loading

If Claude can't access reference materials:

1. **Check references folder**: Should be at `meta-ads-creative-brief/references/`
2. **Verify file names**: Should match exactly:
   - `creative-strategy-framework.md`
   - `format-specifications.md`
   - `audience-mapping.md`
   - `brief-templates.md`
3. **Check permissions**: Ensure files are readable

### Skill Works But Responses Are Generic

If responses lack depth:

1. **Provide more context** in your requests
2. **Be specific** about campaign objectives, audience, and budget
3. **Request specific output formats** (Full Brief vs Quick Brief)
4. **Include constraints** (timeline, existing creative, brand guidelines)

## Updating the Skill

To update to a newer version:

1. **Download the new `.skill` file**
2. **Remove the old version**:
   ```bash
   rm -rf ~/.config/claude/skills/user/meta-ads-creative-brief
   ```
3. **Install the new version** following the installation steps above
4. **Restart Claude**

## Uninstalling

To remove the skill:

```bash
rm -rf ~/.config/claude/skills/user/meta-ads-creative-brief
```

Then restart Claude.

## Getting Help

If you encounter issues:

1. **Check README.md** in the skill folder for usage guidance
2. **Review EXAMPLES.md** for sample requests and outputs
3. **Verify installation** using the checklist above
4. **Provide feedback** through Claude's interface (thumbs up/down on responses)

## Advanced Configuration

### Customizing Templates

You can modify the brief templates in `references/brief-templates.md`:

1. Open the file in a text editor
2. Modify the template structure
3. Save changes
4. Restart Claude for changes to take effect

### Adding Industry-Specific Templates

To add custom templates:

1. Edit `references/brief-templates.md`
2. Add your template following the existing format
3. Reference it by name when requesting briefs

### Adjusting Reference Materials

You can customize the strategic frameworks and guidelines:

1. Edit files in the `references/` folder
2. Keep file names the same for Claude to access them
3. Maintain markdown formatting
4. Restart Claude after changes

## System Requirements

- **Claude Desktop App**: Latest version recommended
- **Storage**: ~100KB for skill files
- **Platform**: macOS, Windows, or Linux

## Version Information

**Current Version**: 1.0
**Last Updated**: January 2025
**Compatibility**: Claude Sonnet 4 and above

## Privacy & Data

- **No data collected**: Skill operates entirely locally
- **No external calls**: All processing within Claude
- **Your campaigns are private**: Nothing is shared or stored externally

## Support

For questions or issues:
- Check the documentation files (README.md, EXAMPLES.md)
- Test with simple requests first
- Verify installation using the checklist
- Provide feedback through Claude's interface

---

**Installation complete?** Try asking Claude to create your first creative brief!
