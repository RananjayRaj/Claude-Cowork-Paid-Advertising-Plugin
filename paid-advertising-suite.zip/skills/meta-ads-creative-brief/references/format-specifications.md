# Meta Ads Format Specifications

## Complete Technical Requirements

### Static Image Ads

**Feed Placement:**
- **Aspect Ratio**: 1:1 (square) or 4:5 (vertical) recommended
- **Resolution**: Minimum 1080 x 1080 pixels
- **File Type**: JPG or PNG
- **File Size**: Maximum 30 MB
- **Text in Image**: < 20% of image area (not enforced, but recommended)
- **Safe Zones**: Keep text/logos 50px from edges

**Story Placement:**
- **Aspect Ratio**: 9:16 (vertical, full-screen)
- **Resolution**: 1080 x 1920 pixels
- **File Type**: JPG or PNG
- **File Size**: Maximum 30 MB
- **Safe Zones**: 
  - Top 250px (profile icon area)
  - Bottom 250px (CTA button area)

**Marketplace/Explore:**
- **Aspect Ratio**: 1:1 (square)
- **Resolution**: 1080 x 1080 pixels minimum
- **Additional Requirements**: White background often performs best

### Carousel Ads

**Feed Carousel:**
- **Images**: 2-10 cards
- **Aspect Ratio**: 1:1 (recommended)
- **Resolution**: 1080 x 1080 pixels per card
- **File Type**: JPG or PNG
- **File Size**: Maximum 30 MB per card
- **Headlines**: Up to 40 characters per card
- **Descriptions**: Up to 20 words per card
- **Best Practice**: Maintain visual continuity across cards

**Story Carousel:**
- **Images**: 2-10 cards
- **Aspect Ratio**: 9:16 (vertical)
- **Resolution**: 1080 x 1920 pixels
- **Auto-advance**: 5-7 seconds per card
- **Design Tip**: Use sequential storytelling

### Video Ads

**Feed Video:**
- **Aspect Ratio**: 
  - 1:1 (square) - recommended for most campaigns
  - 4:5 (vertical) - higher engagement on mobile
  - 16:9 (landscape) - less recommended
- **Resolution**: 
  - Minimum: 720p
  - Recommended: 1080p
  - Maximum: 4K (3840 x 2160)
- **Duration**: 
  - Minimum: 1 second
  - Recommended: 15-60 seconds
  - Maximum: 241 minutes
- **File Type**: MP4 or MOV (H.264 compression)
- **File Size**: Maximum 4 GB
- **Frame Rate**: 30 fps recommended
- **Audio**: Stereo AAC, 128kbps+
- **Captions**: Required for accessibility (auto-generated available)

**Story Video:**
- **Aspect Ratio**: 9:16 (full-screen vertical)
- **Resolution**: 1080 x 1920 pixels
- **Duration**: 
  - Recommended: 6-15 seconds
  - Maximum: 120 seconds
- **File Type**: MP4 or MOV
- **File Size**: Maximum 4 GB
- **Frame Rate**: 30 fps
- **Sound**: Design for sound-off first, sound-on enhancement
- **Text Overlays**: Essential for story viewing behavior

**Reel Ads:**
- **Aspect Ratio**: 9:16 (vertical, mobile-first)
- **Resolution**: 1080 x 1920 pixels minimum
- **Duration**: 
  - Recommended: 9-30 seconds
  - Maximum: 90 seconds
- **File Type**: MP4 or MOV
- **Audio**: Trending audio significantly boosts performance
- **Style**: Native creator aesthetic (not overly produced)
- **Hook**: Must grab attention in first 1-2 seconds
- **Looping**: Design for seamless loop

**In-Stream Video:**
- **Aspect Ratio**: 16:9 (landscape)
- **Resolution**: 1080 x 1920 recommended
- **Duration**: 5-15 seconds (mid-roll ads)
- **File Type**: MP4 or MOV
- **Note**: Users watching video content; less skip behavior

### Video Best Practices by Length

**6 seconds or less:**
- Single message delivery
- Brand recognition play
- Bumper ad strategy
- Use cases: Retargeting, frequency campaigns

**15 seconds:**
- Quick problem/solution
- Product demonstration
- Single feature highlight
- Use cases: Most conversion campaigns

**30 seconds:**
- Story arc with setup/payoff
- Multiple product features
- Testimonial with context
- Use cases: Consideration campaigns

**60+ seconds:**
- Deep product education
- Brand storytelling
- Complex solutions
- Use cases: High-ticket items, B2B

### Collection Ads

**Cover Media:**
- **Format**: Video or image
- **Video**: 15 seconds recommended
- **Image**: 1:1 ratio, 1080 x 1080
- **Purpose**: Hero visual to attract attention

**Product Cards:**
- **Count**: 4-50 products
- **Image Format**: 1:1, minimum 500 x 500
- **Auto-populate**: From product catalog
- **Layout Options**: Grid or lifestyle

**Instant Experience:**
- **Load Time**: < 3 seconds
- **Mobile-optimized**: Full-screen, immersive
- **Components**: Images, videos, carousels, product feeds
- **CTA Buttons**: Multiple strategic placements

### Dynamic Ads (Catalog)

**Product Images:**
- **Aspect Ratio**: 1:1 (square)
- **Resolution**: 1024 x 1024 minimum
- **Background**: White or transparent
- **File Type**: JPG or PNG
- **Consistency**: Maintain style across catalog
- **Lifestyle Images**: Show product in use when possible

**Carousel from Catalog:**
- **Auto-generated**: Based on user behavior
- **Personalization**: Products viewed/carted
- **Cross-sell**: Related products shown
- **Template**: Design once, applies to all products

## Text Specifications

### Primary Text (Caption)

**Feed:**
- **Character Limit**: 125 characters visible, up to 2,200 total
- **Best Practice**: Front-load key message in first 125
- **Emojis**: Use strategically (2-3 max)
- **Line Breaks**: Use for readability
- **Hashtags**: 3-5 relevant tags

**Story:**
- **Not visible**: Design message into creative
- **Text Overlays**: Burned into video/image
- **Font Size**: Large enough for mobile (36pt+)

### Headline

**Character Limit**: 40 characters (27 recommended)
**Placement**: Below image/video
**Best Practice**: 
- Action-oriented
- Benefit-focused
- Creates urgency
- Examples: "Shop 50% Off", "Get Started Free", "Learn More Today"

### Description

**Character Limit**: 30 characters (18 recommended)
**Placement**: Below headline
**Best Practice**: 
- Expand on headline
- Add specifics
- Secondary CTA
- Examples: "Limited Time Offer", "Join 10K+ Users", "No Credit Card"

### Link Description

**Character Limit**: 30 characters
**Best Practice**: Brand name or domain
**Example**: "YourBrand.com"

### Call-to-Action Button

**Standard Options:**
- Shop Now
- Learn More
- Sign Up
- Download
- Book Now
- Get Offer
- Contact Us
- Apply Now
- Subscribe
- Get Quote

**Selection Guide:**
- **Transactional**: Shop Now, Buy Now
- **Informational**: Learn More, See More
- **Lead Gen**: Sign Up, Get Offer, Get Quote
- **App**: Download, Install Now
- **Service**: Book Now, Contact Us

## Mobile Optimization Requirements

### Critical Mobile Considerations

**Thumb Zone Design:**
- Key elements in lower 2/3 of screen
- CTA easily tappable (minimum 44x44 points)
- Avoid important content in top 250px (Stories)

**Text Legibility:**
- **Minimum Font Size**: 18pt for body, 28pt for headlines
- **Contrast**: 4.5:1 for body text, 3:1 for large text
- **Font Choice**: Sans-serif for mobile readability
- **Text Over Images**: Use overlays for contrast

**Sound-Off Optimization:**
- 85% of mobile users watch without sound
- Text overlays essential for video
- Captions auto-generated or custom
- Visual storytelling > audio dependency

**File Size Optimization:**
- Compress images without quality loss
- Video encoding: H.264, High Profile
- Target bitrate: 5,000-10,000 kbps for video
- Progressive loading for large files

**Loading Speed:**
- First frame loads < 1 second
- Video starts < 2 seconds
- Total creative load < 3 seconds
- Use thumbnail optimization

## Platform-Specific Requirements

### Facebook Feed
- Supports all formats
- Longer storytelling acceptable
- Desktop + mobile delivery
- Link previews auto-generated

### Instagram Feed
- Visual-first platform
- High-quality imagery essential
- Aesthetic consistency with organic posts
- Shopping tags available

### Instagram Stories
- Full-screen vertical
- Swipe-up actions (10K+ followers)
- Interactive elements (polls, questions)
- 24-hour shelf life aesthetic

### Instagram Reels
- Entertainment-first content
- Creator aesthetic (not ads)
- Trending audio crucial
- Younger demographic (18-34)

### Facebook Stories
- Similar to Instagram Stories
- Slightly older demographic
- Less frequent usage
- Lower CPMs

### Messenger
- 1:1 conversation context
- Personalization important
- Direct response expected
- Mobile-only placement

### Audience Network
- Third-party apps and sites
- Simpler creative recommended
- Brand awareness focus
- Automatic optimization

## Advanced Format Options

### Augmented Reality (AR) Ads

**Spark AR Studio:**
- Custom filters and effects
- Try-on experiences (makeup, glasses, clothes)
- File size: < 4 MB
- 3D model optimization required

**Use Cases:**
- Beauty and cosmetics (try-on)
- Fashion and accessories
- Furniture (placement in room)
- Entertainment (face filters)

### Playable Ads

**Interactive Previews:**
- Mini-game or app demo
- HTML5 format
- File size: < 5 MB
- Load time: < 3 seconds

**Best For:**
- Mobile games
- App features demonstration
- High engagement campaigns

### Lead Ads

**Instant Form:**
- Native form within platform
- Auto-populated fields
- Custom questions (max 15)
- Multi-step forms available

**Creative Requirements:**
- Image: 1:1, 1080 x 1080
- Video: 15-60 seconds recommended
- Context card: Explain what they'll get
- Privacy policy: Required link

## File Naming Conventions

**Recommended Structure:**
`[Brand]_[Campaign]_[Format]_[Variant]_[Size].[extension]`

**Example:**
`Acme_Q1Sale_Video_HookA_1080x1920.mp4`

**Benefits:**
- Easy asset management
- Clear A/B test tracking
- Agency-client collaboration
- Archive organization

## Quality Assurance Checklist

### Pre-Upload Validation

**Technical:**
- [ ] File within size limits
- [ ] Correct aspect ratio
- [ ] Minimum resolution met
- [ ] Proper file format
- [ ] Audio levels normalized (-14 LUFS for video)

**Creative:**
- [ ] Brand logo visible
- [ ] CTA clear and prominent
- [ ] Text readable on mobile
- [ ] Safe zones respected
- [ ] Sound-off version tested

**Compliance:**
- [ ] No prohibited content
- [ ] Claims substantiated
- [ ] Disclosures included (if needed)
- [ ] Rights cleared (music, images, talent)
- [ ] Brand guidelines followed

### Meta's Automated Checks

**Ad Review Criteria:**
- Personal attributes (no targeting based on sensitive categories)
- Misleading content
- Low-quality/disruptive content
- Prohibited content (weapons, tobacco, adult content)
- Grammar and profanity

**Rejection Prevention:**
- Avoid sensationalized language
- No before/after images (health/fitness)
- No paused video play buttons
- No misleading CTAs
- Accurate landing page match

## Creative Specs Quick Reference

### Most Common Formats

| Format | Aspect Ratio | Resolution | Duration | File Size |
|--------|--------------|------------|----------|-----------|
| Feed Image | 1:1 or 4:5 | 1080x1080 | N/A | 30 MB |
| Feed Video | 1:1 or 4:5 | 1080x1080 | 15-60s | 4 GB |
| Story Image | 9:16 | 1080x1920 | N/A | 30 MB |
| Story Video | 9:16 | 1080x1920 | 6-15s | 4 GB |
| Reel Video | 9:16 | 1080x1920 | 9-30s | 4 GB |
| Carousel | 1:1 | 1080x1080 | N/A | 30 MB/card |

### Emergency Specs (When You Need to Ship Fast)

**Minimum Viable Creative:**
- 1 Feed image (1:1, 1080x1080)
- 1 Story image (9:16, 1080x1920)
- Clear offer in creative
- Text overlays for sound-off
- Strong CTA button

**Scale-Up Priority:**
1. Add Feed video (repurpose Story creative)
2. Create carousel (break up single image story)
3. Add Reel video (recut Feed video)
4. Test variations of winners

## Format Selection Decision Tree

```
Start: What's your campaign objective?

├─ Awareness
│  ├─ New audience? → Reel Video (entertainment-first)
│  └─ Brand building? → Feed Video (storytelling)
│
├─ Consideration
│  ├─ Multiple products? → Carousel
│  ├─ Feature demo? → Feed Video
│  └─ Social proof? → Story Video (testimonials)
│
└─ Conversion
   ├─ Clear offer? → Feed Image (direct)
   ├─ Lead magnet? → Lead Ad form
   └─ Retargeting? → Dynamic Catalog Ad
```

## Accessibility Requirements

### WCAG 2.1 Compliance

**Visual:**
- Color contrast: 4.5:1 for text
- No color-only information
- Alt text for images
- Captions for videos

**Audio:**
- Captions/subtitles provided
- Audio descriptions for key visual info
- Clear speech (not too fast)
- Background music < speech volume

### Meta's Accessibility Tools

**Automatic:**
- Auto-generated captions (95% accuracy)
- Alt text suggestions
- Screen reader optimization

**Manual:**
- Custom caption upload (SRT file)
- Audio descriptions
- Alternative text editing
