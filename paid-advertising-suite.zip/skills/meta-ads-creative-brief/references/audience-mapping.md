# Audience Mapping to Creative Decisions

## Audience Analysis Framework

### Demographic-Driven Creative Decisions

#### Age-Based Creative Guidelines

**Gen Z (18-24):**
- **Visual Style**: Bold colors, fast cuts, text-heavy, meme-aware
- **Format Preference**: Reels (9:16), TikTok-style, short-form (9-15s)
- **Messaging**: Authentic, transparent, socially conscious
- **Hook Strategy**: Trending audio, challenges, relatable humor
- **Trust Signals**: Peer reviews, creator endorsements, transparency
- **Avoid**: Corporate polish, hard sells, lengthy explanations
- **Example**: "POV: You just discovered [product]" format

**Millennials (25-34):**
- **Visual Style**: Aspirational lifestyle, clean aesthetics, storytelling
- **Format Preference**: Feed video (1:1), Stories, carousels
- **Messaging**: Value-focused, convenience, experience over things
- **Hook Strategy**: Problem-solution, "hack" content, transformation
- **Trust Signals**: Reviews, influencer partnerships, social proof
- **Avoid**: Outdated references, assumption of tech illiteracy
- **Example**: "How I [achieved result] in [timeframe]" narrative

**Gen X (35-44):**
- **Visual Style**: Professional, clear hierarchy, straightforward
- **Format Preference**: Feed video (detailed), image with text
- **Messaging**: ROI-focused, time savings, quality of life
- **Hook Strategy**: Direct benefits, before/after, testimonials
- **Trust Signals**: Expert endorsements, certifications, guarantees
- **Avoid**: Trend-chasing, assumptions of digital nativity
- **Example**: "Finally, a [solution] that actually works"

**Baby Boomers (45-54):**
- **Visual Style**: Clean, uncluttered, larger text, clear CTAs
- **Format Preference**: Static images, longer videos with narration
- **Messaging**: Reliability, customer service, detailed information
- **Hook Strategy**: Trust-building, authority, legacy
- **Trust Signals**: Established brands, professional certifications
- **Avoid**: Slang, fast pacing, assumed tech comfort
- **Example**: "Trusted by [X] customers since [year]"

**Seniors (55+):**
- **Visual Style**: Simple, high contrast, minimal effects
- **Format Preference**: Static images, narrated videos
- **Messaging**: Security, simplicity, support availability
- **Hook Strategy**: Problem-solving, ease of use, customer care
- **Trust Signals**: Established reputation, phone support, endorsements
- **Avoid**: Complex navigation, small text, rapid changes
- **Example**: "Simple [solution] with personal support"

#### Gender-Based Nuances

**Women (Primary Decision Makers):**
- **Messaging**: Community, relationships, practical benefits
- **Visual Style**: Warm colors, people-focused, detailed
- **Social Proof**: Testimonials from similar personas
- **Hook Strategy**: Emotional connection, transformation stories
- **Purchase Triggers**: Reviews, recommendations, guarantees

**Men (Primary Decision Makers):**
- **Messaging**: Performance, specs, competitive advantage
- **Visual Style**: Bold, action-oriented, technical
- **Social Proof**: Stats, expert opinions, rankings
- **Hook Strategy**: Problem-solution, efficiency gains
- **Purchase Triggers**: Features, comparisons, authority

**Note**: Avoid stereotyping; test both approaches with all audiences.

#### Income-Level Creative Strategy

**Budget-Conscious (<$50K household):**
- **Messaging**: Savings, value, affordability, payment plans
- **Offers**: Discounts, bundles, financing options
- **Hook Strategy**: Price anchoring, "Save $X", comparison
- **Proof Elements**: Value for money, durability, warranty
- **Avoid**: Luxury positioning, exclusivity messaging

**Middle Income ($50K-$150K):**
- **Messaging**: Smart shopping, quality-price balance, lifestyle
- **Offers**: Quality at fair price, occasional premium
- **Hook Strategy**: Best value, "Worth it", smart choice
- **Proof Elements**: Reviews, ROI, time savings
- **Avoid**: Too cheap (quality concerns) or too expensive

**High Income ($150K+):**
- **Messaging**: Exclusivity, premium quality, time savings
- **Offers**: Luxury experience, VIP access, convenience
- **Hook Strategy**: "For those who", status signals, curated
- **Proof Elements**: Prestige brands, expert curation, scarcity
- **Avoid**: Budget messaging, mass market positioning

### Psychographic-Driven Creative

#### Buyer Psychology Segments

**Early Adopters:**
- **Creative Focus**: Innovation, "first to", cutting-edge
- **Visual Style**: Futuristic, tech-forward, sleek
- **Messaging**: "The future of [category]", "Next generation"
- **Hook Strategy**: New launch, revolutionary, breakthrough
- **Social Proof**: Tech reviewers, industry experts
- **CTA**: "Be the first", "Get early access"

**Skeptical Buyers:**
- **Creative Focus**: Transparency, proof, guarantees
- **Visual Style**: Professional, detailed, authentic
- **Messaging**: Address objections directly, show evidence
- **Hook Strategy**: "The truth about", myth-busting
- **Social Proof**: Third-party reviews, studies, testimonials
- **CTA**: "Try risk-free", "See proof", "Money-back guarantee"

**Convenience Seekers:**
- **Creative Focus**: Speed, ease, simplicity, automation
- **Visual Style**: Clean, minimal steps, time-saving visual
- **Messaging**: "In just [X] minutes", "Zero hassle"
- **Hook Strategy**: Time saved, effortless, simple solution
- **Social Proof**: "Saves [X] hours per week"
- **CTA**: "Get instant access", "Start in 60 seconds"

**Status Conscious:**
- **Creative Focus**: Exclusivity, prestige, social signaling
- **Visual Style**: Luxury aesthetics, curated, aspirational
- **Messaging**: "Join the elite", "Exclusive to"
- **Hook Strategy**: Limited availability, VIP access
- **Social Proof**: Celebrity/influencer use, waiting lists
- **CTA**: "Apply now", "Exclusive access", "Limited spots"

**Value Hunters:**
- **Creative Focus**: ROI, savings, smart shopping
- **Visual Style**: Price comparisons, savings callouts
- **Messaging**: "Save $X", "Get more for less"
- **Hook Strategy**: Deal alerts, limited-time savings
- **Social Proof**: Price comparisons, savings calculations
- **CTA**: "Claim savings", "Get deal", "Shop sale"

**Community Oriented:**
- **Creative Focus**: Belonging, shared values, collective
- **Visual Style**: People-focused, diverse representation
- **Messaging**: "Join [X] others", "Part of the community"
- **Hook Strategy**: Movement language, inclusivity
- **Social Proof**: User-generated content, member stories
- **CTA**: "Join us", "Be part of", "Connect with"

### Behavioral-Driven Creative

#### Purchase Stage Mapping

**Problem Unaware (Cold):**
- **Objective**: Awareness
- **Creative Strategy**: 
  - Educate on problem existence
  - Show pain point they didn't know existed
  - Create "aha moment"
- **Hook**: "Did you know [surprising stat]?"
- **Format**: Story/Reel (entertainment value)
- **CTA**: "Learn more", "Discover how"
- **Example**: "Most people don't realize [problem]..."

**Problem Aware (Warm):**
- **Objective**: Consideration
- **Creative Strategy**:
  - Position your solution to their known problem
  - Show multiple benefits
  - Build credibility
- **Hook**: "Struggling with [problem]?"
- **Format**: Feed video (demonstration)
- **CTA**: "See how it works", "Get solution"
- **Example**: "The [solution] that solves [problem]"

**Solution Aware (Hot):**
- **Objective**: Conversion
- **Creative Strategy**:
  - Direct comparison/differentiation
  - Remove final objections
  - Create urgency
- **Hook**: "Why [X people] choose us over [competitor]"
- **Format**: Feed image/carousel (direct)
- **CTA**: "Shop now", "Get started", "Buy now"
- **Example**: "Get [benefit] without [objection]"

**Product Aware (Retargeting):**
- **Objective**: Conversion/Re-engagement
- **Creative Strategy**:
  - Remind of specific benefits
  - Show what they're missing
  - Limited-time offer
- **Hook**: "Still thinking about [product]?"
- **Format**: Dynamic catalog, carousel
- **CTA**: "Complete purchase", "Get [X]% off"
- **Example**: "Your [product] is waiting..."

#### Engagement-Based Segments

**Profile Visitors:**
- **Creative**: Soft sell, brand story, values alignment
- **Messaging**: "Get to know us", behind-the-scenes
- **Hook**: Content they engaged with previously
- **CTA**: "Follow for more", "Join our community"

**Content Engagers:**
- **Creative**: Related content, similar topics
- **Messaging**: Deepen relationship, provide value
- **Hook**: "Since you liked [topic]..."
- **CTA**: "Learn more", "Discover more"

**Website Visitors (Non-Purchasers):**
- **Creative**: Address abandonment reasons
- **Messaging**: Overcome objections, add urgency
- **Hook**: "Forgot something?", "Still available"
- **CTA**: "Complete order", "Get discount"

**Past Purchasers:**
- **Creative**: Loyalty rewards, new products, upsells
- **Messaging**: VIP treatment, exclusive access
- **Hook**: "Just for our customers"
- **CTA**: "Shop new arrivals", "Get VIP offer"

### Interest-Based Creative Optimization

#### Lifestyle Interests

**Fitness Enthusiasts:**
- **Visual Style**: Active lifestyle, before/after, movement
- **Messaging**: Performance, results, goals achievement
- **Hook Strategy**: Transformation, "Get [physique/ability]"
- **Colors**: Energetic (red, orange, blue)
- **Music/Audio**: Upbeat, motivational

**Foodies:**
- **Visual Style**: Close-ups, vibrant colors, food styling
- **Messaging**: Taste, experience, convenience, discovery
- **Hook Strategy**: "You have to try", mouth-watering visuals
- **Colors**: Warm, appetizing (yellow, orange, red)
- **Proof**: Reviews, ratings, chef endorsements

**Travelers:**
- **Visual Style**: Destinations, adventure, wanderlust
- **Messaging**: Escape, experience, memories, ease
- **Hook Strategy**: "Discover", "Explore", "Experience"
- **Colors**: Blues, greens, earth tones
- **Proof**: User photos, destination ratings

**Tech Enthusiasts:**
- **Visual Style**: Product focus, specs display, innovation
- **Messaging**: Features, performance, cutting-edge
- **Hook Strategy**: "The tech you've been waiting for"
- **Colors**: Black, white, blue (tech aesthetic)
- **Proof**: Specs, comparisons, reviews

**Parents:**
- **Visual Style**: Family scenes, real-life situations
- **Messaging**: Safety, convenience, child development
- **Hook Strategy**: "Make parenting easier", peace of mind
- **Colors**: Soft, trustworthy (blue, green, neutral)
- **Proof**: Parent testimonials, safety certifications

### Audience Size & Creative Strategy

**Broad Audiences (1M+):**
- **Creative Approach**: Universal messaging, wide appeal
- **Testing Strategy**: Large variant volume (10+ creatives)
- **Refresh Cadence**: Weekly (high frequency risk)
- **Format Mix**: All formats (algorithm optimization)

**Mid-Size Audiences (100K-1M):**
- **Creative Approach**: Segment-specific messaging
- **Testing Strategy**: 5-7 creative variants
- **Refresh Cadence**: Bi-weekly
- **Format Mix**: Focus on 2-3 top-performing formats

**Niche Audiences (<100K):**
- **Creative Approach**: Hyper-personalized, insider language
- **Testing Strategy**: 3-4 variants max (limited volume)
- **Refresh Cadence**: Monthly (avoid frequency burnout)
- **Format Mix**: 1-2 formats (preserve learning phase)

## Lookalike Audience Creative Strategy

### 1% Lookalike (Highest Quality)
- **Seed**: Best customers (high LTV)
- **Creative**: Premium positioning, quality focus
- **Messaging**: Align with best customer motivations
- **Example**: "For serious [category] enthusiasts"

### 5% Lookalike (Balanced)
- **Seed**: All purchasers
- **Creative**: Broader appeal with differentiation
- **Messaging**: Clear value prop, multiple benefits
- **Example**: "The [category] choice for [X] people"

### 10% Lookalike (Broad Reach)
- **Seed**: All engaged users
- **Creative**: Mass appeal, simple messaging
- **Messaging**: Universal benefits, accessibility
- **Example**: "Everyone's talking about [product]"

## Audience Insight Sources

### Platform Data (Meta Audience Insights)
- Demographics: Age, gender, location
- Interests: Pages liked, behaviors
- Device usage: Mobile vs desktop
- Purchase behavior: High-intent indicators

### First-Party Data
- Customer surveys: Voice of customer
- Purchase history: What they actually buy
- Support tickets: Pain points and objections
- Email engagement: Content preferences

### Third-Party Research
- Market research reports: Category insights
- Competitor analysis: Who they target successfully
- Social listening: Conversation themes
- Review analysis: Common praise/complaints

## Creative Personalization Matrix

| Audience Attribute | Creative Element to Personalize |
|-------------------|----------------------------------|
| Age | Visual style, pacing, cultural references |
| Income | Offer type, messaging tone, product tier |
| Location | Local references, weather, regional language |
| Gender | Product use cases, testimonials, benefits emphasis |
| Life Stage | Relevant scenarios, time references, priorities |
| Interests | Visual style, product positioning, proof types |
| Purchase History | Product recommendations, loyalty messaging |
| Device | Video orientation, text size, loading speed |

## A/B Testing by Audience Segment

**Test Priorities by Audience:**

**New/Cold Audiences:**
1. Hook testing (highest impact)
2. Format testing
3. Length testing
4. Message testing (last)

**Warm Audiences:**
1. Message testing (they know you exist)
2. Offer testing
3. Social proof testing
4. CTA testing

**Retargeting Audiences:**
1. Offer testing (price sensitivity high)
2. Objection handling
3. Urgency mechanisms
4. Product variations

## Dynamic Creative Optimization (DCO) by Audience

Meta's DCO can automatically match creative elements to audiences:

**Elements to Provide:**
- 5-10 images/videos (varied style and tone)
- 5 headlines (varied benefit emphasis)
- 5 descriptions (varied objections addressed)
- 3 CTAs (varied urgency levels)

**Meta Matches:**
- Younger audiences → faster-paced videos
- Older audiences → static images with detail
- High income → premium imagery
- Value conscious → savings-focused copy

## Audience-Creative Success Metrics

**By Audience Type:**

| Audience | Primary Metric | Secondary Metric | Creative Impact |
|----------|----------------|------------------|-----------------|
| Cold | CTR, CPM | Video completion | Hook strength |
| Warm | Engagement rate | Landing page views | Message clarity |
| Hot | Conversion rate | ROAS | Offer strength |
| Retargeting | ROAS | Repeat purchase rate | Objection handling |

## Creative Fatigue by Audience

**Frequency Thresholds:**

- **Broad Audiences**: Fatigue at 3+ frequency
- **Niche Audiences**: Fatigue at 2+ frequency
- **Retargeting**: Fatigue at 5+ frequency (higher tolerance)

**Fatigue Signals:**
- CTR drops >25%
- CPM increases >50%
- Relevance score decreases
- Negative feedback increases

**Refresh Strategies:**
- New hook, same message (fastest)
- New format, same concept (medium effort)
- Completely new concept (most effective)

## Audience Exclusions & Creative Strategy

**Exclude from Creative:**
- Recent purchasers (unless upselling)
- Job seekers (if not hiring)
- Competitors (if possible to identify)
- Loyalty program members (different messaging)

**Benefit**: Allows focused creative for acquisition without wasting impressions on non-qualified audiences.
