# Creative Strategy Framework

## Strategic Planning Process

### Phase 1: Objective Alignment

**Campaign Objective Categories:**

1. **Awareness**
   - Goal: Reach and impressions
   - Creative Focus: Brand story, product education, category creation
   - Hook Strategy: Pattern interrupts, curiosity gaps, bold statements
   - Success Metrics: Reach, impressions, video views, brand lift

2. **Consideration**
   - Goal: Engagement and interest
   - Creative Focus: Product benefits, differentiation, social proof
   - Hook Strategy: Problem/solution, transformation, "how to"
   - Success Metrics: Engagement rate, video completion, link clicks, saves

3. **Conversion**
   - Goal: Actions and sales
   - Creative Focus: Offers, urgency, clear CTAs, objection handling
   - Hook Strategy: Direct offers, time limits, exclusive access
   - Success Metrics: CTR, conversion rate, ROAS, CPA

### Phase 2: Audience-Creative Mapping

**Audience Attributes to Creative Decisions:**

| Audience Trait | Creative Implication |
|----------------|---------------------|
| Age: 18-24 | Fast-paced, trending audio, text overlays, meme format |
| Age: 25-34 | Aspirational lifestyle, clear value props, testimonials |
| Age: 35-44 | Problem-solution, ROI focus, authority signals |
| Age: 45-54 | Trust signals, detailed info, professional tone |
| Age: 55+ | Simple messaging, larger text, clear benefits |
| High income | Premium aesthetics, exclusivity, sophisticated copy |
| Budget conscious | Price anchoring, savings focus, comparison content |
| Early adopters | Innovation angle, "first to" messaging, tech specs |
| Skeptical buyers | Social proof heavy, guarantees, transparent pricing |

**Psychographic Mapping:**

- **Convenience Seekers**: Show speed, ease, time savings
- **Status Conscious**: Emphasize exclusivity, premium positioning
- **Value Hunters**: Lead with savings, ROI, smart shopping
- **Community Oriented**: Feature user content, testimonials, belonging
- **Self-Improvers**: Highlight transformation, growth, achievement

### Phase 3: Hook Strategy Selection

**The 3-Second Rule:**
Meta ads have ~3 seconds to stop scroll. Your hook must:
- Create pattern interrupt (visual or auditory)
- Promise clear value
- Trigger curiosity or emotion
- Be thumb-stopping on mobile

**Hook Frameworks by Objective:**

**Awareness Hooks:**
1. Unexpected Visual: Show something surprising or unusual
2. Bold Statement: Make a controversial or attention-grabbing claim
3. Question: Pose a curiosity-inducing question
4. Pattern Interrupt: Break visual expectations
5. Story Opening: Start with "I never thought..." or "What if..."

**Consideration Hooks:**
1. Problem Callout: "Tired of [pain point]?"
2. Transformation: Before/after visual
3. How To: "The [simple/secret/proven] way to..."
4. Social Proof: "Why [X people] are switching to..."
5. Myth Busting: "Everything you know about [X] is wrong"

**Conversion Hooks:**
1. Direct Offer: "[X]% off [product] this week only"
2. Urgency: "Last chance" / "Ending soon"
3. Scarcity: "Only [X] left" / "Limited spots"
4. Exclusive Access: "VIP early access"
5. Risk Reversal: "Try free" / "Money-back guarantee"

### Phase 4: Message Architecture

**The Creative Pyramid:**

```
         HOOK (0-3s)
        Clear benefit
      
      VALUE PROP (3-7s)
    Why this matters to them
  
    PROOF/TRUST (7-12s)
  Social proof, testimonials
  
      CTA (12-15s)
  Clear next step + urgency
```

**Message Hierarchy Rules:**

1. **Primary Message**: The ONE thing you want them to remember
   - State in first 3 seconds
   - Repeat visually and verbally
   - Make it benefit-focused, not feature-focused

2. **Supporting Points**: 2-3 reinforcing elements
   - Social proof (X customers, testimonials)
   - Unique differentiator (what competitors can't claim)
   - Risk mitigation (guarantee, free trial)

3. **Call to Action**: The specific next step
   - Use action verbs (Get, Try, Start, Join, Claim)
   - Add urgency when appropriate (Today, Now, Limited)
   - Make it crystal clear and easy

### Phase 5: Creative Concepting

**Concept Development Framework:**

**Concept = Hook + Format + Message**

Example Concept Matrix:

| Hook Type | Format | Message Angle | Concept |
|-----------|--------|---------------|---------|
| Transformation | Photo Carousel | Before/After | 5-image journey showing customer transformation |
| Problem Callout | Story Video | Pain Point Focus | 15s video dramatizing frustration, then solution |
| Social Proof | Feed Image | Trust Building | Customer testimonial with results callout |

**Multi-Variant Strategy:**

For A/B testing, vary ONE element:
- **Hook Testing**: Same message, different opening hooks
- **Format Testing**: Same concept, different formats (video vs carousel)
- **Message Testing**: Same hook, different value propositions
- **Audience Testing**: Same creative, different audience segments

### Phase 6: Platform Optimization

**Feed Ads Strategy:**
- Longer storytelling (up to 60s video)
- Text overlays for sound-off viewing
- Strong first frame (video thumbnail)
- Detailed captions for context

**Story Ads Strategy:**
- Vertical format native to Stories
- Fast-paced (5-15s max)
- Interactive elements (polls, swipe-ups)
- Bold, simple visuals

**Reel Ads Strategy:**
- Entertainment-first approach
- Trending audio and effects
- Native creator aesthetic (not overly polished)
- Hook in first 1-2 seconds

## Creative Testing Methodology

### Structured Creative Testing

**Phase 1: Hook Testing (Week 1-2)**
- Test 3-5 different hooks with same body/CTA
- Budget: Equal split
- Winner: Highest CTR + lowest CPA

**Phase 2: Message Testing (Week 3-4)**
- Test 2-3 value propositions with winning hook
- Budget: Equal split
- Winner: Highest conversion rate

**Phase 3: Format Testing (Week 5-6)**
- Test winning concept across formats
- Budget: Weighted by audience size
- Winner: Best ROAS

### Creative Refresh Triggers

Replace/refresh creative when:
- Frequency > 3.0 (audience fatigued)
- CTR drops > 25% from baseline
- Creative has run > 30 days
- CPM increases > 50% without seasonal explanation
- Ad relevance score < 6

## Budget Allocation by Creative Approach

**Testing Budget Recommendations:**

- **Small Budget** (<$5K/month): 2-3 concepts max, focus on one format
- **Medium Budget** ($5K-$25K/month): 3-5 concepts, test 2 formats
- **Large Budget** ($25K-$100K/month): 5-10 concepts, test all formats
- **Enterprise Budget** (>$100K/month): 10+ concepts, platform-specific strategies

**Creative Production Budget:**

| Format | DIY/Low Cost | Professional | Premium |
|--------|--------------|--------------|---------|
| Static Image | $0-100 | $500-2,000 | $2,000-10,000 |
| Carousel | $0-200 | $1,000-3,000 | $3,000-15,000 |
| Video (Feed) | $100-500 | $2,000-10,000 | $10,000-50,000 |
| Video (Story/Reel) | $50-200 | $1,000-5,000 | $5,000-25,000 |
| UGC Content | $100-300 | $500-2,000 | $2,000-10,000 |

## Industry-Specific Strategies

### E-commerce/DTC
- Product-focused visuals with lifestyle context
- Clear pricing and offer in creative
- Multiple product shots (carousel)
- UGC and review content
- Urgency and scarcity tactics

### B2B/SaaS
- Problem-solution narrative
- Screen recordings of product
- ROI and time savings focus
- Testimonials from recognizable brands
- Free trial or demo CTAs

### Lead Generation
- Value proposition in first 3s
- Lead magnet clearly showcased
- Trust signals (privacy, no spam)
- Form preview or ease of sign-up
- Follow-up experience teased

### App Install
- Actual app footage
- Core benefit demonstrated quickly
- User testimonials/ratings
- Clear app store badges
- Gamification of onboarding

### Local Business
- Location-specific imagery
- Local testimonials and reviews
- Proximity messaging
- Service before/afters
- Seasonal relevance

## Performance Benchmarks

**By Objective (Median Performance):**

| Objective | CTR Benchmark | CPC Benchmark | Conversion Rate |
|-----------|---------------|---------------|-----------------|
| Awareness | 0.5-1.5% | $0.30-$1.50 | N/A |
| Consideration | 1.0-3.0% | $0.50-$2.00 | N/A |
| Conversion | 1.5-4.0% | $0.75-$3.00 | 2-10% |

**By Format:**

| Format | Average CTR | Best Use Case |
|--------|-------------|---------------|
| Single Image | 0.9% | Simple message, strong visual |
| Carousel | 1.2% | Multiple products, storytelling |
| Video (Feed) | 1.5% | Demonstration, transformation |
| Video (Story) | 2.0% | Quick hooks, mobile-first |
| Video (Reel) | 2.5% | Entertainment, younger audience |

## Creative Quality Checklist

**Pre-Production:**
- [ ] Hook identified and validated
- [ ] Message hierarchy defined
- [ ] Format selected based on objective
- [ ] Technical specs confirmed
- [ ] Brand guidelines reviewed

**Production:**
- [ ] Mobile-first design (90% of views)
- [ ] Sound-off optimization (text overlays)
- [ ] Captions reviewed for accessibility
- [ ] First 3 seconds tested separately
- [ ] Multiple variants created

**Post-Production:**
- [ ] File sizes optimized
- [ ] Dimensions correct for placements
- [ ] Brand safety review completed
- [ ] A/B test variants prepared
- [ ] Tracking parameters set up

## Advanced Techniques

### Dynamic Creative Optimization (DCO)
- Upload multiple hooks, images, headlines, descriptions
- Meta's algorithm tests combinations
- Delivers best-performing variants automatically
- Best for large budgets ($5K+/month per campaign)

### Catalog Ads
- Product feed integration
- Automatic retargeting of viewed products
- Template-based creative
- Personalized recommendations

### Advantage+ Creative
- Automated enhancement of static images
- Multiple aspect ratios generated
- Template variations tested
- Best for catalog and conversion campaigns

### UGC at Scale
- Creator marketplace integration
- Consistent brief templates
- Rights management process
- Performance-based creator selection
