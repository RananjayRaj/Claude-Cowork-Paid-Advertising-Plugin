# Creative Brief Templates

## Template Selection Guide

Choose the template that matches your use case:

- **Full Creative Brief**: Comprehensive handoff to designers (recommended)
- **Executive Summary**: Stakeholder alignment and approvals
- **Quick Brief**: Fast-turnaround campaigns
- **Technical Spec Sheet**: Production team requirements only
- **Multi-Variant Brief**: A/B testing multiple concepts

---

## Template 1: Full Creative Brief

```markdown
# Creative Brief: [Campaign Name]

**Date**: [Date]
**Campaign Owner**: [Name]
**Designer(s)**: [Name(s)]
**Due Date**: [Date]

---

## 1. Campaign Overview

### Objective
[Primary campaign goal - awareness, consideration, conversion]

### Target KPIs
- [Metric 1]: [Target]
- [Metric 2]: [Target]
- [Metric 3]: [Target]

### Campaign Timeline
- **Launch Date**: [Date]
- **End Date**: [Date]
- **Duration**: [X weeks]

### Budget
- **Total**: $[Amount]
- **Per Creative Set**: $[Amount]
- **Production Budget**: $[Amount]

---

## 2. Target Audience

### Primary Audience
- **Demographics**: [Age range, gender, location, income]
- **Psychographics**: [Values, interests, behaviors]
- **Digital Behavior**: [Platform usage, content preferences]

### Audience Insights
**Pain Points:**
1. [Pain point 1 - describe frustration]
2. [Pain point 2 - describe challenge]
3. [Pain point 3 - describe need]

**Motivations:**
1. [Motivation 1 - what drives them]
2. [Motivation 2 - what they want to achieve]
3. [Motivation 3 - what they value]

**Content Preferences:**
- [What content they engage with]
- [How they consume content]
- [When they're most active]

### Audience Quote
"[A real or representative quote that captures their mindset]"

---

## 3. Creative Strategy

### Big Idea
[One sentence capturing the core creative concept]

### Key Message
[The single most important thing we want them to remember]

### Message Hierarchy
1. **Primary**: [Main benefit/value proposition]
2. **Secondary**: [Supporting point #1]
3. **Tertiary**: [Supporting point #2]

### Proof Points
- [Proof element 1: social proof, stats, testimonials]
- [Proof element 2: guarantee, certification, etc.]
- [Proof element 3: additional credibility element]

### Call to Action
- **Primary CTA**: [Action verb + benefit]
- **Secondary CTA**: [Alternative action if available]
- **Urgency Element**: [Time limit, scarcity, exclusive access]

---

## 4. Creative Concepts

### Concept A: [Concept Name]
**Hook Strategy**: [How we'll stop the scroll in 3 seconds]
**Visual Approach**: [Describe the look and feel]
**Message Angle**: [What value proposition we're leading with]
**Format**: [Feed video, Story, Reel, etc.]

### Concept B: [Concept Name]
**Hook Strategy**: [Alternative hook]
**Visual Approach**: [Alternative style]
**Message Angle**: [Alternative value prop]
**Format**: [Format]

### Concept C: [Concept Name]
**Hook Strategy**: [Third hook option]
**Visual Approach**: [Third style option]
**Message Angle**: [Third value prop angle]
**Format**: [Format]

---

## 5. Format Specifications

### Required Assets

#### Feed Image Ad
- **Quantity**: [X variants]
- **Aspect Ratio**: 1:1 (square) or 4:5 (vertical)
- **Resolution**: 1080 x 1080px or 1080 x 1350px
- **File Format**: JPG or PNG
- **Special Requirements**: [Any specific needs]

#### Feed Video Ad
- **Quantity**: [X variants]
- **Aspect Ratio**: 1:1 or 4:5
- **Resolution**: 1080 x 1080px minimum
- **Duration**: [15s / 30s / 60s]
- **File Format**: MP4 (H.264)
- **Audio**: [Music style, voiceover Y/N]
- **Captions**: Required (burned in)

#### Story Ad
- **Quantity**: [X variants]
- **Aspect Ratio**: 9:16 (vertical)
- **Resolution**: 1080 x 1920px
- **Duration**: [6-15s recommended]
- **Safe Zones**: Keep content 250px from top/bottom
- **Text**: [Overlay specifications]

#### Reel Ad
- **Quantity**: [X variants]
- **Aspect Ratio**: 9:16 (vertical)
- **Resolution**: 1080 x 1920px
- **Duration**: [9-30s recommended]
- **Style**: [Creator aesthetic vs polished]
- **Audio**: [Trending sound vs original]

#### Carousel Ad
- **Quantity**: [X carousels]
- **Cards Per Carousel**: [2-10 cards]
- **Aspect Ratio**: 1:1 per card
- **Resolution**: 1080 x 1080px per card
- **Storytelling**: [Sequential narrative vs standalone cards]

---

## 6. Design Guidelines

### Visual Style
- **Aesthetic**: [Modern, minimalist, bold, playful, luxury, etc.]
- **Color Palette**: [Primary colors to use]
- **Typography**: [Font styles and hierarchy]
- **Imagery Style**: [Photography style, illustration, 3D, etc.]

### Brand Elements
- **Logo Placement**: [Location and size]
- **Brand Colors**: [Specific hex codes if required]
- **Font Usage**: [Brand fonts if applicable]
- **Don'ts**: [What to avoid from brand perspective]

### Mobile Optimization
- **Text Size**: Minimum 18pt body, 28pt headlines
- **Touch Targets**: CTAs minimum 44x44 points
- **Contrast**: 4.5:1 for body text
- **Testing**: Preview on actual mobile devices

### Sound-Off Design
- **Text Overlays**: [Specifications for burned-in text]
- **Captions**: [Style, placement, readability]
- **Visual Storytelling**: [Must work without audio]

---

## 7. Copy Requirements

### Headlines (40 characters max)
- Option 1: [Headline focusing on benefit]
- Option 2: [Headline creating urgency]
- Option 3: [Headline with social proof]

### Primary Text (125 characters visible)
[Front-loaded key message that works when truncated]
[Full text can expand to 2,200 characters]
[Include emoji if brand-appropriate: ❤️ ⭐ 💯]

### Description (30 characters max)
[Supporting detail or secondary CTA]

### CTA Button
[Shop Now / Learn More / Sign Up / etc.]

---

## 8. Competitive Context

### Competitive Ads Analysis
[Summary of what competitors are doing well]
[Opportunities they're missing that we can exploit]

### Differentiation Strategy
[How our creative will stand out]
[What makes our approach unique]

---

## 9. Success Criteria

### What "Good" Looks Like
- **Performance**: [CTR target, engagement rate, conversion rate]
- **Creative Quality**: [Specific elements that indicate quality]
- **Brand Alignment**: [How we'll know it's on-brand]

### Performance Benchmarks
- **CTR**: [X.X%] (target)
- **Engagement Rate**: [X.X%] (target)
- **Conversion Rate**: [X.X%] (target)
- **ROAS**: [X.X] (target)

### Testing Plan
- **Test Variables**: [What we're testing - hook vs message vs format]
- **Success Criteria**: [How we'll determine winner]
- **Timeline**: [Testing duration]

---

## 10. Assets & Resources

### Reference Materials
- [Link to brand guidelines]
- [Link to product images]
- [Link to competitor ads]
- [Link to inspiration board]

### Stock Asset Access
- [Stock photo account info if needed]
- [Music licensing details]
- [Font licenses]

### Previous Campaign Assets
- [Link to assets from similar campaigns]
- [Performance data from previous creative]

---

## 11. Approval Process

### Review Stakeholders
1. [Name - Role] - [What they're reviewing]
2. [Name - Role] - [What they're reviewing]
3. [Name - Role] - [Final approval]

### Timeline
- **First Draft**: [Date]
- **Feedback Round 1**: [Date]
- **Revisions**: [Date]
- **Final Approval**: [Date]
- **Upload to Ads Manager**: [Date]

### Feedback Process
[How and where to share feedback]
[Response time expectations]

---

## 12. Production Notes

### Technical Requirements
- [File naming conventions]
- [Delivery format and location]
- [Version control process]

### Quality Assurance
- [ ] Aspect ratios correct
- [ ] File sizes within limits
- [ ] Text readable on mobile
- [ ] Safe zones respected
- [ ] Brand guidelines followed
- [ ] Sound-off version tested
- [ ] Captions accurate
- [ ] CTAs clear and prominent

---

## Questions or Concerns?
Contact: [Name, email, phone]
```

---

## Template 2: Executive Summary Brief

```markdown
# Creative Brief: [Campaign Name] - Executive Summary

**Campaign Owner**: [Name]
**Date**: [Date]
**Budget**: $[Amount]

---

## Campaign at a Glance

**Objective**: [One sentence - what we're trying to achieve]

**Target Audience**: [One sentence - who we're reaching]

**Key Message**: [One sentence - what we want them to remember]

**Success Metric**: [Primary KPI with target]

---

## Creative Strategy

### The Big Idea
[2-3 sentences describing the core creative concept]

### Why This Will Work
[2-3 bullets explaining the strategy rationale]
- [Reason 1: audience insight]
- [Reason 2: competitive advantage]
- [Reason 3: proven approach]

---

## Creative Concepts

### Concept A: [Name]
[1 sentence description + expected impact]

### Concept B: [Name]
[1 sentence description + expected impact]

### Concept C: [Name]
[1 sentence description + expected impact]

---

## Formats & Timeline

**Formats**: [List of ad formats]
**Production Timeline**: [X weeks]
**Launch Date**: [Date]

---

## Budget Breakdown

| Item | Cost |
|------|------|
| Creative Production | $[Amount] |
| Media Spend | $[Amount] |
| Total | $[Amount] |

---

## Expected Results

**Target Performance**:
- [Metric 1]: [Target]
- [Metric 2]: [Target]
- [ROI]: [Target]

**Success Criteria**: [How we'll measure success]

---

## Next Steps

1. [Action item with owner and date]
2. [Action item with owner and date]
3. [Action item with owner and date]

---

**Approval**: ☐ Approved ☐ Approved with changes ☐ Needs revision

**Signature**: _________________ **Date**: _________
```

---

## Template 3: Quick Brief (Fast Turnaround)

```markdown
# Quick Brief: [Campaign Name]

**Due Date**: [Date]
**Designer**: [Name]

---

## What We Need
[1-2 sentences describing the assets needed]

## Who It's For
[1 sentence audience description]

## Key Message
[The one thing they should remember]

## Creative Approach
[1-2 sentences on look/feel/concept]

## Formats Required
- [ ] Feed Image (1:1, 1080x1080)
- [ ] Feed Video (1:1, [X]s)
- [ ] Story ([specify])
- [ ] Reel ([specify])

## Copy
**Headline**: [40 characters max]
**Body**: [First 125 characters]
**CTA**: [Button text]

## Must-Haves
- [Required element 1]
- [Required element 2]
- [Required element 3]

## Nice-to-Haves
- [Optional element 1]
- [Optional element 2]

## References
[Links to inspiration, brand guidelines, assets]

---

**Questions?** Contact [Name]
```

---

## Template 4: Technical Spec Sheet

```markdown
# Technical Specifications: [Campaign Name]

## Asset List

### Asset 1: [Format Name]
- **File Name**: [naming convention]
- **Format**: [MP4/JPG/PNG]
- **Dimensions**: [width x height]
- **Aspect Ratio**: [ratio]
- **Duration**: [seconds] (if video)
- **File Size**: Max [X] MB
- **Frame Rate**: [fps] (if video)
- **Audio**: [specs] (if video)
- **Color Space**: [sRGB/etc]
- **Quantity**: [X variants]

### Asset 2: [Format Name]
[Same specifications as above]

---

## Text Elements

### Headlines (Per Variant)
1. [Headline 1] (X characters)
2. [Headline 2] (X characters)
3. [Headline 3] (X characters)

### Primary Text
[Copy for primary text field]

### Description
[Copy for description field]

---

## Design Requirements

### Colors
- Primary: [Hex code]
- Secondary: [Hex code]
- Accent: [Hex code]

### Typography
- Headlines: [Font name, size, weight]
- Body: [Font name, size, weight]
- CTA: [Font name, size, weight]

### Logo
- Placement: [Location]
- Size: [Minimum size]
- Clear space: [Specifications]

---

## Mobile Optimization

- **Minimum Text Size**: 18pt body, 28pt headlines
- **Touch Target Size**: 44x44 points
- **Contrast Ratio**: 4.5:1 minimum
- **Safe Zones**: [Specifications per format]

---

## Delivery

- **Format**: [How files should be delivered]
- **Location**: [Where to upload]
- **Naming**: [File naming convention]
- **Due Date**: [Date and time]

---

## Quality Checklist

- [ ] Correct dimensions and aspect ratio
- [ ] File size within limits
- [ ] Text readable on mobile
- [ ] Safe zones respected
- [ ] Brand guidelines followed
- [ ] Captions included (video)
- [ ] Sound-off version works
- [ ] CTA clear and prominent
- [ ] File naming correct
```

---

## Template 5: Multi-Variant Testing Brief

```markdown
# A/B Test Creative Brief: [Campaign Name]

**Test Objective**: [What we're testing - hook, message, format, etc.]
**Campaign Owner**: [Name]
**Timeline**: [Test duration]

---

## Test Hypothesis

**We believe that**: [Hypothesis statement]
**Will result in**: [Expected outcome]
**Measured by**: [Primary metric]

---

## Control vs Variants

### Control (Baseline)
**Concept**: [Current/control concept]
**Hook**: [Current hook]
**Message**: [Current message]
**Format**: [Current format]
**Current Performance**: [Benchmark metrics]

### Variant A
**Concept**: [Test concept A]
**Hook**: [Test hook A]
**Message**: [Test message A]
**Format**: [Test format A]
**Hypothesis**: [Why we think this will perform better]

### Variant B
**Concept**: [Test concept B]
**Hook**: [Test hook B]
**Message**: [Test message B]
**Format**: [Test format B]
**Hypothesis**: [Why we think this will perform better]

### Variant C
**Concept**: [Test concept C]
**Hook**: [Test hook C]
**Message**: [Test message C]
**Format**: [Test format C]
**Hypothesis**: [Why we think this will perform better]

---

## Test Design

### What We're Changing
[Specific element(s) that vary between versions]

### What Stays the Same
[Elements held constant across all versions]

### Audience
- **Size**: [Total audience size]
- **Split**: [Even split or weighted]
- **Exclusions**: [Any audience exclusions]

### Budget
- **Total**: $[Amount]
- **Per Variant**: $[Amount]
- **Duration**: [X days]

---

## Success Criteria

### Primary Metric
[Metric name]: [Current baseline] → [Target improvement]

### Secondary Metrics
- [Metric 2]: [Baseline] → [Target]
- [Metric 3]: [Baseline] → [Target]

### Statistical Significance
- **Confidence Level**: 95%
- **Minimum Sample Size**: [X conversions/clicks]
- **Test Duration**: [Minimum X days]

---

## Creative Specifications

[Include full specs for each variant following Technical Spec Sheet template]

---

## Analysis Plan

### Decision Framework
**If Variant wins by [X]%**: [Action to take]
**If no clear winner**: [Action to take]
**If Control wins**: [Action to take]

### Next Test
[What we'll test next based on results]

---

## Timeline

- **Brief Complete**: [Date]
- **Assets Delivered**: [Date]
- **Test Launch**: [Date]
- **Test End**: [Date]
- **Results Analysis**: [Date]
- **Decision & Scale**: [Date]
```

---

## Brief Customization Guidelines

### When to Use Each Template

**Full Creative Brief**:
- New campaign launches
- Complex multi-format campaigns
- Agency-client handoffs
- Multiple stakeholder approvals

**Executive Summary**:
- Budget approvals needed
- Quick stakeholder alignment
- Campaign overview for leadership

**Quick Brief**:
- Simple creative refreshes
- Time-sensitive campaigns
- In-house designers familiar with brand

**Technical Spec Sheet**:
- Production house handoffs
- Assets already conceptualized
- Technical teams only

**Multi-Variant Brief**:
- A/B testing programs
- Optimization campaigns
- Performance testing

### Customization Tips

1. **Add Industry-Specific Sections**:
   - E-commerce: Product specs, SKU information
   - B2B: Decision-maker titles, company sizes
   - Local: Location-specific guidelines

2. **Adjust for Team Size**:
   - Solo founders: Combine into one brief
   - Small teams: Quick brief sufficient
   - Agencies: Full brief + technical specs

3. **Scale to Budget**:
   - <$5K: Quick brief
   - $5K-$50K: Full brief
   - >$50K: Full brief + testing brief

4. **Adapt to Cadence**:
   - Always-on: Templates in tools
   - Quarterly: Comprehensive briefs
   - Weekly: Quick briefs + past performance

---

## Brief Best Practices

### Before Writing

1. **Gather Requirements**:
   - Campaign objectives clear?
   - Audience insights available?
   - Budget and timeline confirmed?
   - Brand guidelines accessible?

2. **Review Past Performance**:
   - What creative performed best?
   - What messaging resonated?
   - What formats delivered ROI?

3. **Competitive Analysis**:
   - What are competitors doing?
   - What gaps can we exploit?
   - What's saturating the space?

### While Writing

1. **Be Specific**:
   - ❌ "Make it pop"
   - ✅ "Use high-contrast colors from our brand palette"

2. **Provide Context**:
   - Why this approach?
   - What problem does it solve?
   - How does it fit strategy?

3. **Include Examples**:
   - Link to reference ads
   - Show visual inspiration
   - Provide copy examples

### After Writing

1. **Stakeholder Review**:
   - All requirements captured?
   - Feasible within timeline?
   - Budget realistic?

2. **Designer Feedback**:
   - Clear enough to execute?
   - Any missing information?
   - Technical specs correct?

3. **Archive & Learn**:
   - Save brief with campaign
   - Note what worked/didn't
   - Build brief template library
