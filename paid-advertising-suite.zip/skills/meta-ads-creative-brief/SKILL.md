---
name: meta-ads-creative-brief
description: Generate creative briefs for designers based on campaign objectives, including audience insights, creative guidelines, objective alignment, and format specifications
---

# Meta Ads Creative Brief Generator

Generates comprehensive creative briefs for Meta advertising campaigns that align design teams with campaign objectives, audience insights, and platform requirements.

## How to Use This Skill

### Quick Start
1. Provide campaign context (objective, audience, offer)
2. Specify ad formats needed (Feed, Story, Reel, etc.)
3. Receive a complete creative brief ready to share with designers

### What You'll Need
- Campaign objective (awareness, consideration, conversion)
- Target audience description or persona
- Key message/offer
- Budget/timeline (optional but helpful)
- Existing brand guidelines (if available)

## Core Workflow

When you ask for a creative brief, I'll guide you through:

1. **Campaign Discovery** - Understanding your objectives and constraints
2. **Audience Analysis** - Mapping audience insights to creative decisions
3. **Format Specifications** - Defining technical and creative requirements
4. **Brief Generation** - Creating a designer-ready document

## Brief Components

Each creative brief includes:

### 1. Campaign Overview
- Objective and KPIs
- Target audience profile
- Key message and offer
- Campaign timeline

### 2. Audience Insights
- Demographics and psychographics
- Pain points and motivations
- Content consumption patterns
- Creative preferences by segment

### 3. Creative Strategy
- Hook strategies for stopping scroll
- Value proposition messaging
- Call-to-action guidance
- Brand voice and tone

### 4. Format Specifications
- Technical requirements (dimensions, file sizes, durations)
- Platform best practices (Feed vs Story vs Reel)
- Variant requirements (A/B test concepts)
- Mobile optimization guidelines

### 5. Success Criteria
- What "good" looks like for this campaign
- Performance benchmarks
- Approval process and stakeholders

## Example Requests

**Simple Request:**
"Create a creative brief for a lead generation campaign targeting small business owners for our accounting software."

**Detailed Request:**
"I need a creative brief for a product launch campaign. We're targeting millennial parents, budget is $50K, and we need Feed ads, Story ads, and Reels. The offer is 20% off for first-time customers."

**Optimization Request:**
"Our current ads have a 0.8% CTR but we want 1.5%+. Help me create a creative brief for a refresh with better stopping power."

## Advanced Features

### Competitive Creative Analysis
Ask me to analyze competitor ads and incorporate winning patterns into your brief.

### Multi-Variant Briefs
Request briefs for A/B testing different creative concepts, hooks, or formats.

### Audience-Specific Variations
Generate separate briefs for different audience segments with tailored messaging.

### Performance Optimization
Include past campaign data for briefs that address specific performance gaps.

## Integration with Other Skills

Works well with:
- **Ad Creative Performance Predictor** - Score concepts before production
- **Creative Testing Framework** - Design test matrices for variants
- **Competitive Ads Extractor** - Analyze competitor creative for inspiration

## Reference Materials

For detailed methodologies and frameworks, I'll access:
- `references/creative-strategy-framework.md` - Strategic planning approaches
- `references/format-specifications.md` - Complete platform requirements
- `references/audience-mapping.md` - Audience insights to creative decisions
- `references/brief-templates.md` - Professional output formats

## Output Formats

Choose your preferred format:
- **Full Creative Brief** (recommended for design handoff)
- **Executive Summary** (for stakeholder alignment)
- **Technical Spec Sheet** (for production teams)
- **Miro/Figma-Ready** (formatted for collaborative tools)

## Tips for Best Results

1. **Be specific about objectives** - "Increase leads" is better than "grow business"
2. **Share context** - Past campaign data, competitor insights, brand guidelines
3. **Define constraints** - Budget, timeline, and resource limitations
4. **Specify variants** - How many concepts you want to test
5. **Include examples** - Show me ads you like or want to avoid

## Common Use Cases

### New Campaign Launch
Generate a comprehensive brief for a net-new campaign with no historical data.

### Campaign Refresh
Update creative for an existing campaign that needs performance improvement.

### Seasonal Campaigns
Create briefs for time-sensitive promotions (holidays, events, sales).

### Product Launches
Develop creative strategies for introducing new products or features.

### Retargeting Campaigns
Design briefs for re-engaging warm audiences with specific messaging.

---

**Ready to create your creative brief?** Share your campaign details and I'll generate a comprehensive brief for your design team.
