# Meta Ads Creative Brief - Usage Examples

## Example 1: E-commerce Product Launch

### User Request
```
Create a creative brief for launching our new sustainable water bottle line. 
Target audience is environmentally-conscious millennials (25-35). 
Budget is $25K for a 4-week campaign. We need Feed, Story, and Reel ads.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: Product awareness + conversion
- Target: 25-35 year-olds, eco-conscious, active lifestyle
- Budget: $25K ($15K media, $10K production)
- Timeline: 4 weeks

**Creative Strategy:**
- Hook: "The water bottle that's actually good for the planet"
- Message Hierarchy: Sustainability → Quality → Style
- Proof Points: Carbon-neutral shipping, B-Corp certified, 1% for the Planet

**Formats:**
- 3 Feed video variants (15s, 30s, 60s)
- 2 Story ad variants (quick product shots)
- 2 Reel variants (lifestyle + product demo)

**Expected Results:**
- CTR: 2.0%+
- Conversion Rate: 3.5%+
- ROAS: 3.5x

---

## Example 2: B2B SaaS Lead Generation

### User Request
```
I need a creative brief for our project management software. 
We're targeting startup founders and small team leads. 
Lead gen campaign with free trial offer. Budget is $10K/month.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: Lead generation (free trial signups)
- Target: Founders and team leads, 10-50 employees, tech-savvy
- Budget: $10K/month ongoing
- Goal: 200 qualified leads at $50 CPA

**Creative Strategy:**
- Hook: "Stop losing time to messy project management"
- Message: From chaos to clarity in 5 minutes
- Proof: 5,000+ teams, 4.8★ rating, no credit card required

**Formats:**
- Lead ad form (native Meta form)
- 2 Feed video variants (problem/solution)
- 1 Carousel (feature showcase)

**Audience Insights:**
- Pain: Using spreadsheets or too-complex tools
- Motivation: Team efficiency, looking professional to clients
- Decision drivers: Easy setup, affordable, team buy-in

---

## Example 3: Local Business Promotion

### User Request
```
Create a brief for my dental practice. We're running a spring 
cleaning special - $99 cleaning and exam. Targeting families 
within 10 miles. Budget is $2K.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: Appointment bookings
- Target: Parents 30-50, within 10 miles, family-focused
- Budget: $2K for 2-week promotion
- Goal: 40 appointments at $50 CAC

**Creative Strategy:**
- Hook: "Spring into a healthier smile"
- Offer: $99 cleaning + exam (reg. $250)
- Urgency: Limited spots, ends March 31st
- Trust: 15 years serving [City], 500+ 5★ reviews

**Formats:**
- 2 Feed images (before/after testimonials)
- 1 Story video (tour of office, meet the dentist)

**Local Optimization:**
- Location-specific imagery ([City] landmarks)
- Local testimonials with first names + neighborhood
- "Your [City] family dentist" messaging

---

## Example 4: Mobile App Install Campaign

### User Request
```
Creative brief for our meditation app launch. Targeting stressed 
professionals. $50K budget. Need app install ads for iOS and Android.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: App installs + Day 1 retention
- Target: 28-45 professionals, high-stress careers
- Budget: $50K launch month
- Goal: 10,000 installs at $5 CPI

**Creative Strategy:**
- Hook: "5 minutes to calm in your crazy day"
- Value: Science-backed, works anywhere, no experience needed
- Proof: 4.9★ rating, featured by Apple, 1M+ users

**Formats:**
- 3 Feed video variants (app demo in real contexts)
- 2 Story ads (before/after mood transformation)
- 2 Reels (trending audio + app showcase)
- Playable ad (mini meditation experience)

**App-Specific Elements:**
- Actual app footage (not stock)
- Clear app store badges
- First session experience preview
- Privacy reassurance (data not shared)

---

## Example 5: Seasonal Flash Sale

### User Request
```
Quick brief needed! Flash sale this weekend - 40% off everything. 
E-commerce fashion brand. Need ads by tomorrow. Budget $5K.
```

### Generated Brief (Quick Brief Template)

**What We Need:** Flash sale ads for 40% off sitewide
**Timeline:** Launch Saturday 8am, run through Sunday
**Audience:** Existing customers + warm audiences

**Key Message:** "Weekend Flash Sale: 40% Off Everything"

**Formats:**
- 2 Feed images (product grids)
- 2 Story graphics (countdown timer style)

**Must-Haves:**
- Bold "40% OFF" callout
- "This Weekend Only" urgency
- Shop Now CTA
- Mobile-optimized (large text)

**Copy:**
- Headline: "40% Off Ends Sunday"
- Body: "Flash Sale! 40% off everything. Shop now before it's gone. 🔥"
- CTA: Shop Now

---

## Example 6: Retargeting Campaign Optimization

### User Request
```
Our retargeting ads have 1.2% CTR but we need 2%+. Create a 
brief for refreshed creative that addresses cart abandoners. 
Beauty/skincare brand.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: Conversion (cart recovery)
- Target: Cart abandoners (last 30 days)
- Current Performance: 1.2% CTR, 2.3% conversion
- Goal: 2.0%+ CTR, 4.0%+ conversion

**Creative Strategy:**
- Hook: "Your [product] is waiting" with actual product image
- Objection Handling: Free shipping, easy returns, 60-day guarantee
- Urgency: Cart saved for 24 hours, best-sellers selling out
- Incentive: 10% discount for completing order today

**Formats:**
- Dynamic catalog ads (exact products in cart)
- 2 Story reminders (cart contents + benefits)
- 1 Carousel (cart items + related products)

**Why Current Ads Are Underperforming:**
- Generic "Complete your order" messaging
- No incentive or urgency
- Missing product-specific benefits
- No objection handling

**New Approach:**
- Product-specific hooks ("Your vitamin C serum...")
- Address abandonment reasons (price, shipping, trust)
- Add social proof (X people bought this today)
- Create FOMO (low stock alerts)

---

## Example 7: Multi-Audience Campaign

### User Request
```
Create briefs for our online course launch. We're targeting 
three audiences: college students, career switchers, and 
professionals upskilling. Same course, different messaging.
```

### Generated Brief (3 Variants)

#### Variant A: College Students (18-24)

**Creative Strategy:**
- Hook: "The skills your degree won't teach you"
- Message: Career-ready skills, affordable, future-proof
- Format: Reels (fast-paced, trending audio)
- Proof: Recent grads who landed jobs

#### Variant B: Career Switchers (25-35)

**Creative Strategy:**
- Hook: "I made the switch to [career] in 6 months"
- Message: No degree needed, real portfolio projects, money-back guarantee
- Format: Feed video (transformation story)
- Proof: Student testimonials with salary increases

#### Variant C: Professionals Upskilling (35-50)

**Creative Strategy:**
- Hook: "Stay relevant in your field" / "Lead, don't follow"
- Message: Executive-level skills, self-paced, ROI-focused
- Format: Feed carousel (clear value props)
- Proof: Before/after career outcomes, recognizable companies

**Shared Elements:**
- Same course curriculum
- Same instructor credentials
- Same pricing structure
- Same landing page (with toggled testimonials)

---

## Example 8: Testing Multiple Concepts

### User Request
```
We want to test 3 different creative concepts for our 
productivity app. Can you create a brief that sets up 
proper A/B testing?
```

### Generated Brief (Multi-Variant Testing Template)

**Test Hypothesis:** Hook strategy (problem vs transformation vs social proof) impacts CTR and conversion rate

**Test Design:**
- Even budget split across 3 concepts
- Same audience, same placement
- 7-day test minimum
- 95% statistical confidence

#### Concept A: Problem-Focused
- Hook: "Drowning in tasks? There's a better way"
- Angle: Pain point amplification
- Format: Feed video (chaotic → organized)

#### Concept B: Transformation
- Hook: "How I finally got my life together"
- Angle: Before/after personal story
- Format: Story video (testimonial style)

#### Concept C: Social Proof
- Hook: "Join 50,000 productive people"
- Angle: Popularity and validation
- Format: Carousel (user testimonials)

**Success Criteria:**
- Primary: Conversion rate
- Secondary: CTR, CPA
- Winner: >20% improvement + statistical significance

**Next Test:** After identifying winning hook approach, test message variations

---

## Example 9: Industry-Specific (Healthcare)

### User Request
```
Creative brief for our telehealth service. Need to handle 
healthcare advertising restrictions while promoting 
convenience benefits.
```

### Generated Brief Summary

**Campaign Overview:**
- Objective: Patient acquisition
- Target: 25-55, busy professionals, families with kids
- Compliance: HIPAA-compliant messaging, no health claims

**Creative Strategy:**
- Hook: "See a doctor from anywhere" (benefit, not claim)
- Message: Convenience → affordability → quality
- Avoid: Specific health conditions, before/after health images

**Compliance Requirements:**
- No personal health attributes targeting
- No medical claims or guarantees
- Include disclaimers where required
- Doctor credentials clearly stated
- Privacy policy easily accessible

**Formats:**
- Feed video (day-in-the-life showing convenience)
- Story ads (simple UI demonstration)
- Lead ads (appointment booking)

**Safe Messaging:**
- ✅ "Skip the waiting room"
- ✅ "Talk to licensed doctors"
- ❌ "Cure your [condition]"
- ❌ "Better than in-person visits"

---

## Example 10: Performance Optimization with Data

### User Request
```
Here's our last campaign data:
- CTR: 1.8% (target was 2.5%)
- Conversion rate: 2.1% (target was 3.5%)
- Frequency: 4.2 (creative fatigue)

Create a brief that specifically addresses these issues.
```

### Generated Brief Summary

**Problem Diagnosis:**
1. **Low CTR** = Weak hook/first 3 seconds
2. **Low conversion rate** = Landing page mismatch or unclear value
3. **High frequency** = Creative fatigue/audience burnout

**Creative Solutions:**

**For CTR Improvement:**
- Test 3 new hook strategies (pattern interrupt, curiosity gap, bold claim)
- Shorten videos to 15s (faster payoff)
- Use motion/animation in first frame
- Test story-style authentic content vs polished

**For Conversion Rate:**
- Match ad creative to landing page more closely
- Add social proof to creative (testimonials, user counts)
- Test direct offer in creative vs soft benefit
- Include specific CTA preview ("Fill out 2-minute form")

**For Frequency Management:**
- Expand audience size by 3x
- Rotate creative weekly (3-4 variants)
- Exclude converters from seeing ads
- Test new platforms (Reels if only using Feed)

**Testing Priority:**
1. Week 1-2: Hook testing (highest impact on CTR)
2. Week 3-4: Offer/social proof testing (conversion rate)
3. Week 5+: Format expansion (frequency management)

---

## Pro Tips from These Examples

### 1. Always Include Context
The more context you provide (budget, timeline, past performance, constraints), the more tailored and actionable your brief will be.

### 2. Specify Output Format
If you need a quick turnaround, request the "Quick Brief" template. For comprehensive handoffs, use "Full Creative Brief."

### 3. Request Testing Structure
For campaigns with adequate budget ($5K+), ask for multi-variant briefs that set up proper A/B tests.

### 4. Industry-Specific Considerations
Mention your industry for relevant compliance guidance (healthcare, finance, alcohol, etc.).

### 5. Performance Data Improves Recommendations
Share past campaign data for optimization-focused briefs that address specific performance gaps.

### 6. Audience Segmentation
For multiple target audiences, request separate briefs or variants to ensure messaging relevance.

### 7. Budget Constraints Help Prioritization
Mention your budget to get format and concept recommendations that fit your spend level.

---

**Want to see a specific example?** Ask for a brief based on your campaign requirements and I'll generate a tailored example.
