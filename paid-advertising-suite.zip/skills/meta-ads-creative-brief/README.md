# Meta Ads Creative Brief Generator

A comprehensive Claude Skill for generating professional creative briefs that align designers with campaign objectives, audience insights, and Meta platform requirements.

## What This Skill Does

Transforms campaign requirements into designer-ready creative briefs that include:

- **Audience Insights**: Demographics, psychographics, and creative preferences
- **Creative Guidelines**: Hook strategies, message hierarchy, and visual direction
- **Format Specifications**: Technical requirements for Feed, Story, Reel formats
- **Objective Alignment**: Campaign goals mapped to creative decisions

## Who This Is For

- **Marketing Managers**: Creating briefs for in-house or agency designers
- **Creative Directors**: Standardizing brief quality across campaigns
- **Solo Founders**: Professional briefs without marketing team overhead
- **Agencies**: Consistent client handoffs and approval processes

## Quick Start

### Basic Usage

**Simple Request:**
```
Create a creative brief for a lead generation campaign 
targeting small business owners for our accounting software.
```

**Detailed Request:**
```
I need a creative brief for a product launch. We're targeting 
millennial parents, budget is $50K, and we need Feed ads, 
Story ads, and Reels. The offer is 20% off for first-time customers.
```

### What You'll Get

A comprehensive creative brief including:

1. **Campaign Overview** - Objectives, timeline, budget
2. **Audience Analysis** - Demographics, pain points, motivations
3. **Creative Strategy** - Hook approach, message hierarchy, proof points
4. **Format Requirements** - Technical specs for each placement
5. **Design Guidelines** - Visual style, brand elements, mobile optimization
6. **Copy Requirements** - Headlines, body text, CTAs
7. **Success Criteria** - Performance benchmarks and approval process

## Key Features

### 1. Audience-Creative Mapping

Automatically translates audience characteristics into creative decisions:

- **Age-based recommendations**: Visual style, pacing, messaging tone
- **Income-level strategies**: Offer positioning and proof elements
- **Psychographic alignment**: Hook strategies matched to buyer psychology

### 2. Platform Optimization

Specifications for all Meta ad formats:

- **Feed Ads**: 1:1 or 4:5, storytelling approach, longer form
- **Story Ads**: 9:16 full-screen, quick hooks, interactive elements
- **Reel Ads**: Creator aesthetic, trending audio, entertainment-first
- **Carousel Ads**: Sequential narratives or product showcases

### 3. Strategic Frameworks

Built-in methodologies for:

- **Hook Strategy Selection**: Pattern interrupts, curiosity gaps, direct offers
- **Message Architecture**: The Creative Pyramid framework
- **Concept Development**: Hook + Format + Message combinations
- **Testing Strategies**: Multi-variant brief generation

### 4. Multiple Output Formats

Choose the brief style that fits your workflow:

- **Full Creative Brief**: Comprehensive 10+ section document
- **Executive Summary**: Stakeholder alignment format
- **Quick Brief**: Fast-turnaround template
- **Technical Spec Sheet**: Production-focused requirements
- **Multi-Variant Brief**: A/B testing documentation

## Common Use Cases

### New Campaign Launch
Generate comprehensive brief for net-new campaign with no historical data. Includes competitive analysis and audience research integration.

### Campaign Refresh
Update creative for existing campaigns needing performance improvement. Addresses specific KPI gaps with targeted creative strategies.

### Seasonal Campaigns
Create briefs for time-sensitive promotions with urgency elements and seasonal relevance built in.

### Product Launches
Develop creative strategies for introducing new products with education and awareness focus.

### A/B Testing
Generate multi-variant briefs that test specific elements (hook, message, format) with statistical rigor.

## Advanced Features

### Competitive Creative Analysis

Request analysis of competitor ads with pattern identification:
```
Analyze competitor ads in [industry] and create a brief 
that incorporates winning patterns while differentiating our brand.
```

### Performance Optimization

Include past campaign data for targeted improvements:
```
Our current ads have 0.8% CTR but we need 1.5%+. Create a 
creative brief that specifically addresses stopping power.
```

### Multi-Audience Briefs

Generate separate briefs for different segments:
```
Create briefs for three audience segments: Gen Z students, 
millennial professionals, and Gen X parents. Same product, 
tailored messaging for each.
```

### Budget-Optimized Briefs

Get recommendations scaled to your budget:
```
We have $5K total budget. Create a creative brief that 
prioritizes the highest-ROI formats and concepts.
```

## Integration with Other Skills

Works seamlessly with:

- **Ad Creative Performance Predictor**: Score concepts before production
- **Creative Testing Framework**: Design test matrices for variants
- **Competitive Ads Extractor**: Analyze competitor creative for inspiration
- **Creative Testing Insights Reporter**: Learn from past test results

## Tips for Best Results

### 1. Be Specific About Objectives
❌ "Grow the business"
✅ "Generate 500 qualified leads at <$25 CPA"

### 2. Share Available Context
- Past campaign performance data
- Competitor ads you've researched
- Brand guidelines or style preferences
- Budget and timeline constraints

### 3. Define Testing Intent
- How many concepts to test
- What specific elements to vary
- Success criteria for winner selection

### 4. Specify Output Format
- Need stakeholder approval? → Executive Summary
- Direct to designer? → Full Creative Brief
- Fast turnaround? → Quick Brief

### 5. Include Examples
- Show ads you like (yours or competitors)
- Explain what you want to avoid
- Share creative that performed well previously

## Brief Components Explained

### Campaign Overview
Sets context for designers: objectives, timeline, budget, and success metrics. Ensures creative decisions align with business goals.

### Audience Insights
Translates target audience into actionable creative direction. Includes pain points, motivations, and content preferences that inform hook and message strategies.

### Creative Strategy
Defines the "Big Idea" and execution approach. Includes message hierarchy, proof points, and CTA strategy to guide creative development.

### Format Specifications
Technical requirements for each Meta placement. Ensures deliverables meet platform requirements and perform optimally.

### Design Guidelines
Visual direction including style, brand elements, mobile optimization, and sound-off considerations for platform behavior.

### Success Criteria
Performance benchmarks, testing plan, and approval process. Sets clear expectations for what "good" looks like.

## Performance Benchmarks

Typical improvements when using structured creative briefs:

- **Production Efficiency**: 40-60% reduction in revision rounds
- **Campaign Performance**: 20-35% improvement in CTR
- **Designer Satisfaction**: Clearer direction reduces guesswork
- **Stakeholder Alignment**: Fewer approval delays

## File Structure

```
meta-ads-creative-brief/
├── SKILL.md (core workflow)
├── README.md (this file)
├── EXAMPLES.md (usage scenarios)
└── references/
    ├── creative-strategy-framework.md (methodologies)
    ├── format-specifications.md (technical requirements)
    ├── audience-mapping.md (audience insights)
    └── brief-templates.md (output formats)
```

## Frequently Asked Questions

**Q: Do I need design experience to use this?**
A: No. The skill generates briefs that non-designers can use to communicate effectively with designers.

**Q: Can I use this for platforms other than Meta?**
A: The frameworks are adaptable, but specifications are optimized for Meta (Facebook/Instagram). For other platforms, mention the platform in your request.

**Q: How long does it take to generate a brief?**
A: 2-5 minutes for a comprehensive brief, depending on complexity and available context.

**Q: Can I customize the brief templates?**
A: Yes. Request specific sections to add/remove, or ask for industry-specific modifications.

**Q: Does this work for B2B campaigns?**
A: Absolutely. The skill includes B2B-specific strategies and messaging frameworks.

**Q: What if I don't know all the campaign details yet?**
A: Start with what you have. The skill will identify gaps and help you work through remaining decisions.

**Q: Can this help with creative testing strategies?**
A: Yes. Request the Multi-Variant Testing Brief template for structured A/B test documentation.

**Q: Is this suitable for small budgets (<$5K)?**
A: Yes. Mention your budget and you'll get recommendations optimized for smaller spend levels.

## Example Outputs

See `EXAMPLES.md` for complete sample briefs including:

- E-commerce product launch
- B2B lead generation
- Mobile app install campaign
- Local business promotion
- Seasonal sale campaign

## Updates & Improvements

This skill is actively maintained with:

- Latest Meta platform specifications
- Updated performance benchmarks
- New creative frameworks and strategies
- Industry-specific templates

## Support & Feedback

For questions or suggestions, provide feedback through Claude's interface using the thumbs up/down buttons.

## License

This skill is provided for use with Claude. No additional licensing required.

---

**Ready to create your creative brief?** Just tell me about your campaign and I'll generate a comprehensive brief for your design team.
