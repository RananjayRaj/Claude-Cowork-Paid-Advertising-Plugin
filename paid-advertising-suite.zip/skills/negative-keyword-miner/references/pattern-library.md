# Negative Keyword Pattern Library

## Universal Waste Patterns

These patterns waste spend across most industries and business types.

### Job Seeker Patterns

**Keywords to Block**:
- jobs
- careers
- hiring
- employment
- job openings
- apply
- resume
- salary
- job description

**Recommended Match Type**: Broad match negative for "jobs", "careers", "salary"  
**Expected Impact**: 3-8% cost reduction  
**Risk Level**: Low

**Example Wasted Searches**:
- "[your company] jobs"
- "[industry] careers"
- "[product] salary"
- "how much does [job title] make"

---

### Free/DIY Seekers

**Keywords to Block**:
- free
- free trial (if you don't offer)
- free version
- no cost
- diy
- how to make
- homemade
- tutorial
- guide (for how-to guides, not buyer guides)

**Recommended Match Type**: 
- "free" as broad match negative (if you have no free offering)
- "diy" as phrase match negative
- "how to make" as phrase match negative

**Expected Impact**: 5-12% cost reduction  
**Risk Level**: Medium (be careful with "free shipping", "free returns")

**Example Wasted Searches**:
- "free [product]"
- "diy [product]"
- "how to make [product] at home"
- "[product] tutorial"

**IMPORTANT**: Don't block "free" if you offer:
- Free shipping
- Free trial
- Free returns
- Risk-free guarantee

---

### Academic/Student Patterns

**Keywords to Block**:
- project
- assignment
- thesis
- dissertation
- essay
- homework
- class
- student project
- school project
- research paper

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 2-6% cost reduction  
**Risk Level**: Low

**Example Wasted Searches**:
- "[product] project ideas"
- "[topic] assignment help"
- "[product] for school project"

---

### Download/Resource Hunters

**Keywords to Block**:
- pdf download
- free download
- template download
- cheat sheet
- worksheet
- printable

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 3-7% cost reduction  
**Risk Level**: Low

**Exception**: Keep if you offer lead magnets or downloadable resources

**Example Wasted Searches**:
- "[topic] pdf free download"
- "[product] template"
- "[process] cheat sheet"

---

### Wrong Media Type Searches

**Keywords to Block**:
- images
- wallpaper
- logo
- icon
- clipart
- png
- transparent background
- vector
- drawing

**Recommended Match Type**: Broad match negative  
**Expected Impact**: 1-4% cost reduction  
**Risk Level**: Low

**Example Wasted Searches**:
- "[product] images"
- "[product] logo png"
- "[product] clipart"

---

## Industry-Specific Patterns

### B2B SaaS

#### Information Seekers (Wrong for Bottom-Funnel)

**Keywords to Monitor**:
- what is
- define
- definition
- meaning
- explained
- for dummies
- beginner guide

**Recommended Approach**: 
- Keep in top-of-funnel research campaigns
- Block from bottom-funnel purchase campaigns

**Match Type**: Phrase match negative (campaign-level)  
**Expected Impact**: 8-15% cost reduction in purchase campaigns

---

#### Wrong Pricing Queries

**Keywords to Block**:
- free
- open source
- free alternative
- free version
- no credit card

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 5-10% cost reduction  
**Risk Level**: Low

**Exception**: If you have freemium model, create separate campaign

---

#### Comparison Shoppers (Wrong for Brand Campaign)

**Keywords to Block from Brand Campaign**:
- vs
- versus
- compared to
- alternative
- competitor
- better than

**Recommended Approach**: 
- Block from brand campaign (phrase match)
- Create separate comparison campaign if valuable

**Expected Impact**: 10-20% improvement in brand campaign efficiency

---

### E-commerce

#### Wrong Purchase Intent

**Keywords to Block**:
- wholesale
- bulk
- distributor
- supplier
- manufacturer
- trade
- reseller

**Recommended Match Type**: Broad match negative (unless you serve B2B)  
**Expected Impact**: 3-8% cost reduction  
**Risk Level**: Low

---

#### Wrong Product Attributes

**Example for Apparel**:
- plus size (if you don't carry)
- petite (if you don't carry)
- tall (if you don't carry)
- custom (if you don't offer custom)
- handmade (if you don't sell handmade)

**Recommended Match Type**: Exact or phrase match negative  
**Expected Impact**: Varies by product range  
**Risk Level**: Low

---

#### Product Research (Not Ready to Buy)

**Keywords to Consider Blocking**:
- review
- reviews
- ratings
- unboxing
- haul
- try on

**Recommended Approach**: CAREFUL - these can convert well
- If your reviews are strong: Keep these terms
- If reviews are weak: Block from main campaign, create separate research campaign

**Match Type**: Phrase match negative (if blocking)  
**Risk Level**: High (review carefully)

---

### Local Services

#### Geographic Mismatches

**Pattern**: Searches for services in locations you don't serve

**Keywords to Block**:
- [City name] (cities outside service area)
- [State name] (states outside service area)
- [Zip code] (zip codes outside service area)
- "near me" + location modifier you don't serve

**Recommended Match Type**: Exact or phrase match for city names  
**Expected Impact**: 10-25% cost reduction for local businesses  
**Risk Level**: Low

**Example for NYC Plumber**:
- "plumber in los angeles" (phrase)
- "boston plumber" (phrase)
- "plumber near miami" (phrase)

---

#### DIY Intent

**Keywords to Block**:
- how to
- diy
- do it yourself
- fix yourself
- repair yourself
- video tutorial

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 5-15% cost reduction  
**Risk Level**: Low

---

#### Information Seekers

**Keywords to Consider**:
- cost
- how much
- average price
- estimate
- quote (might be high-intent!)

**Recommended Approach**: CAREFUL
- "quote" is often high-intent for local services
- "cost" and "how much" can be mid-funnel

**Match Type**: Monitor before adding as negative  
**Risk Level**: High

---

### Legal Services

#### Wrong Practice Area

**Pattern**: Searches for legal services you don't provide

**Example for Personal Injury Lawyer**:
- criminal defense (phrase match negative)
- divorce lawyer (phrase match negative)
- bankruptcy attorney (phrase match negative)

**Expected Impact**: 5-15% cost reduction  
**Risk Level**: Low

---

#### Pro Bono Seekers

**Keywords to Block**:
- free consultation (if you don't offer)
- pro bono
- free lawyer
- volunteer lawyer
- legal aid

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 3-7% cost reduction  
**Risk Level**: Low

---

#### Generic Legal Information

**Keywords to Block**:
- forms
- template
- sample
- example
- definition
- statute
- law text

**Recommended Match Type**: Broad match negative  
**Expected Impact**: 4-9% cost reduction  
**Risk Level**: Low

---

## Match Type-Specific Patterns

### Broad Match Gone Wrong

**Symptom**: Your broad match keywords are triggering irrelevant searches

**Example**:
- Target keyword: "email marketing software" (broad)
- Triggered search: "email marketing jobs"
- Triggered search: "free email marketing guide"

**Solution**:
1. Add specific problem terms as negatives
2. Consider switching to phrase match
3. Use negative keyword sculpting

---

### Phrase Match Close Variants

**Symptom**: Phrase match keywords triggering wrong plurals, verb forms

**Example**:
- Target: "buy running shoes" (phrase)
- Triggered: "buying running shoes" (might be less intent)
- Triggered: "bought running shoes" (past tense = already purchased)

**Solution**: Add past tense and -ing forms as exact match negatives if they don't convert

---

### Exact Match Isn't Always Perfect

**Symptom**: Even exact match keywords can waste money

**Example**:
- Target: [project management software] (exact)
- Converts at 0.5% vs account average of 3%
- High CPC: $25

**Solution**: 
- Not a negative keyword issue
- Consider pausing keyword entirely
- Or dramatically reduce bid

---

## Seasonal Patterns

### Holiday Season

**December-January**:
- Block "black friday" after Black Friday passes
- Block "cyber monday" after Cyber Monday
- Block "christmas" after December 25
- Block "new years" after January 1

---

### Tax Season (USA)

**January-April** (Keep terms that usually are negatives):
- "tax" terms might convert for financial services
- "deadline" becomes high-intent

**May-December** (Block again):
- "tax" becomes informational only

---

### Back to School

**July-September** (Review student terms):
- Some "student" terms might convert for education products
- "school supplies" might be relevant for some businesses

**October-June** (Block student terms):
- "student", "homework", "assignment" back to negative status

---

## Competitor Patterns

### Brand Protection

**Pattern**: Searches including competitor names

**Recommended Approach**:
1. Create separate competitor campaign
2. Add all competitor brands as negatives in main campaigns
3. Target competitor terms in dedicated campaign with comparison messaging

**Keywords to Block from Main Campaign**:
- [competitor name]
- [competitor name] vs [your brand]
- [competitor name] alternative
- switch from [competitor name]

**Match Type**: Phrase match negative  
**Expected Impact**: Cleaner campaign structure, better Quality Scores

---

### Competitive Research Terms

**Keywords to Consider Blocking**:
- comparison
- compare
- vs
- versus
- alternative to
- better than
- instead of

**Recommended Approach**: 
- Block from brand campaign (users already know you)
- Keep in competitor/comparison campaign
- Monitor closely for conversion potential

**Risk Level**: Medium-High

---

## Technical/Troubleshooting Patterns

### Post-Purchase Searches

**Keywords to Block**:
- login
- sign in
- support
- help
- customer service
- portal
- account

**Recommended Match Type**: Phrase match negative  
**Expected Impact**: 2-5% cost reduction  
**Risk Level**: Low

**Note**: These are existing customers, not prospects

---

### Wrong Product Version

**Example for Software Company**:
- You sell Windows software
- Block: "mac version", "ios app", "android"

**Example for Physical Products**:
- You sell standard sizes
- Block: "custom size", "made to order", "bespoke"

**Match Type**: Phrase match negative  
**Expected Impact**: Varies by business  
**Risk Level**: Low

---

## High-Risk Patterns (Review Carefully)

### Terms That Can Go Either Way

#### "Cheap"
- ✅ Keep if: Budget positioning, price is competitive advantage
- ❌ Block if: Premium positioning, quality focus

#### "Best"
- ✅ Keep if: You are/can claim to be the best, strong reviews
- ❌ Block if: Mid-market positioning, comparison shoppers

#### "Review" / "Reviews"
- ✅ Keep if: Strong reviews (4+ stars), reviews are advantage
- ❌ Block if: Weak reviews, or research-stage traffic doesn't convert

#### "Vs" / "Versus" / "Comparison"
- ✅ Keep if: You win comparisons, have comparison content
- ❌ Block if: Weak competitive position, or from brand campaign

#### "How to"
- ✅ Keep if: You have strong educational content, long sales cycle
- ❌ Block if: Bottom-funnel campaign, informational traffic doesn't convert

---

## Custom Pattern Recognition

### How to Identify Your Own Patterns

1. **Export Search Terms Report** (30+ days)
2. **Sort by Cost** (highest first)
3. **Filter by Conversions** (= 0)
4. **Look for Common Words/Phrases** in top 50 terms
5. **Validate Pattern** across multiple terms
6. **Estimate Savings** if blocked
7. **Choose Match Type** (start conservative)
8. **Implement & Monitor**

### Pattern Recognition Checklist

- [ ] Do I see the same word in 5+ wasted search terms?
- [ ] Do these terms collectively waste $100+/month?
- [ ] Are these terms definitely irrelevant to my offering?
- [ ] Have I checked if any variations might convert?
- [ ] What's the least restrictive match type I can use?
- [ ] Will this negative block any of my target keywords?

---

## Pattern Testing Framework

### Before Adding Pattern as Negative

**Test Questions**:
1. How many search terms match this pattern?
2. What's the total cost of these terms?
3. What's the conversion rate? (0% = good candidate)
4. Any exceptions that might convert?
5. What match type covers the pattern without over-blocking?

### After Adding Pattern as Negative

**Monitor**:
- Days 1-3: Impression volume change
- Days 4-7: Conversion volume change
- Day 14: Calculate actual savings vs forecast
- Day 30: Review for unintended consequences

---

## Emergency Patterns (Add Immediately)

Some patterns are universal waste and should be added immediately:

### Critical Priority (Add Today)

1. **Adult Content** (if not your business)
   - porn, xxx, sex, nude, naked
   - Match: Broad negative

2. **Illegal Activities**
   - crack, hack, pirate, illegal, torrent
   - Match: Broad negative

3. **Wrong Jobs** (universal)
   - jobs, careers, salary, hiring
   - Match: Broad negative

4. **Spam/Junk**
   - spam, fake, scam, virus
   - Match: Broad negative

These have zero legitimate use cases for most businesses and represent pure waste.

---

## Pattern Library Maintenance

### Quarterly Updates

- Review new search terms for emerging patterns
- Remove patterns that are no longer relevant
- Update based on business changes
- Document new patterns discovered

### Pattern Performance Tracking

| Pattern | Date Added | Monthly Savings | Risk Level | Still Active? |
|---------|------------|-----------------|------------|---------------|
| [pattern] | [date] | $[amount] | [Low/Med/High] | Yes/No |

---

*Remember: Patterns are more powerful than individual keywords. One pattern-based negative can block hundreds of wasted searches.*
