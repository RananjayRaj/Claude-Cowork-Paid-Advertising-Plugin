# Negative Keyword Miner - Output Template

## Analysis Summary

**Analysis Period**: [Start Date] to [End Date]  
**Total Search Terms Analyzed**: [Number]  
**Current Monthly Ad Spend**: $[Amount]  
**Estimated Monthly Waste**: $[Amount] ([Percentage]% of spend)  
**Potential Monthly Savings**: $[Amount]  
**Number of Recommended Negatives**: [Number]

---

## Priority Tier 1: CRITICAL (Implement Immediately)

These negative keywords represent significant waste with minimal risk.

### Exact Match Negatives

| Negative Keyword | Match Type | Monthly Cost | Est. Savings | Reason | Implementation Level |
|------------------|------------|--------------|--------------|--------|---------------------|
| [keyword] | Exact | $[amount] | $[amount] | [1-2 sentence reason] | [Account/Campaign] |

**Total Tier 1 Savings**: $[amount]/month

**Implementation Instructions**:
1. Add to [Account/Campaign] level negative keyword list
2. Expected impact: [X]% reduction in wasted spend
3. Risk assessment: LOW - these are proven non-converters

---

## Priority Tier 2: HIGH (Implement Within 1 Week)

Strong candidates with good cost savings, slightly higher monitoring needed.

### Phrase Match Negatives

| Negative Keyword | Match Type | Monthly Cost | Est. Savings | Reason | Implementation Level |
|------------------|------------|--------------|--------------|--------|---------------------|
| [keyword phrase] | Phrase | $[amount] | $[amount] | [1-2 sentence reason] | [Account/Campaign] |

### Broad Match Negatives (Use with Caution)

| Negative Keyword | Match Type | Monthly Cost | Est. Savings | Reason | Implementation Level | Monitor Closely |
|------------------|------------|--------------|--------------|--------|---------------------|-----------------|
| [keyword] | Broad | $[amount] | $[amount] | [1-2 sentence reason] | [Account/Campaign] | âš ï¸ Yes |

**Total Tier 2 Savings**: $[amount]/month

**Implementation Instructions**:
1. Add phrase match negatives first
2. Wait 48 hours, monitor impression changes
3. Then add broad match negatives
4. Set calendar reminder to review in 7 days

---

## Priority Tier 3: MEDIUM (Implement Within 2 Weeks)

Moderate cost savings, require more careful consideration.

| Negative Keyword | Match Type | Monthly Cost | Est. Savings | Reason | Implementation Level | Risk Level |
|------------------|------------|--------------|--------------|--------|---------------------|------------|
| [keyword] | [type] | $[amount] | $[amount] | [1-2 sentence reason] | [Account/Campaign] | [Low/Med/High] |

**Total Tier 3 Savings**: $[amount]/month

**Implementation Notes**:
- Review these with product/brand team before implementing
- Some may require campaign restructuring instead
- Consider testing with lower bids first

---

## Priority Tier 4: LOW (Monitor & Consider)

Small cost impact, or higher implementation risk requiring more analysis.

| Negative Keyword | Match Type | Monthly Cost | Est. Savings | Reason | Consideration |
|------------------|------------|--------------|--------------|--------|---------------|
| [keyword] | [type] | $[amount] | $[amount] | [1-2 sentence reason] | [Why low priority] |

**Total Tier 4 Potential Savings**: $[amount]/month

---

## Pattern Analysis

### Top Cost-Wasting Patterns Identified

1. **[Pattern Category]** (e.g., "Free + Product" queries)
   - Example terms: [list 3-5 examples]
   - Total monthly waste: $[amount]
   - Recommended action: [Specific negative keyword strategy]

2. **[Pattern Category]**
   - Example terms: [list 3-5 examples]
   - Total monthly waste: $[amount]
   - Recommended action: [Specific negative keyword strategy]

3. **[Pattern Category]**
   - Example terms: [list 3-5 examples]
   - Total monthly waste: $[amount]
   - Recommended action: [Specific negative keyword strategy]

---

## Intent Misalignment Analysis

### Informational Intent (Should be in content marketing, not paid search)
- [List specific search terms]
- Combined monthly cost: $[amount]
- Recommendation: Exclude from paid, target with SEO content

### Job Seeker Intent
- [List specific search terms]
- Combined monthly cost: $[amount]
- Recommendation: Add broad match negative "jobs"

### Wrong Product/Service Type
- [List specific search terms]
- Combined monthly cost: $[amount]
- Recommendation: Campaign restructure or phrase match exclusions

---

## Match Type Inefficiency Report

### Broad Match Overspend
**Issue**: Broad match keywords triggering irrelevant searches  
**Evidence**: [List examples with costs]  
**Recommendation**: 
1. Add these as negative keywords
2. Consider shifting to Phrase Match for [list keywords]
3. Estimated savings: $[amount]/month

### Phrase Match Leakage
**Issue**: Close variants causing problems  
**Evidence**: [List examples]  
**Recommendation**: Add exact match negatives for problematic variants

---

## Implementation Roadmap

### Week 1: Quick Wins
- [ ] Implement all Tier 1 negatives (Critical)
- [ ] Expected impact: $[amount]/month saved
- [ ] Monitor daily for first 3 days

### Week 2: Strategic Implementation
- [ ] Implement Tier 2 High priority negatives
- [ ] Review performance of Week 1 changes
- [ ] Adjust if needed

### Week 3: Refinement
- [ ] Implement selected Tier 3 negatives after review
- [ ] Calculate actual savings vs forecast

### Week 4: Optimization
- [ ] Evaluate Tier 4 negatives
- [ ] Plan next monthly analysis
- [ ] Document lessons learned

---

## Risk Mitigation Strategy

### Safeguards to Implement

1. **Staggered Rollout**: Don't add all negatives at once
2. **Daily Monitoring**: Check impressions, clicks, conversions for 7 days
3. **Backup Plan**: Document all negatives added for easy removal if needed
4. **Alert Setup**: Set up alerts for >20% impression drop
5. **Exclusion Review**: Monthly review to remove negatives that may now be relevant

### Red Flags to Watch For

âš ï¸ **Immediate attention needed if:**
- Impressions drop >30% in 3 days
- Conversion volume drops >15% in 7 days
- Entire ad groups stop serving
- Brand search impressions significantly decline

### Rollback Process

If unintended consequences occur:
1. Immediately pause most recent negative keyword additions
2. Wait 24 hours for data to normalize
3. Review which negative caused the issue
4. Remove problematic negative, adjust to more targeted match type
5. Document lesson for future implementations

---

## Expected Results Timeline

**Days 1-3**: Initial CPC may increase slightly (blocking cheaper irrelevant clicks)  
**Days 4-7**: CPA should improve as only qualified traffic remains  
**Days 8-14**: Conversion rate should increase noticeably  
**Day 30**: Measure total cost savings vs forecast

**Success Metrics**:
- Cost savings: Target [X]% of forecast achieved
- Conversion rate: Target [X]% improvement
- Impression loss: <5% of total impressions
- Quality score: Maintained or improved

---

## Next Analysis Recommended

Schedule next negative keyword analysis for: [Date 30 days from now]

**What to bring to next analysis**:
- Performance data from this implementation
- Any new campaigns launched
- Seasonal considerations for upcoming period
- Budget changes or business goals shifts

---

## Questions or Concerns?

**Before implementing, validate:**
- [ ] Have you cross-referenced with existing negative keyword lists?
- [ ] Have you reviewed with stakeholders who might have strategic concerns?
- [ ] Do you have a monitoring plan for the first week?
- [ ] Have you documented the pre-implementation baseline metrics?
- [ ] Do you know how to remove negatives if needed?

**Common Questions Addressed**:
- *"Will this hurt my brand campaign?"* - Review brand term analysis section
- *"What if I over-exclude?"* - Follow staggered rollout process
- *"How do I add these to Google Ads?"* - See implementation guide below

---

## Platform-Specific Implementation Guide

### Google Ads
1. Navigate to Tools & Settings > Negative Keywords
2. Click the blue plus button
3. Select Account level or Campaign level
4. Paste negatives with match types
5. Save and monitor

### Microsoft Ads
1. Go to Campaigns > Campaign/Ad Group
2. Select Keywords > Negative Keywords
3. Add negative keywords
4. Choose match type from dropdown
5. Apply changes

### Meta Ads (Facebook/Instagram)
*Note: Meta doesn't use traditional negative keywords*
- Use Exclusion audiences instead
- Add domains to block list for placement exclusions
- Refine detailed targeting to prevent irrelevant reaches

---

## Appendix: Full Search Term Analysis

[Optional: Include full data table if user wants comprehensive breakdown]

| Search Term | Impressions | Clicks | CTR | Cost | Conversions | Conv. Rate | CPA | Recommendation |
|-------------|-------------|--------|-----|------|-------------|-----------|-----|----------------|
| [term] | [#] | [#] | [%] | $[#] | [#] | [%] | $[#] | [Negative/Keep/Monitor] |

---

**End of Analysis Report**

*Generated by Negative Keyword Miner Skill*  
*Analysis Date: [Date]*  
*Next Review: [Date]*
