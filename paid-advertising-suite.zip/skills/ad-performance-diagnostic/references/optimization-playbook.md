# Optimization Playbook

## Issue-Specific Fix Strategies

### Problem: Low CTR

**Root Cause Analysis:**
1. Check average position (Google) - Low position = low visibility
2. Review ad copy relevance - Generic copy = low engagement  
3. Analyze

 audience targeting - Wrong audience = low interest
4. Assess creative quality (Meta) - Poor creative = no stopping power

**Solutions by Cause:**

**If Low Position (Google Ads):**
- Increase bids by 20-30%
- Improve Quality Score (see QS playbook)
- Add all relevant ad extensions
- **Expected lift**: 15-40% CTR improvement
- **Timeline**: 3-7 days

**If Generic Ad Copy:**
- Add specific numbers ("Save $500" vs "Save money")
- Include time-bound offers ("24-hour sale")
- Test emotional triggers ("Don't miss out")
- Use power words ("Free", "Guaranteed", "Proven")
- **Expected lift**: 20-50% CTR improvement
- **Timeline**: 1-2 weeks (testing period)

**If Wrong Audience (Meta):**
- Narrow targeting by 30-50%
- Exclude irrelevant demographics
- Test interest-based audiences
- Use lookalike audiences (1-2%)
- **Expected lift**: 30-100% CTR improvement
- **Timeline**: Immediate

**If Ad Fatigue (Meta):**
- Refresh creative completely
- Expand audience size
- Reduce frequency cap
- Exclude converters
- **Expected lift**: 50-150% CTR improvement
- **Timeline**: 3-7 days

---

### Problem: High CPC

**Root Cause Analysis:**
1. Quality Score below 6 (Google) = paying quality tax
2. Overbidding = inefficient spend
3. High competition = market saturation
4. Poor targeting = wasted impressions

**Solutions by Cause:**

**If Low Quality Score:**
Priority fixes in order:
1. **Week 1**: Improve ad relevance
   - Rewrite ads to match keywords exactly
   - Add keywords to ad headlines
   - Use dynamic keyword insertion
   
2. **Week 2**: Fix landing page experience
   - Reduce load time to <3 seconds
   - Make mobile-responsive
   - Add trust signals
   
3. **Week 3-4**: Build historical CTR
   - Test compelling ad copy
   - Add all extensions
   - Optimize for position 1-3

**Expected Results:**
- QS improvement from 4 to 7: -35% CPC
- Timeline: 4-8 weeks for full impact

**If Overbidding:**
- Test bid reductions of 10% per week
- Switch to automated bidding (Target CPA)
- Implement bid adjustments by device/location/time
- **Expected savings**: 15-30%
- **Timeline**: 1-2 weeks

**If High Competition:**
- Find less competitive long-tail keywords
- Test different match types (phrase instead of broad)
- Geo-target less competitive markets
- Shift to off-peak hours
- **Expected savings**: 20-40%
- **Timeline**: 2-4 weeks

---

### Problem: Low Conversion Rate

**Root Cause Analysis:**
1. Landing page issues = friction
2. Wrong traffic = poor targeting
3. Weak offer = insufficient value
4. Technical problems = broken experience

**Landing Page Diagnostic:**
```
Check in order:
1. Page load speed (<3s mobile) - Use PageSpeed Insights
2. Mobile responsiveness - Test on real devices
3. Headline-ad message match - Should be obvious connection
4. Clear CTA above fold - Visitor knows what to do
5. Trust signals present - Reviews, security badges, guarantees
6. Form length - Fewer fields = higher conversion
```

**Solutions:**

**Quick Wins (0-7 days):**
- Reduce form fields by 30-50%
- Make CTA button larger and contrasting color
- Add trust badges near CTA
- Remove navigation to reduce exits
- **Expected lift**: 20-40%

**Medium-Term (1-4 weeks):**
- Redesign page for mobile-first
- A/B test headlines matching top ads
- Add social proof (testimonials, reviews)
- Implement exit-intent popup
- **Expected lift**: 40-80%

**Long-Term (1-3 months):**
- Complete page redesign
- Video testimonials
- Live chat integration
- Personalization by traffic source
- **Expected lift**: 80-150%

**If Wrong Traffic:**
- Add negative keywords (Google)
- Tighten audience targeting
- Increase bid on high-converting segments
- Pause poor-performing demographics
- **Expected lift**: 30-60%
- **Timeline**: 1-2 weeks

---

### Problem: Quality Score Below 6

**Systematic QS Improvement Process:**

**Phase 1: Expected CTR (Week 1-2)**
- Write 5 new ad variations testing different hooks
- Add all relevant ad extensions
- Test different CTAs
- Bid for top 3 positions temporarily
- **Target**: Achieve >industry benchmark CTR

**Phase 2: Ad Relevance (Week 2-3)**
- Create Single Keyword Ad Groups (SKAGs) for top 20% keywords
- Include exact keyword in ad headline
- Mirror keyword in description
- Use dynamic keyword insertion where appropriate
- **Target**: Keyword in headline + description

**Phase 3: Landing Page (Week 3-6)**
- Ensure page loads in <3 seconds
- Add keyword to page title and H1
- Make content relevant to ad promise
- Optimize for mobile (80%+ mobile score)
- Remove aggressive ads/popups
- **Target**: >3s load time, mobile-optimized

**Expected Results:**
- Starting QS 3-4 → Target QS 7-8
- Timeline: 6-8 weeks for full improvement
- CPC reduction: 35-50%

---

### Problem: High Frequency (Meta)

**Frequency Thresholds:**
- 1.0-2.5: Healthy, monitor
- 2.5-3.5: Refresh soon
- 3.5-5.0: Refresh now
- 5.0+: Critical, pause immediately

**Solutions:**

**Immediate (Same Day):**
- Pause ad sets with frequency >4.0
- Launch new creative using successful concept + new hook
- **Expected**: CTR improves 50-100%

**Short-Term (1-2 weeks):**
- Develop creative rotation calendar
- Expand audience size by 2-3x
- Exclude all converters
- Test new placements (Stories, Reels)
- **Expected**: Sustained performance

**Long-Term (Monthly):**
- Build creative production pipeline (1 new creative/week)
- Create 10% lookalike audiences
- Implement campaign budget optimization
- **Expected**: Scalable performance

---

### Problem: Budget Waste

**Budget Audit Process:**

**Step 1: Identify Waste Sources**
- Bottom 20% of campaigns by ROAS
- Keywords with 0 conversions after 60 days
- Placements with CTR <50% of account average
- Geographic areas with CPA >2x account average
- Hours with CVR <50% of peak hours

**Step 2: Quantify Opportunity**
Calculate potential savings:
```
Wasted Spend = (Bottom 20% spend) × (1 - ROAS/Target ROAS)
Reallocation Impact = Wasted Spend × Top 20% ROAS
```

**Step 3: Reallocate**
- Pause bottom 10% immediately
- Reduce bottom 10-20% by 50%
- Increase top 20% by 50%
- Create test budget for new opportunities (10%)

**Expected Results:**
- 20-40% improvement in overall ROAS
- Timeline: Immediate impact, full results in 2-4 weeks

---

## Platform-Specific Optimization

### Google Ads Optimization Priorities

**Priority 1: Quality Score (Highest Impact)**
1. Fix keywords with QS 1-3 (huge CPC tax)
2. Improve keywords with QS 4-5 (quick wins)
3. Maintain keywords with QS 6+ (already good)

**Priority 2: Search Term Mining**
- Weekly review of search terms
- Add negatives (20-50 per week typical)
- Find new keyword opportunities
- Expected savings: 10-20% of spend

**Priority 3: Bid Optimization**
- Implement automated bidding (Target CPA/ROAS)
- Bid adjustments by device (-30% to +30%)
- Bid adjustments by location (+50% for top geos)
- Bid adjustments by time (+30% for peak hours)

### Meta Ads Optimization Priorities

**Priority 1: Creative Refresh**
- Monitor frequency daily
- Refresh at 3.5+ frequency
- Test 3-5 concepts per campaign
- Maintain creative backlog (10+ concepts)

**Priority 2: Audience Expansion**
- Start with 1% lookalike
- Expand to 3-5% for scale
- Test Advantage+ Audiences
- Monitor audience overlap (keep <20%)

**Priority 3: Placement Optimization**
- Analyze by placement
- Pause placements with CPA >2x average
- Test automatic placements vs manual
- Allocate 70% to best placements

### LinkedIn Optimization Priorities

**Priority 1: Audience Refinement**
- Job title targeting (not too narrow)
- Company size appropriate for product
- Seniority level matches buyer
- Location targeting

**Priority 2: Lead Form Optimization**
- Reduce fields to minimum
- Use autofill where possible
- Clear value proposition
- Follow-up promise

**Priority 3: Bid Optimization**
- Start with maximum bid
- Reduce by 10% weekly until performance drops
- Find minimum efficient bid
- Typical sweet spot: 20-30% below maximum

---

## Budget Reallocation Strategies

### Campaign-Level Reallocation

**Analysis Framework:**
1. Calculate ROAS or CPA efficiency for each campaign
2. Rank campaigns by efficiency
3. Identify top 20% and bottom 20%

**Reallocation Formula:**
```
Top 20% Budget Increase = Bottom 20% Spend × 0.7
Test Budget = Bottom 20% Spend × 0.2
Emergency Reserve = Bottom 20% Spend × 0.1
```

**Implementation:**
- Week 1: Reduce bottom 20% by 30%
- Week 2: Reduce bottom 20% by another 30%
- Week 3: Pause remaining if no improvement
- Monitor top 20% for scaling headroom

### Placement-Level Optimization (Meta)

**Placement Performance Analysis:**
| Placement | Avg CPA vs Account | Action |
|-----------|-------------------|---------|
| Feed | 0.8x | Increase 20% |
| Stories | 1.1x | Maintain |
| Reels | 0.9x | Increase 20% |
| Audience Network | 1.8x | Decrease 50% or pause |
| Messenger | 1.5x | Decrease 30% |

### Geographic Budget Optimization

**Process:**
1. Export performance by state/city
2. Calculate CPA or ROAS by location
3. Create tiers:
   - Tier 1: CPA <80% of target (increase +50%)
   - Tier 2: CPA 80-120% of target (maintain)
   - Tier 3: CPA >120% of target (decrease -50% or pause)

**Bid Adjustments:**
- Tier 1 locations: +30% to +50%
- Tier 2 locations: 0%
- Tier 3 locations: -30% to -50%

---

## Advanced Optimization Tactics

### Dayparting Optimization

**Process:**
1. Export performance by hour of day
2. Calculate CVR and CPA by hour
3. Identify top 25% hours and bottom 25% hours

**Bid Schedule:**
- Top 25% hours: +30% bid adjustment
- Middle 50%: No adjustment
- Bottom 25%: -50% bid adjustment or pause

**Expected Impact:**
- 15-25% CPA improvement
- Same conversions with less spend

### Device Optimization

**Analysis:**
1. Compare CVR by device
2. Calculate relative efficiency

**Typical Pattern:**
- Desktop: Highest CVR, lowest CTR
- Mobile: Lowest CVR, highest CTR
- Tablet: Medium on both

**Bid Adjustments:**
```
If Desktop CVR is 2x Mobile:
- Desktop: +20%
- Mobile: -20%
- Tablet: -30%
```

### Audience Segmentation

**Create Separate Campaigns:**
- Cold audiences (1-2% CPA target)
- Warm audiences (40% CPA of cold)
- Hot/Retargeting (20% CPA of cold)

**Budget Split:**
- Cold: 40% of budget
- Warm: 30% of budget
- Hot: 30% of budget

**Different Creative:**
- Cold: Education, problem-awareness
- Warm: Social proof, differentiation
- Hot: Offers, urgency, reminders

---

## Testing & Experimentation

### What to Test (Priority Order)

**High Impact Tests:**
1. Landing page redesign
2. New audience segments
3. Different offers/pricing
4. Creative concepts (Meta)
5. Bid strategies

**Medium Impact Tests:**
1. Ad copy variations
2. Headlines
3. CTA buttons
4. Form length
5. Creative hooks

**Low Impact Tests:**
1. Button colors
2. Image style
3. Minor copy tweaks
4. Logo placement

### Test Design Requirements

**Statistical Validity:**
- Minimum 100 conversions per variation
- Minimum 95% statistical confidence
- Run for minimum 2 weeks
- Control for external factors

**Budget Requirements:**
- Allocate 10-20% of budget to testing
- Split evenly between variations
- Don't test more than you can afford

---

## Automation & Scaling

### When to Use Automated Bidding

**Requirements:**
- 30+ conversions per month (minimum)
- 50+ conversions per month (recommended)
- Conversion tracking accurate
- Stable conversion rate

**Best Strategies by Goal:**
- Lead volume: Maximize Conversions
- Lead efficiency: Target CPA
- E-commerce revenue: Target ROAS
- Mixed goals: Portfolio bidding

### Scaling Guidelines

**Healthy Scaling:**
- Increase budget max 20% per week
- Monitor for CPA inflation
- Maintain minimum 2-week learning phases
- Don't scale losing campaigns

**When to Scale:**
- Impression share lost to budget >30%
- Campaign consistently hits daily budget
- ROAS >target consistently
- Learning phase complete

**Scale Limits:**
- Stop scaling if CPA increases >20%
- Don't scale faster than creative production
- Maximum 2x per month typically

---

## Maintenance & Monitoring

### Daily Tasks
- Check budget pacing
- Monitor for dramatic performance changes
- Respond to automated alerts
- Pause obvious failures

### Weekly Tasks
- Search term review + negatives (Google)
- Creative performance review (Meta)
- Audience overlap check (Meta)
- Budget reallocation analysis
- Quality Score review (Google)

### Monthly Tasks
- Full account audit
- Competitive analysis
- Landing page testing
- Creative refresh planning
- Strategic review

### Quarterly Tasks
- Account restructure (if needed)
- Historical trend analysis
- Industry benchmark comparison
- Annual planning
- Major landing page overhauls
