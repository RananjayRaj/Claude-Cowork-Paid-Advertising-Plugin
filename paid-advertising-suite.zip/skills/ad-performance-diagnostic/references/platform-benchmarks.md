# Platform Benchmarks & Industry Standards

## Cross-Platform Performance Benchmarks

### Click-Through Rate (CTR) Benchmarks

**Google Search Ads (by Industry)**
| Industry | Average CTR | Good CTR | Excellent CTR |
|----------|-------------|----------|---------------|
| Legal | 3.84% | 5-7% | 8%+ |
| E-commerce | 2.69% | 4-5% | 6%+ |
| B2B Technology | 2.41% | 4-5% | 6%+ |
| Real Estate | 3.71% | 5-6% | 7%+ |
| Travel & Hospitality | 4.68% | 6-8% | 9%+ |
| Healthcare | 3.27% | 5-6% | 7%+ |
| Financial Services | 2.91% | 4-5% | 6%+ |
| Education | 3.78% | 5-6% | 7%+ |

**Google Display Network**
| Placement Type | Average CTR |
|----------------|-------------|
| Standard Display | 0.46% |
| Remarketing | 0.89% |
| Gmail Ads | 0.21% |
| YouTube | 0.65% |

**Meta Platforms (Facebook/Instagram)**
| Ad Format | Average CTR | Good CTR | Excellent CTR |
|-----------|-------------|----------|---------------|
| Feed Image | 0.90% | 1.5-2.0% | 2.5%+ |
| Feed Video | 1.32% | 2.0-2.5% | 3.0%+ |
| Feed Carousel | 1.12% | 1.8-2.3% | 2.8%+ |
| Story Ads | 1.94% | 2.5-3.5% | 4.0%+ |
| Reel Ads | 2.54% | 3.5-4.5% | 5.0%+ |

**LinkedIn Ads**
| Ad Format | Average CTR |
|-----------|-------------|
| Sponsored Content | 0.56% |
| Sponsored InMail | 3.19% |
| Text Ads | 0.025% |
| Dynamic Ads | 0.037% |

**TikTok Ads**
| Average CTR: 1.52% |
| Good CTR: 2.0-3.0% |
| Excellent CTR: 4.0%+ |

### Cost Per Click (CPC) Benchmarks

**Google Search (by Industry)**
| Industry | Average CPC | Competitive CPC |
|----------|-------------|-----------------|
| Legal | $6.75 | $10-50 |
| Insurance | $5.65 | $8-30 |
| E-commerce | $1.16 | $1.50-3.00 |
| B2B Technology | $3.33 | $5-15 |
| Real Estate | $2.37 | $3-8 |
| Healthcare | $2.62 | $4-10 |
| Financial Services | $3.44 | $5-20 |
| Education | $2.40 | $3-8 |
| Travel | $1.53 | $2-5 |

**Google Display Network**
- Average CPC: $0.63
- Range: $0.30-$2.00

**Meta Platforms**
| Industry | Average CPC |
|----------|-------------|
| Finance/Insurance | $3.77 |
| B2B | $2.80 |
| Consumer Services | $2.62 |
| E-commerce | $1.20 |
| Technology | $1.99 |
| Healthcare | $1.63 |
| Retail | $0.70 |

**LinkedIn Ads**
- Average CPC: $5.26
- Range: $2.00-$15.00
- Higher for senior decision-makers ($8-$20)

### Conversion Rate Benchmarks

**Google Search (by Industry)**
| Industry | Average CVR | Good CVR | Excellent CVR |
|----------|-------------|----------|---------------|
| Legal | 6.98% | 10-15% | 18%+ |
| E-commerce | 2.81% | 4-6% | 8%+ |
| B2B | 3.04% | 5-8% | 10%+ |
| Real Estate | 2.47% | 4-6% | 8%+ |
| Healthcare | 3.36% | 5-7% | 9%+ |
| Financial Services | 5.10% | 8-12% | 15%+ |
| Education | 3.39% | 5-8% | 10%+ |

**Meta Platforms**
- Average CVR: 9.21% (landing page view to conversion)
- E-commerce: 2-4%
- B2B Lead Gen: 5-10%
- Local Services: 8-15%

**LinkedIn**
- Average CVR: 6.1% (form fill)
- Good: 10-15%
- Excellent: 18%+

### Cost Per Acquisition (CPA) Benchmarks

**By Industry & Business Model**

**E-commerce**
| AOV Range | Target CPA | Max Acceptable CPA |
|-----------|------------|---------------------|
| $0-$50 | $10-$20 | $30 |
| $51-$100 | $15-$35 | $50 |
| $101-$200 | $25-$60 | $100 |
| $201-$500 | $50-$150 | $250 |
| $500+ | $100-$300 | $500 |

**B2B (by ACV)**
| Annual Contract Value | Target CPA | Max Acceptable |
|----------------------|------------|----------------|
| <$5K | $50-$200 | $500 |
| $5K-$25K | $200-$1,000 | $2,000 |
| $25K-$100K | $1,000-$3,000 | $5,000 |
| $100K-$500K | $3,000-$10,000 | $15,000 |
| $500K+ | $10,000-$50,000 | $100,000 |

**Lead Generation (Local Services)**
| Service Type | Target CPA | Max Acceptable |
|--------------|------------|----------------|
| HVAC | $30-$80 | $150 |
| Plumbing | $35-$90 | $160 |
| Roofing | $50-$150 | $250 |
| Solar | $100-$300 | $500 |
| Legal Consultation | $75-$200 | $400 |
| Real Estate Agent | $40-$100 | $200 |

### Return on Ad Spend (ROAS) Benchmarks

**By Industry**
| Industry | Break-Even ROAS | Good ROAS | Excellent ROAS |
|----------|-----------------|-----------|----------------|
| E-commerce (General) | 2.0x | 4.0x | 6.0x+ |
| E-commerce (Luxury) | 1.5x | 3.0x | 5.0x+ |
| B2B SaaS | 3.0x | 5.0x | 8.0x+ |
| Lead Generation | 2.5x | 4.0x | 6.0x+ |
| Local Services | 3.0x | 5.0x | 7.0x+ |
| Professional Services | 4.0x | 6.0x | 10.0x+ |
| Retail | 2.0x | 3.5x | 5.0x+ |

**By Campaign Type**
| Campaign Type | Target ROAS |
|---------------|-------------|
| Cold Prospecting | 1.5-3.0x |
| Warm Audiences | 3.0-5.0x |
| Retargeting | 5.0-10.0x |
| Brand Search | 8.0-15.0x |

### Impression Share Benchmarks (Google Ads)

**By Keyword Category**
| Keyword Type | Target IS | Acceptable IS |
|--------------|-----------|---------------|
| Brand Terms | 95-100% | 90%+ |
| High-Intent Commercial | 70-90% | 60%+ |
| Generic Category | 50-70% | 40%+ |
| Competitor Terms | 30-50% | 20%+ |
| Research/Informational | 30-50% | 20%+ |

**Impression Share Lost To:**
- Budget: <10% acceptable, <5% ideal
- Rank: <15% acceptable, <10% ideal

---

## Platform-Specific Metrics

### Google Ads Quality Score Benchmarks

**Quality Score Distribution (Healthy Accounts)**
| Score | % of Keywords |
|-------|---------------|
| 8-10 | 40-60% |
| 6-7 | 30-40% |
| 4-5 | 10-20% |
| 1-3 | 0-5% |

**Average Quality Score by Industry**
| Industry | Average QS |
|----------|------------|
| Legal | 6.8 |
| E-commerce | 7.2 |
| B2B Technology | 6.9 |
| Real Estate | 7.0 |
| Healthcare | 7.1 |
| Financial Services | 6.7 |

**Quality Score Impact on CPC**
| Quality Score | CPC Impact vs QS 5 |
|---------------|---------------------|
| 10 | -50% |
| 9 | -44% |
| 8 | -37.5% |
| 7 | -28.5% |
| 6 | -16.7% |
| 5 | Baseline (0%) |
| 4 | +25% |
| 3 | +67% |
| 2 | +150% |
| 1 | +400% |

### Meta Relevance Score Benchmarks

**Relevance Score Distribution (Healthy Accounts)**
| Score | Meaning | % of Ads |
|-------|---------|----------|
| Above Average | Top 35% of ads | 30-40% |
| Average | Middle 30% | 40-50% |
| Below Average | Bottom 35% | 10-20% |

**Frequency Thresholds**
| Frequency | Status | Action Needed |
|-----------|--------|---------------|
| 1.0-2.0 | Healthy | Monitor |
| 2.0-3.0 | Good | Plan refresh |
| 3.0-4.0 | Warning | Refresh soon |
| 4.0-5.0 | Critical | Refresh now |
| 5.0+ | Severe Fatigue | Pause & refresh |

**Engagement Rate Benchmarks**
| Engagement Rate | Rating |
|----------------|---------|
| >4% | Excellent |
| 2-4% | Good |
| 1-2% | Average |
| 0.5-1% | Below Average |
| <0.5% | Poor |

### LinkedIn Relevance Score

**Score Ranges**
- 8-10: Excellent (top 10% of ads)
- 6-7: Good (above average)
- 4-5: Average
- 2-3: Below average
- 0-1: Poor (bottom 10%)

**Ideal Performance Metrics**
- CTR: >0.8%
- Engagement Rate: >3%
- Lead Form Completion: >50%

---

## Device Performance Benchmarks

### Mobile vs Desktop Performance

**CTR by Device (Google Search)**
| Industry | Mobile CTR | Desktop CTR |
|----------|-----------|-------------|
| E-commerce | 3.2% | 2.4% |
| B2B | 2.1% | 2.8% |
| Local Services | 4.5% | 3.1% |
| Finance | 2.5% | 3.4% |

**Conversion Rate by Device**
| Industry | Mobile CVR | Desktop CVR |
|----------|-----------|-------------|
| E-commerce | 1.8% | 3.9% |
| B2B | 2.1% | 4.6% |
| Local Services | 5.2% | 4.8% |
| Finance | 3.1% | 6.8% |

**Average CPC by Device**
- Mobile: 20-30% lower than desktop
- Tablet: 10-20% lower than desktop

**Optimal Device Bid Adjustments**
| Device | Typical Adjustment |
|--------|-------------------|
| Desktop | Baseline (0%) |
| Mobile | -20% to +10% depending on CVR |
| Tablet | -30% to -10% |

---

## Geographic Performance Benchmarks

### US Metropolitan Performance Tiers

**Tier 1 Markets (Highest CPC, Highest Competition)**
| Metro | Avg CPC Multiplier |
|-------|-------------------|
| San Francisco | 1.8x |
| New York | 1.7x |
| Los Angeles | 1.5x |
| Seattle | 1.5x |
| Boston | 1.4x |

**Tier 2 Markets (Moderate CPC)**
| Metro | Avg CPC Multiplier |
|-------|-------------------|
| Chicago | 1.2x |
| Dallas | 1.1x |
| Atlanta | 1.1x |
| Philadelphia | 1.2x |

**Tier 3 Markets (Lower CPC)**
- Average multiplier: 0.8-1.0x
- Generally better ROAS due to lower competition
- May have lower volume

### International Performance

**CPC by Country (Relative to US)**
| Country | CPC vs US |
|---------|-----------|
| United States | 1.0x (baseline) |
| United Kingdom | 0.9x |
| Canada | 0.85x |
| Australia | 0.95x |
| Germany | 0.7x |
| France | 0.65x |
| India | 0.15x |
| Brazil | 0.35x |

---

## Temporal Performance Patterns

### Day-of-Week Performance (B2B)

**CTR by Day**
| Day | CTR Index |
|-----|-----------|
| Monday | 105 |
| Tuesday | 110 |
| Wednesday | 115 |
| Thursday | 108 |
| Friday | 95 |
| Saturday | 70 |
| Sunday | 68 |

**Conversion Rate by Day**
| Day | CVR Index |
|-----|-----------|
| Tuesday | 120 |
| Wednesday | 118 |
| Thursday | 115 |
| Monday | 100 |
| Friday | 85 |
| Saturday | 45 |
| Sunday | 42 |

### Day-of-Week Performance (B2C E-commerce)

**CTR by Day**
| Day | CTR Index |
|-----|-----------|
| Monday | 92 |
| Tuesday | 95 |
| Wednesday | 98 |
| Thursday | 105 |
| Friday | 110 |
| Saturday | 108 |
| Sunday | 112 |

**Conversion Rate by Day**
| Day | CVR Index |
|-----|-----------|
| Sunday | 115 |
| Saturday | 110 |
| Monday | 105 |
| Friday | 100 |
| Thursday | 98 |
| Wednesday | 95 |
| Tuesday | 92 |

### Hour-of-Day Performance (General)

**B2B Peak Hours**
- 9-11 AM: Highest engagement
- 1-3 PM: Good performance
- 8-9 AM: Moderate
- 4-5 PM: Declining
- After 6 PM: Low performance

**B2C Peak Hours**
- 7-9 PM: Highest (leisure time)
- 12-1 PM: Good (lunch break)
- 5-7 PM: Good (commute/after work)
- 9-11 PM: Moderate
- Night/Early AM: Low

---

## Audience Performance Benchmarks

### Cold vs Warm vs Hot Traffic

**Performance Comparison**
| Audience Type | CTR | CVR | CPA Index |
|---------------|-----|-----|-----------|
| Cold (New) | 1.0x | 1.0x | 1.0x (baseline) |
| Warm (Engaged) | 2.0x | 2.5x | 0.4x |
| Hot (Retargeting) | 3.0x | 5.0x | 0.2x |

### Lookalike Audience Performance (Meta)

**By Lookalike Percentage**
| LAL % | CTR vs 1% | CVR vs 1% | Volume |
|-------|-----------|-----------|---------|
| 1% | 1.0x | 1.0x | Low |
| 2-3% | 0.9x | 0.8x | Medium |
| 5% | 0.8x | 0.6x | High |
| 10% | 0.6x | 0.4x | Very High |

**Optimization Strategy:**
- Start with 1-2% for quality
- Expand to 5% for scale
- Use 10% for awareness/reach

---

## Budget & Bidding Benchmarks

### Minimum Budget Requirements by Platform

**Google Ads (Search)**
- Test Campaign: $500-$1,000/month minimum
- Single Campaign: $1,500-$3,000/month
- Account with 5+ campaigns: $5,000-$10,000/month

**Meta Ads**
- Test Campaign: $300-$500/month
- Single Campaign: $1,000-$2,000/month
- Full account: $3,000-$5,000/month

**LinkedIn Ads**
- Minimum: $1,500/month per campaign
- Recommended: $3,000-$5,000/month
- Large-scale: $10,000+/month

### Learning Phase Requirements

**Google Smart Bidding**
- Minimum: 30 conversions in 30 days
- Optimal: 50+ conversions in 30 days

**Meta Campaign Budget Optimization**
- Minimum: 50 optimization events per week per ad set
- Optimal: 100+ events per week

### Bid Strategy Performance

**Google Ads Bid Strategy Success Rates**
| Strategy | Use Case | Success Rate |
|----------|----------|--------------|
| Target CPA | Lead gen, e-commerce | 75% |
| Target ROAS | E-commerce with LTV data | 80% |
| Maximize Conversions | Sufficient budget | 70% |
| Manual CPC | Testing, tight control | 60% |
| Enhanced CPC | Transitioning to automated | 65% |

---

## Creative Performance Standards

### Video Performance Benchmarks

**View-Through Rates (VTR)**
| Platform | 25% VTR | 50% VTR | 75% VTR | 100% VTR |
|----------|---------|---------|---------|----------|
| YouTube | 50% | 35% | 25% | 15% |
| Meta Feed | 45% | 30% | 20% | 10% |
| Meta Story | 65% | 45% | 30% | 18% |
| LinkedIn | 40% | 25% | 15% | 8% |

**Optimal Video Lengths**
- YouTube: 15-30s (skippable), 6s (bumper)
- Meta Feed: 15-60s
- Meta Story/Reel: 7-15s
- LinkedIn: 15-30s

### Image Ad Performance

**Meta Image Ad Benchmarks**
- Text in image: <20% for best delivery
- With faces: +25% engagement vs without
- Bright colors: +30% CTR vs muted
- Lifestyle vs product-only: +40% CTR

---

## Seasonal & Market Factors

### Seasonality Impact (E-commerce)

**CPM Inflation by Period**
| Period | CPM vs Baseline |
|--------|----------------|
| Q1 (Jan-Mar) | 0.8-0.9x |
| Q2 (Apr-Jun) | 0.9-1.0x |
| Q3 (Jul-Sep) | 1.0-1.1x |
| Q4 (Oct-Nov) | 1.3-1.5x |
| Black Friday/Cyber Monday | 2.0-3.0x |
| Week before Christmas | 1.8-2.2x |

**Conversion Rate Seasonality**
- Black Friday: +50-100% vs baseline
- Cyber Monday: +40-80% vs baseline
- Post-holiday (Jan): -20-30% vs baseline
- Back-to-school (Aug): +30-50% for relevant categories

---

## Attribution & Tracking Standards

### Conversion Window Benchmarks

**Standard Attribution Windows**
| Platform | Click Attribution | View Attribution |
|----------|------------------|------------------|
| Google Ads | 30 days | N/A (search) |
| Meta | 7 days default | 1 day default |
| LinkedIn | 30 days | N/A |

**Optimal Windows by Industry**
- B2B (long sales cycle): 30-90 day click
- E-commerce (impulse): 7-day click
- Lead gen (medium): 14-30 day click

### Multi-Touch Attribution Impact

**Channel Contribution (Typical)**
- First-touch: 30-40% of value
- Mid-touch: 30-40% of value
- Last-touch: 30-40% of value

**Don't over-attribute to last touch alone**
