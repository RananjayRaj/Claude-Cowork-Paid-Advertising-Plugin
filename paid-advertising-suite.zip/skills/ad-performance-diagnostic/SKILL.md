---
name: ad-performance-diagnostic
description: Analyze campaign data and provide optimization recommendations including performance analysis, quality score factors, bid optimization, and budget reallocation
---

# Ad Performance Diagnostic

Analyzes advertising campaign data to identify performance issues, diagnose root causes, and provide specific, actionable optimization recommendations across all major platforms (Google Ads, Meta, LinkedIn, etc.).

## How to Use This Skill

### Quick Start
1. Share your campaign data (CSV, screenshot, or describe metrics)
2. Specify your platform (Google Ads, Meta, LinkedIn, etc.)
3. Receive diagnostic analysis with prioritized recommendations

### What You'll Need
- Campaign performance metrics (CTR, CPC, conversion rate, ROAS, etc.)
- Platform (Google Ads, Meta, LinkedIn, TikTok, etc.)
- Campaign objective (awareness, leads, conversions, etc.)
- Time period for analysis (last 7/30/90 days)

## Core Workflow

When you provide campaign data, I will:

1. **Performance Analysis** - Compare your metrics against benchmarks
2. **Issue Identification** - Diagnose specific problems and root causes
3. **Priority Ranking** - Rank issues by impact potential
4. **Recommendation Generation** - Provide specific, actionable fixes
5. **Implementation Roadmap** - Sequence optimizations for maximum impact

## What I Analyze

### Performance Metrics
- **CTR (Click-Through Rate)**: Hook strength and relevance
- **CPC (Cost Per Click)**: Bidding efficiency and competition
- **Conversion Rate**: Landing page and offer quality
- **Quality Score**: Ad relevance, landing page experience, expected CTR
- **ROAS/CPA**: Overall campaign profitability
- **Impression Share**: Budget and bid adequacy

### Platform-Specific Factors

**Google Ads:**
- Quality Score components (1-10 scale)
- Ad Rank and auction insights
- Search impression share metrics
- Keyword-level performance
- Ad extensions utilization

**Meta (Facebook/Instagram):**
- Relevance Score/Quality Ranking
- Engagement Rate
- Frequency and ad fatigue
- Audience overlap
- Placement performance

**LinkedIn:**
- Relevance Score
- Social engagement metrics
- Lead form completion rates
- Audience targeting precision

## Diagnostic Frameworks

### The Performance Pyramid
```
         ROAS/CPA (Business Outcome)
              ↑
        Conversion Rate
              ↑
         CTR × Landing Page
              ↑
    Impressions × Quality Score
```

I analyze each level to identify where the breakdown occurs.

## Example Requests

**Simple Analysis:**
"My Google Ads campaign has a 0.5% CTR and $15 CPC. Industry is B2B SaaS. What's wrong?"

**Data Upload:**
"Here's my campaign export from the last 30 days. Find the biggest opportunities."

**Platform-Specific:**
"My Meta ads have 4.2 frequency but only 0.8% CTR. How do I fix creative fatigue?"

**Quality Score Focus:**
"My Quality Scores are 3-5 across keywords. Help me improve them."

**Budget Optimization:**
"I have 15 campaigns. How should I reallocate my $50K monthly budget?"

## Analysis Components

### 1. Benchmark Comparison
I compare your metrics against:
- Industry averages
- Platform standards
- Historical performance (if provided)
- Best-in-class benchmarks

### 2. Root Cause Diagnosis
For each underperforming metric, I identify:
- **Primary driver**: Main cause of the issue
- **Contributing factors**: Secondary influences
- **Severity**: Impact on overall performance
- **Fix difficulty**: Easy, medium, or hard

### 3. Prioritized Recommendations
Recommendations are ranked by:
- **Impact**: Expected performance lift
- **Effort**: Implementation difficulty
- **Timeline**: How quickly you'll see results
- **Dependencies**: What needs to happen first

### 4. Implementation Roadmap
I provide a sequenced action plan:
- **Quick wins** (0-7 days): High impact, low effort
- **Core optimizations** (1-4 weeks): Structural improvements
- **Advanced tactics** (1-3 months): Long-term enhancements

## Platform-Specific Diagnostics

### Google Ads
- Quality Score improvement strategies
- Bid strategy optimization
- Keyword match type recommendations
- Ad copy testing priorities
- Extension opportunities
- Negative keyword mining

### Meta Ads
- Creative fatigue detection
- Audience overlap analysis
- Placement optimization
- Frequency capping recommendations
- Budget pacing adjustments
- Creative refresh timing

### LinkedIn Ads
- Audience targeting refinement
- Bid optimization for professional audiences
- Lead form optimization
- Content relevance improvements

## Budget Reallocation Framework

When analyzing multiple campaigns, I provide:

**Current State Analysis:**
- Spend distribution
- Performance by campaign
- Efficiency metrics (CPA, ROAS by campaign)

**Recommended Reallocation:**
- Move budget from low performers to high performers
- Test budget for new opportunities
- Reserve budget for seasonality
- Specific $ amounts per campaign

**Expected Impact:**
- Projected performance improvement
- Risk assessment
- Timeline for evaluation

## Quality Score Deep Dive

For Google Ads Quality Score issues, I analyze:

### Expected CTR
- Historical CTR by keyword
- Ad copy relevance
- Ad extensions usage
- Position impact

### Ad Relevance
- Keyword-to-ad alignment
- Ad copy specificity
- Call-to-action clarity
- Landing page promise match

### Landing Page Experience
- Page load speed
- Mobile optimization
- Content relevance
- Conversion path clarity
- Trust signals

## Advanced Features

### Anomaly Detection
I identify unusual patterns:
- Sudden performance drops
- Seasonal variations
- Day-of-week patterns
- Hour-of-day opportunities

### Competitive Analysis
When possible, I assess:
- Impression share lost to competitors
- Auction insights patterns
- Market saturation indicators

### Creative Performance
I evaluate:
- Ad copy effectiveness
- Creative fatigue indicators
- A/B test result interpretation
- Format performance comparison

## Integration with Other Skills

Works seamlessly with:
- **Creative Testing Framework** - Design tests based on diagnostic findings
- **Negative Keyword Miner** - Clean up poor performers
- **Attribution Modeling Advisor** - Understand full customer journey
- **Cohort Analysis Builder** - Deeper retention analysis

## Reference Materials

For detailed methodologies, I access:
- `references/diagnostic-framework.md` - Analysis methodologies
- `references/platform-benchmarks.md` - Industry performance standards
- `references/optimization-playbook.md` - Fix strategies by issue type
- `references/quality-score-guide.md` - Google Ads Quality Score deep dive

## Output Formats

Choose your preferred format:
- **Executive Summary** (1 page, priorities only)
- **Full Diagnostic Report** (comprehensive analysis)
- **Quick Wins List** (immediate actions only)
- **Campaign Comparison** (side-by-side performance)
- **Budget Reallocation Plan** (specific $ recommendations)

## Tips for Best Results

1. **Provide Context**: Industry, campaign objective, target audience
2. **Include Timeframe**: Performance period and any major changes
3. **Share Constraints**: Budget limits, brand guidelines, platform restrictions
4. **Mention Goals**: Target CPA, ROAS, or other KPIs
5. **Include Historical Data**: Trends reveal more than snapshots

## Common Issues Diagnosed

### Low CTR
- Weak ad copy
- Poor targeting
- Ad fatigue
- Low ad rank/position

### High CPC
- Overbidding
- Low Quality Score
- Intense competition
- Broad targeting

### Low Conversion Rate
- Landing page issues
- Offer misalignment
- Targeting wrong audience
- Friction in conversion path

### Quality Score Issues
- Keyword-ad-landing page misalignment
- Poor historical CTR
- Landing page experience problems
- Low ad relevance

### Budget Waste
- Poor campaign allocation
- Broad match keywords draining budget
- Underperforming placements
- Geographic inefficiencies

---

**Ready to diagnose your campaigns?** Share your performance data and I'll identify the issues holding you back with specific recommendations to fix them.
