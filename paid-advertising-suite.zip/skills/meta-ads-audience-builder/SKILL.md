---
name: meta-ads-audience-builder
description: Design and optimize Meta Ads audiences for maximum signal quality and delivery efficiency. Build prospecting, lookalike, and retargeting segments aligned with Andromeda's AI-driven delivery system. Manage audience overlap, exclusions, funnel alignment, and continuous optimization using performance data. Use when creating new Meta audiences, auditing existing audience structure, reducing overlap, improving signal quality, or aligning audiences to creative strategy and funnel stages.
---

# Meta Ads Audience Builder

Strategic framework for designing, building, and optimizing Meta Ads audiences aligned with Andromeda's AI-driven delivery system (2025). Shifts focus from hyper-segmentation to high-signal audience architecture that feeds the algorithm effectively.

## What This Skill Does

Designs and optimizes Meta Ads audiences across 6 key dimensions:

1. **Audience Architecture Design** - Structure audiences for Andromeda's broad-first approach
2. **Custom Audience Building** - Website, engagement, customer list, and app audiences
3. **Lookalike Strategy** - Seed quality, percentage testing, and signal optimization
4. **Retargeting Framework** - Funnel-aligned retargeting with proper windows
5. **Overlap & Exclusion Management** - Prevent cannibalization and wasted spend
6. **Signal Quality Optimization** - Maximize audience value for algorithm learning

**Output**: Complete audience strategy with specific audience definitions, naming conventions, exclusion rules, and testing roadmap.

## Andromeda Context: The New Audience Paradigm

Andromeda fundamentally changed audience strategy in 2025:

**Old Paradigm (Pre-Andromeda)**:
- Hyper-segmentation by interest stacking
- Many narrow ad sets competing
- Lookalikes as hard targeting boundaries
- Manual audience testing and optimization

**New Paradigm (Andromeda)**:
- Broad targeting with algorithm optimization
- Consolidated campaigns, fewer ad sets
- Lookalikes as signal inputs, not boundaries
- Creative diversity as primary targeting lever

**Key Insight**: Audiences now serve as *signals* to guide Andromeda, not *constraints* that limit reach. The algorithm expands beyond your defined audience based on behavioral signals from your creative.

## Audience Types Overview

### 1. Prospecting Audiences (Cold)

**Purpose**: Reach new potential customers

| Type | When to Use | Andromeda Alignment |
|------|-------------|---------------------|
| Broad (country-wide) | Default for scale | ✅ Preferred |
| Advantage+ Audience | AI-optimized prospecting | ✅ Highly recommended |
| Interest-based | Specific niches only | ⚠️ Use sparingly |
| Lookalike (1-10%) | Guided prospecting | ✅ As signals |

### 2. Retargeting Audiences (Warm/Hot)

**Purpose**: Re-engage people who know your brand

| Type | Funnel Stage | Typical Window |
|------|--------------|----------------|
| Website visitors | Mid-funnel | 30-180 days |
| Product viewers | Mid-funnel | 14-60 days |
| Add to cart | Bottom-funnel | 7-30 days |
| Checkout initiated | Bottom-funnel | 3-14 days |
| Engagement (IG/FB) | Top-funnel | 30-365 days |
| Video viewers | Top-funnel | 30-180 days |

### 3. Customer Audiences (Existing)

**Purpose**: Retention, upsell, exclusions

| Type | Use Case | Update Frequency |
|------|----------|------------------|
| All purchasers | Exclusions, lookalike seed | Weekly-monthly |
| High-value customers | Premium lookalike seed | Monthly |
| Lapsed customers | Win-back campaigns | Monthly |
| Subscribers/members | Retention, exclusions | Auto-sync preferred |

## Audience Architecture Framework

### Recommended Structure for Andromeda

```
Campaign: [Objective]
├── Ad Set 1: Broad Prospecting
│   ├── Targeting: Advantage+ or Country-wide
│   ├── Exclusions: Purchasers (180d), Website visitors (30d)
│   └── Budget: 60-70% of campaign
│
├── Ad Set 2: Lookalike Stack (Optional)
│   ├── Targeting: LAL 1-5% combined
│   ├── Exclusions: Purchasers (180d)
│   └── Budget: 20-30% of campaign
│
└── Ad Set 3: Retargeting
    ├── Targeting: Website + Engagement audiences
    ├── Exclusions: Purchasers (7-30d)
    └── Budget: 10-20% of campaign
```

### Simplified Structure (Andromeda-Optimized)

For maximum Andromeda efficiency:

```
Campaign: [Objective]
└── Ad Set: Combined Prospecting + Signals
    ├── Targeting: Advantage+ Audience
    ├── Suggested Audiences: LAL Purchasers 1%, Engagers 90d
    ├── Exclusions: Recent purchasers
    └── Budget: 100% (algorithm distributes)
```

## Custom Audience Building Guide

### Website Audiences (Meta Pixel Required)

| Audience | Event/Rule | Suggested Window | Use Case |
|----------|------------|------------------|----------|
| All visitors | PageView | 180 days | Broad retargeting |
| Engaged visitors | 3+ page views OR 2+ min on site | 90 days | Quality retargeting |
| Product viewers | ViewContent | 30-60 days | Product retargeting |
| Category viewers | URL contains /category/ | 30 days | Category campaigns |
| Cart abandoners | AddToCart NOT Purchase | 14-30 days | Recovery campaigns |
| Checkout abandoners | InitiateCheckout NOT Purchase | 7-14 days | High-intent recovery |
| Pricing page viewers | URL contains /pricing | 30 days | High-intent B2B |
| Blog readers | URL contains /blog | 90-180 days | Content nurturing |

**Naming Convention**: `[Source]_[Action]_[Window]_[Date]`
Example: `WEB_AddToCart_30d_2025-01`

### Engagement Audiences (Platform Data)

| Audience | Definition | Window | Signal Strength |
|----------|------------|--------|-----------------|
| IG profile visitors | Visited Instagram profile | 90-365 days | Medium |
| FB page engagers | Any page engagement | 90-365 days | Medium |
| Post engagers | Liked, commented, shared, saved | 90-365 days | High |
| Video viewers (25%) | Watched 25%+ of video | 365 days | Low-Medium |
| Video viewers (75%) | Watched 75%+ of video | 365 days | High |
| Video viewers (95%) | Watched 95%+ of video | 365 days | Very High |
| Lead form openers | Opened lead form | 90 days | High |
| Lead form submitters | Submitted lead form | 90 days | Very High |
| IG Shop engagers | Browsed/saved products | 90-365 days | High |
| Reel engagers | Engaged with Reels | 365 days | Medium-High |

### Customer List Audiences

| List Type | Match Rate Target | Refresh Cadence |
|-----------|-------------------|-----------------|
| All customers | 40-70% | Weekly-monthly |
| High-value (top 20% LTV) | 50-80% | Monthly |
| Recent purchasers (90d) | 50-80% | Weekly |
| Lapsed (no purchase 180d+) | 30-50% | Monthly |
| Email subscribers | 40-60% | Weekly |
| Newsletter engaged | 50-70% | Weekly |

**Required Identifiers** (for best match rates):
- Email (hashed) - Critical
- Phone (hashed) - High impact
- First name, Last name - Medium impact
- City, State, Zip - Lower impact
- External ID - High impact if consistent

## Lookalike Audience Strategy

### Seed Quality Hierarchy

Best seeds for lookalikes (ranked by signal strength):

| Rank | Seed Source | Why It Works |
|------|-------------|--------------|
| 1 | High-LTV customers (top 10-20%) | Strongest purchase signal |
| 2 | Repeat purchasers | Proven loyalty signal |
| 3 | All purchasers | Clear conversion signal |
| 4 | Add-to-cart (purchase excluded) | High intent signal |
| 5 | 75%+ video viewers | Strong engagement signal |
| 6 | Lead form submitters | Conversion signal |
| 7 | Email subscribers | Interest signal |
| 8 | Website visitors (90d+) | Awareness signal |

### Lookalike Percentage Testing

| Percentage | Audience Size | Use Case |
|------------|---------------|----------|
| 1% | ~2.3M (US) | Highest similarity, smaller scale |
| 1-3% | ~7M (US) | Balance of quality and scale |
| 3-5% | ~11.5M (US) | Broader reach, good for scaling |
| 5-10% | ~23M (US) | Maximum scale, lower precision |

**Andromeda Recommendation**: Start with 1-3% for quality, let Advantage+ expand. The algorithm will find additional users beyond your defined percentage.

### Lookalike Stacking Strategy

Combine multiple lookalikes in one ad set as signals:

```
Ad Set: Prospecting with LAL Signals
├── LAL 1% - Purchasers
├── LAL 1% - High-value customers
├── LAL 3% - Add to cart
└── Advantage+ Audience: ON
```

This gives Andromeda multiple signal sources while allowing expansion.

## Exclusion Strategy

### Standard Exclusions by Objective

**Purchase/Sales Campaigns**:
- Exclude: Purchasers (30-180 days, depending on repurchase cycle)
- Consider: Exclude cart abandoners from prospecting (retarget separately)

**Lead Generation**:
- Exclude: Existing leads (form submitters)
- Exclude: Current customers
- Exclude: Low-quality leads (if identifiable)

**Brand Awareness**:
- Exclude: Recent engagers (to maximize new reach)
- Optional: Exclude existing customers

### Exclusion Window Guidelines

| Product Type | Exclusion Window |
|--------------|------------------|
| One-time purchase | 180 days |
| Monthly subscription | 30-60 days |
| Consumables (replenish) | Match repurchase cycle (30-90 days) |
| High-consideration | 180 days |
| Frequent purchase | 7-14 days |

### Critical Exclusions Checklist

- [ ] Exclude purchasers from prospecting campaigns
- [ ] Exclude retargeting audiences from broad prospecting
- [ ] Exclude low-intent segments from bottom-funnel
- [ ] Exclude employees/team (if applicable)
- [ ] Exclude existing leads from lead gen
- [ ] Exclude irrelevant geos if targeting is broad

## Overlap Management

### Detecting Overlap

Signs of audience overlap issues:
- Same users seeing multiple ad sets
- Increasing frequency on multiple campaigns
- Cannibalizing your own auction
- Inconsistent delivery across ad sets

### Overlap Prevention Strategies

1. **Consolidate Ad Sets**: Fewer ad sets = less overlap
2. **Clear Exclusions**: Each ad set excludes audiences in other ad sets
3. **Funnel Separation**: Prospect vs retarget clearly separated
4. **Advantage+ Preference**: Let algorithm handle distribution

### Overlap Audit Questions

1. Are multiple ad sets targeting the same website visitors?
2. Do lookalikes overlap significantly with custom audiences?
3. Are engaged users in both prospecting and retargeting?
4. Is frequency rising due to audience overlap?

## Funnel-Aligned Audience Strategy

### TOFU (Top of Funnel) - Awareness

**Audiences**: Broad, Advantage+, Interest-based, Cold lookalikes
**Goal**: Maximum reach to qualified prospects
**Exclusions**: Recent engagers, website visitors, customers
**Creative**: Brand-focused, educational, problem-aware

### MOFU (Middle of Funnel) - Consideration

**Audiences**: Website visitors, engagement audiences, video viewers
**Goal**: Nurture awareness into consideration
**Exclusions**: Cart abandoners, purchasers
**Creative**: Product-focused, social proof, comparison

### BOFU (Bottom of Funnel) - Conversion

**Audiences**: Cart abandoners, checkout abandoners, high-intent visitors
**Goal**: Convert high-intent users
**Exclusions**: Recent purchasers
**Creative**: Urgency, offers, testimonials, guarantees

## Audience Building Workflow

### Step 1: Foundation Audiences (Create First)

1. All purchasers (180 days)
2. All website visitors (180 days)
3. All IG/FB engagers (365 days)
4. Cart abandoners (30 days)
5. Video viewers 75%+ (365 days)

### Step 2: Segmented Audiences

1. High-value purchasers (top 20%)
2. Repeat purchasers
3. Product/category viewers
4. Pricing/key page visitors
5. Email subscribers

### Step 3: Lookalike Creation

1. LAL 1% - High-value customers
2. LAL 1% - All purchasers
3. LAL 1-3% - Cart abandoners
4. LAL 3-5% - Engagers (for scale)

### Step 4: Audience Mapping

Map audiences to campaign structure:
- Prospecting: Broad + LAL signals
- Retargeting: Website + engagement
- Retention: Customer audiences

## Signal Quality Optimization

### Improving Audience Signal Strength

| Action | Impact |
|--------|--------|
| Use CAPI for website audiences | Higher match rates |
| Regular customer list updates | Fresh signals |
| Multiple identifiers in lists | Better matching |
| Event-based segmentation | Cleaner intent signals |
| Recency-based windows | More relevant audiences |

### Audience Health Metrics

| Metric | Healthy Range |
|--------|---------------|
| Customer list match rate | >40% |
| Audience size vs impressions | Audience should grow |
| Retargeting frequency | <3.0 weekly |
| Overlap percentage | <30% between ad sets |

## Reference Files

For detailed guidance, access:
- `references/audience-templates.md` - Pre-built audience definitions for common scenarios
- `references/naming-conventions.md` - Standardized naming system for organization
- `references/testing-framework.md` - Audience testing methodology and analysis

## How to Use This Skill

### New Audience Strategy
```
Build a complete Meta audience strategy for my [business type]
- Monthly ad spend: $X
- Primary goal: [purchases/leads/awareness]
- Existing assets: [pixel/customer list/engagement]
```

### Audience Audit
```
Audit my current Meta audience structure for overlap and efficiency
[describe current setup or attach export]
```

### Specific Audience Build
```
Create retargeting audiences for my ecommerce store
- Products: [category]
- Purchase cycle: [X days]
- Current tracking: [pixel/CAPI status]
```

---

**Ready to build your Meta Ads audience strategy?** Share your business context and I'll design an Andromeda-optimized audience architecture with specific definitions, naming conventions, and testing recommendations.
