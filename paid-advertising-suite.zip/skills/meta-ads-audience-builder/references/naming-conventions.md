# Meta Ads Audience Naming Conventions

## Standard Naming Format

```
[SOURCE]_[ACTION/SEGMENT]_[WINDOW]_[DATE]
```

### Components

| Component | Description | Examples |
|-----------|-------------|----------|
| SOURCE | Data origin | WEB, ENG, LIST, LAL, APP |
| ACTION/SEGMENT | What they did or who they are | AllVisitors, Purchasers, VideoViewers75 |
| WINDOW | Lookback period | 7d, 30d, 90d, 180d, 365d |
| DATE | Creation date (optional) | 2025-01, 2025-Q1 |

## Source Prefixes

| Prefix | Full Source | Examples |
|--------|-------------|----------|
| WEB | Website (Pixel) | WEB_AllVisitors_180d |
| APP | Mobile App (SDK) | APP_Installers_90d |
| ENG | Engagement (Platform) | ENG_IGProfile_365d |
| LIST | Customer List (CRM) | LIST_Purchasers_All |
| LAL | Lookalike Audience | LAL_Purchasers_1pct |
| GEO | Geographic Targeting | GEO_US_CA_25mi |
| INT | Interest Targeting | INT_FitnessEnthusiasts |

## Website Audience Names

### By Event Type

```
WEB_PageView_[Window]          → All website visitors
WEB_ViewContent_[Window]       → Product/content viewers
WEB_AddToCart_[Window]         → Cart adders
WEB_InitiateCheckout_[Window]  → Checkout starters
WEB_Purchase_[Window]          → Purchasers
WEB_Lead_[Window]              → Form submitters
WEB_CompleteReg_[Window]       → Account creators
WEB_StartTrial_[Window]        → Trial starters
WEB_Subscribe_[Window]         → Subscribers
```

### By Page/URL

```
WEB_[PageName]_[Window]

Examples:
WEB_PricingPage_60d
WEB_BlogReaders_90d
WEB_ProductCategory_30d
WEB_CheckoutPage_14d
WEB_ThankYouPage_180d
```

### Combined Events (Abandonment)

```
WEB_CartAbandoners_[Window]       → AddToCart NOT Purchase
WEB_CheckoutAbandoners_[Window]   → InitiateCheckout NOT Purchase
WEB_FormAbandoners_[Window]       → StartForm NOT Lead
WEB_TrialNotConverted_[Window]    → StartTrial NOT Subscribe
```

## Engagement Audience Names

### Instagram

```
ENG_IGProfile_[Window]         → Profile visitors
ENG_IGEngagers_[Window]        → Any engagement
ENG_IGSavers_[Window]          → Post savers
ENG_IGShoppers_[Window]        → Shop browsers
ENG_IGReels_[Window]           → Reel engagers
ENG_IGStories_[Window]         → Story engagers
ENG_IGLive_[Window]            → Live viewers
```

### Facebook

```
ENG_FBPage_[Window]            → Page visitors/engagers
ENG_FBPost_[Window]            → Post engagers
ENG_FBEvent_[Window]           → Event responders
ENG_FBShop_[Window]            → Shop engagers
```

### Video

```
ENG_Video25_[Window]           → 25% watched
ENG_Video50_[Window]           → 50% watched
ENG_Video75_[Window]           → 75% watched
ENG_Video95_[Window]           → 95% watched
ENG_VideoComplete_[Window]     → 100% watched
```

### Lead Forms

```
ENG_LeadFormOpen_[Window]      → Opened form
ENG_LeadFormSubmit_[Window]    → Submitted form
ENG_LeadFormAbandon_[Window]   → Opened NOT submitted
```

## Customer List Names

### By Segment

```
LIST_Customers_All              → All customers ever
LIST_Customers_Active           → Currently active
LIST_Customers_Lapsed_[Days]    → No activity in X days
LIST_Customers_HighValue        → Top 20% by LTV
LIST_Customers_Repeat           → 2+ purchases
LIST_Customers_Recent_[Window]  → Purchased in window
```

### By Type

```
LIST_Subscribers_All            → All email subscribers
LIST_Subscribers_Engaged        → Opened in 90 days
LIST_Subscribers_Inactive       → No open in 90+ days
LIST_Leads_All                  → All leads
LIST_Leads_Qualified            → SQLs only
LIST_Leads_Unqualified          → MQLs not yet SQL
```

## Lookalike Audience Names

### Standard Format

```
LAL_[SeedName]_[Percentage]

Examples:
LAL_Purchasers_1pct
LAL_HighValue_1pct
LAL_CartAbandoners_3pct
LAL_VideoViewers75_5pct
LAL_Subscribers_1to3pct
```

### With Geography

```
LAL_[SeedName]_[Percentage]_[Geo]

Examples:
LAL_Purchasers_1pct_US
LAL_Customers_3pct_UK
LAL_Leads_1pct_CA
```

## App Audience Names

```
APP_Installers_[Window]
APP_ActiveUsers_[Window]
APP_InactiveUsers_[Window]
APP_Purchasers_[Window]
APP_Subscribers_[Window]
APP_LevelComplete_[Level]_[Window]
APP_FeatureUsers_[Feature]_[Window]
```

## Exclusion Audience Names

Add `_EXCL` suffix for clarity:

```
EXCL_Purchasers_180d
EXCL_CurrentCustomers
EXCL_RecentLeads_30d
EXCL_Employees
EXCL_Competitors
```

## Combined/Stacked Audience Names

Use `+` for combinations:

```
WEB_AllVisitors+ENG_IGProfile_180d
LAL_Purchasers+LAL_HighValue_1pct
WEB_CartAbandoners+WEB_CheckoutAbandoners_30d
```

## Date Versioning

Add date when audiences need regular refresh:

```
LIST_Customers_All_2025-01
LIST_HighValue_Q1-2025
LAL_Purchasers_1pct_Jan2025
```

## Naming Best Practices

### Do's

✅ Use consistent prefixes
✅ Include window/timeframe
✅ Be specific about events
✅ Use underscores for separation
✅ Keep names scannable
✅ Version date for manual lists
✅ Use % abbreviation (pct)

### Don'ts

❌ Use spaces in names
❌ Use special characters (except _ and -)
❌ Make names too long (>50 chars)
❌ Use ambiguous abbreviations
❌ Mix naming conventions
❌ Forget the window timeframe

## Quick Reference Examples

### Ecommerce

```
WEB_AllVisitors_180d
WEB_ProductViewers_60d
WEB_CartAbandoners_30d
WEB_CheckoutAbandoners_14d
WEB_Purchasers_180d
LIST_Customers_HighValue
LIST_Customers_Repeat
LAL_Purchasers_1pct
LAL_HighValue_1pct
ENG_IGShoppers_365d
```

### Lead Gen

```
WEB_AllVisitors_180d
WEB_PricingPage_60d
WEB_DemoPage_60d
WEB_LeadFormSubmit_180d
LIST_Leads_All
LIST_Leads_Qualified
LIST_Customers_All
LAL_Customers_1pct
LAL_SQLs_1pct
ENG_LeadFormOpen_90d
```

### SaaS

```
WEB_AllVisitors_180d
WEB_PricingPage_60d
WEB_SignUp_180d
WEB_TrialStart_180d
WEB_TrialNotConverted_90d
LIST_Subscribers_Active
LIST_Subscribers_Churned
LAL_ActiveSubs_1pct
LAL_TrialConverters_1pct
APP_ActiveUsers_30d
```

## Folder/Organization Structure

Organize audiences in Ads Manager by category:

```
📁 Prospecting
   ├── LAL_Purchasers_1pct
   ├── LAL_HighValue_1pct
   └── LAL_CartAbandoners_3pct

📁 Retargeting - Website
   ├── WEB_AllVisitors_180d
   ├── WEB_ProductViewers_60d
   └── WEB_CartAbandoners_30d

📁 Retargeting - Engagement
   ├── ENG_IGProfile_365d
   ├── ENG_VideoViewers75_365d
   └── ENG_PostEngagers_365d

📁 Customer Lists
   ├── LIST_Customers_All
   ├── LIST_Customers_HighValue
   └── LIST_Subscribers_Engaged

📁 Exclusions
   ├── EXCL_Purchasers_180d
   ├── EXCL_CurrentCustomers
   └── EXCL_Employees
```
