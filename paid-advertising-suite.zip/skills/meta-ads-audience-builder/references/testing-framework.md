# Audience Testing Framework

## Testing Philosophy in the Andromeda Era

**Old Approach**: Test many narrow audiences to find winners
**New Approach**: Test audience signals to guide algorithm, measure creative performance

Andromeda shifts testing focus from "which audience converts best?" to "which signals help the algorithm find the right people?"

## Testing Hierarchy

### Priority 1: Signal Quality Tests

Test what data you provide to the algorithm:

| Test | Hypothesis | Measurement |
|------|------------|-------------|
| CAPI vs Pixel-only | CAPI improves match rates | Event Match Quality, conversion volume |
| Customer list freshness | Recent data = better signals | Lookalike performance, match rate |
| Event selection | Purchase vs ATC vs ViewContent | Lookalike CPAs |
| Identifier coverage | More identifiers = higher match | Match rate %, CPM efficiency |

### Priority 2: Audience Structure Tests

Test how you organize audiences:

| Test | Hypothesis | Measurement |
|------|------------|-------------|
| Consolidated vs Segmented | Fewer ad sets = better learning | CPA, learning phase duration |
| Advantage+ vs Manual | AI targeting = efficiency | ROAS, reach, CPM |
| Exclusions impact | Proper exclusions = less waste | Incremental conversions, CPA |
| Overlap reduction | Less overlap = lower costs | CPM, frequency, CPA |

### Priority 3: Lookalike Tests

Test seed quality and expansion:

| Test | Hypothesis | Measurement |
|------|------------|-------------|
| Seed source comparison | High-LTV seed > all purchasers | CPA, ROAS, LTV of acquired |
| Percentage comparison | 1% vs 3% vs 5% | Reach, CPA, quality |
| Stacked vs Single | Multiple seeds = better signals | Reach efficiency, CPA |
| Expansion settings | Advantage+ expansion helps | Incremental reach, CPA |

### Priority 4: Window Tests

Test recency and duration:

| Test | Hypothesis | Measurement |
|------|------------|-------------|
| Retargeting windows | Shorter = higher intent | CPA, CVR by window |
| Exclusion windows | Match to purchase cycle | Efficiency, overlap |
| Lookalike freshness | Recent seed = better match | CPA, ROAS |

## Test Design Templates

### A/B Test: Advantage+ vs Manual Targeting

**Hypothesis**: Advantage+ Audience will deliver lower CPA than manual broad targeting

**Setup**:
```
Campaign: [Objective] - Audience Test
├── Ad Set A: Advantage+ Audience
│   ├── Targeting: Advantage+ enabled
│   ├── Suggested: LAL signals
│   └── Budget: 50%
│
└── Ad Set B: Manual Broad
    ├── Targeting: Country-wide, age range only
    ├── No suggestions
    └── Budget: 50%

Variables Controlled:
- Same creative in both ad sets
- Same exclusions
- Same budget split
- Same optimization goal
```

**Measurement**:
- Primary: CPA comparison
- Secondary: Reach, CPM, CTR
- Duration: 7-14 days minimum
- Conversions needed: 50+ per ad set

### A/B Test: Lookalike Seed Quality

**Hypothesis**: High-value customer seed produces lower CPA than all-purchaser seed

**Setup**:
```
Campaign: [Objective] - Seed Test
├── Ad Set A: LAL High-Value 1%
│   ├── Seed: Top 20% LTV customers
│   └── Budget: 50%
│
└── Ad Set B: LAL All Purchasers 1%
    ├── Seed: All purchasers
    └── Budget: 50%

Variables Controlled:
- Same percentage (1%)
- Same creative
- Same exclusions
- Same geo
```

**Measurement**:
- Primary: CPA, ROAS
- Secondary: LTV of acquired customers (track 30-90 days)
- Duration: 14-30 days

### A/B Test: Lookalike Percentage

**Hypothesis**: 1% LAL has lower CPA but 3% LAL has better scale efficiency

**Setup**:
```
Campaign: [Objective] - LAL % Test
├── Ad Set A: LAL 1%
│   ├── Percentage: 1%
│   └── Budget: 50%
│
└── Ad Set B: LAL 3%
    ├── Percentage: 3%
    └── Budget: 50%

Variables Controlled:
- Same seed source
- Same creative
- Same exclusions
```

**Measurement**:
- Primary: CPA at scale
- Secondary: Reach, frequency, CPM
- Watch for: Diminishing returns as spend increases

### A/B Test: Retargeting Window

**Hypothesis**: 14-day cart abandoners have higher CVR than 30-day

**Setup**:
```
Campaign: Retargeting - Window Test
├── Ad Set A: Cart Abandoners 14d
│   ├── Window: 14 days
│   └── Budget: 50%
│
└── Ad Set B: Cart Abandoners 30d
    ├── Window: 30 days
    ├── Exclude: 0-14 day abandoners
    └── Budget: 50%

Variables Controlled:
- Same event (AddToCart NOT Purchase)
- Same creative
- Same bid strategy
```

**Measurement**:
- Primary: CVR comparison
- Secondary: CPA, audience size sustainability
- Note: Shorter windows exhaust faster

### A/B Test: Consolidated vs Segmented

**Hypothesis**: Single ad set outperforms multiple segmented ad sets

**Setup**:
```
Campaign A: Consolidated
└── Ad Set: Combined Retargeting
    ├── Targeting: WEB_AllVisitors_180d + ENG_IGProfile_365d + WEB_CartAbandoners_30d
    └── Budget: 100%

Campaign B: Segmented
├── Ad Set 1: Website Visitors
│   ├── Targeting: WEB_AllVisitors_180d
│   └── Budget: 40%
├── Ad Set 2: IG Engagers
│   ├── Targeting: ENG_IGProfile_365d
│   └── Budget: 30%
└── Ad Set 3: Cart Abandoners
    ├── Targeting: WEB_CartAbandoners_30d
    └── Budget: 30%

Variables Controlled:
- Same total budget
- Same creative across all
- Same conversion goal
```

**Measurement**:
- Primary: Overall CPA
- Secondary: Learning phase duration, delivery stability
- Duration: 14+ days

## Testing Best Practices

### Before Testing

1. **Define clear hypothesis**: What do you expect and why?
2. **Set success criteria**: What improvement is meaningful?
3. **Calculate sample size**: Need 50+ conversions per variant
4. **Control variables**: Only test one thing at a time
5. **Document baseline**: Know current performance

### During Testing

1. **Don't peek too early**: Wait for statistical significance
2. **Monitor for issues**: Check delivery, errors, policy
3. **Don't make changes**: Resist optimization urge
4. **Track external factors**: Seasonality, promos, competitors

### After Testing

1. **Analyze holistically**: CPA + quality + scale
2. **Check significance**: Use Meta's test tools or statistical calculator
3. **Document learnings**: Record what worked and why
4. **Implement winners**: Roll out to main campaigns
5. **Plan follow-up tests**: Build on learnings

## Minimum Test Duration

| Metric | Minimum Duration | Ideal Duration |
|--------|------------------|----------------|
| CPA/ROAS | 7 days | 14 days |
| Reach/CPM | 5 days | 7 days |
| LTV comparison | 30 days | 90 days |
| Brand lift | 14 days | 28 days |

## Sample Size Requirements

### For Confidence in Results

| Weekly Conversions | Test Duration | Confidence Level |
|-------------------|---------------|------------------|
| 100+ | 7 days | High |
| 50-100 | 14 days | Medium-High |
| 25-50 | 21-28 days | Medium |
| <25 | 28+ days | Lower |

### Minimum per Variant

- CPA tests: 50 conversions per ad set
- CTR tests: 1,000 clicks per ad set
- CPM tests: 10,000 impressions per ad set

## Interpreting Results

### Clear Winner (Implement)

- 20%+ improvement
- Consistent over duration
- Statistical significance (p < 0.05)
- Similar quality metrics

### Marginal Difference (Retest)

- 5-20% difference
- Fluctuating results
- Low significance
- Consider larger sample

### No Difference (Both Viable)

- <5% difference
- Neither clearly better
- May indicate creative is the variable
- Choose simpler option

## Testing Roadmap

### Month 1: Foundation Tests

1. Advantage+ vs Manual targeting
2. LAL seed quality (high-value vs all)
3. Retargeting consolidation

### Month 2: Optimization Tests

1. LAL percentage scaling (1% vs 3% vs 5%)
2. Retargeting window optimization
3. Exclusion strategy impact

### Month 3: Advanced Tests

1. Signal quality improvements (CAPI enhancement)
2. Lookalike stacking strategies
3. Cross-campaign audience synergy

## Test Documentation Template

```
Test Name: [Descriptive name]
Test ID: [YYYY-MM-DD-XXX]
Hypothesis: [What you expect and why]
Test Type: [A/B, Multivariate, Holdout]

Setup:
- Variant A: [Description]
- Variant B: [Description]
- Budget split: [50/50, 70/30, etc.]
- Duration: [X days]
- Controlled variables: [List]

Success Metrics:
- Primary: [CPA, ROAS, etc.]
- Secondary: [Supporting metrics]
- Minimum threshold: [X% improvement]

Results:
- Variant A: [Key metrics]
- Variant B: [Key metrics]
- Winner: [A/B/Inconclusive]
- Confidence: [High/Medium/Low]

Learnings:
- [What did we learn?]
- [What should we test next?]
- [Implementation recommendations]

Next Steps:
- [ ] Roll out winner
- [ ] Follow-up test
- [ ] Document in playbook
```

## Common Testing Mistakes

### Mistakes to Avoid

❌ Testing too many variables at once
❌ Ending tests too early
❌ Making changes during tests
❌ Ignoring audience quality metrics
❌ Testing without clear hypothesis
❌ Not controlling for external factors
❌ Over-interpreting small samples
❌ Ignoring statistical significance

### Red Flags During Tests

⚠️ Uneven delivery (one variant getting most spend)
⚠️ Learning phase not completing
⚠️ Significant overlap between test audiences
⚠️ External events affecting results (holidays, PR)
⚠️ Policy issues limiting one variant
