# Audience Templates by Business Type

## Ecommerce Audiences

### Foundation Set

```
1. PURCHASERS_All_180d
   - Source: Pixel/CAPI
   - Event: Purchase
   - Window: 180 days
   - Use: Exclusions, LAL seed

2. PURCHASERS_HighValue_180d
   - Source: Customer list
   - Filter: Top 20% by LTV
   - Use: Premium LAL seed

3. PURCHASERS_Repeat_365d
   - Source: Customer list
   - Filter: 2+ purchases
   - Use: Best LAL seed, loyalty targeting

4. WEB_AllVisitors_180d
   - Source: Pixel
   - Event: PageView
   - Window: 180 days
   - Use: Broad retargeting

5. WEB_ProductViewers_60d
   - Source: Pixel
   - Event: ViewContent
   - Window: 60 days
   - Use: Product retargeting

6. WEB_CartAbandoners_30d
   - Source: Pixel
   - Event: AddToCart NOT Purchase
   - Window: 30 days
   - Use: Recovery campaigns

7. WEB_CheckoutAbandoners_14d
   - Source: Pixel
   - Event: InitiateCheckout NOT Purchase
   - Window: 14 days
   - Use: High-intent recovery

8. ENG_IGProfile_365d
   - Source: Instagram
   - Action: Profile visitors
   - Window: 365 days
   - Use: Warm retargeting

9. ENG_VideoViewers75_365d
   - Source: Facebook/Instagram
   - Action: 75%+ video watched
   - Window: 365 days
   - Use: Engaged retargeting, LAL seed

10. LAL_Purchasers_1pct
    - Seed: PURCHASERS_All_180d
    - Percentage: 1%
    - Use: Primary prospecting signal

11. LAL_HighValue_1pct
    - Seed: PURCHASERS_HighValue_180d
    - Percentage: 1%
    - Use: Premium prospecting signal

12. LAL_CartAbandoners_3pct
    - Seed: WEB_CartAbandoners_30d
    - Percentage: 3%
    - Use: Intent-based prospecting
```

### Campaign Structure

**Prospecting Campaign**
```
Ad Set: Broad + LAL Signals
├── Targeting: Advantage+ Audience
├── Suggested: LAL_Purchasers_1pct, LAL_HighValue_1pct
├── Exclusions: PURCHASERS_All_180d, WEB_AllVisitors_30d
└── Budget: 70% of total
```

**Retargeting Campaign**
```
Ad Set: Website Retargeting
├── Targeting: WEB_AllVisitors_180d, WEB_ProductViewers_60d
├── Exclusions: PURCHASERS_All_30d
└── Budget: 20% of total

Ad Set: Cart Recovery
├── Targeting: WEB_CartAbandoners_30d, WEB_CheckoutAbandoners_14d
├── Exclusions: PURCHASERS_All_7d
└── Budget: 10% of total
```

---

## Lead Generation (B2B) Audiences

### Foundation Set

```
1. LEADS_AllConverted_180d
   - Source: Pixel/CAPI
   - Event: Lead
   - Window: 180 days
   - Use: Exclusions, LAL seed

2. LEADS_Qualified_180d
   - Source: CRM list
   - Filter: SQLs only
   - Use: Premium LAL seed

3. CUSTOMERS_All_365d
   - Source: CRM list
   - Filter: Closed deals
   - Use: Exclusions, best LAL seed

4. WEB_AllVisitors_180d
   - Source: Pixel
   - Event: PageView
   - Window: 180 days
   - Use: Broad retargeting

5. WEB_PricingViewers_60d
   - Source: Pixel
   - Event: URL contains /pricing
   - Window: 60 days
   - Use: High-intent retargeting

6. WEB_DemoPageViewers_60d
   - Source: Pixel
   - Event: URL contains /demo or /contact
   - Window: 60 days
   - Use: High-intent retargeting

7. WEB_CaseStudyViewers_90d
   - Source: Pixel
   - Event: URL contains /case-study
   - Window: 90 days
   - Use: Consideration stage retargeting

8. ENG_LeadFormOpeners_90d
   - Source: Lead form
   - Action: Opened but not submitted
   - Window: 90 days
   - Use: Form abandonment recovery

9. ENG_VideoViewers75_365d
   - Source: Facebook/Instagram
   - Action: 75%+ video watched
   - Window: 365 days
   - Use: Engaged retargeting

10. EMAIL_Subscribers_Active
    - Source: Email list
    - Filter: Opened email last 90 days
    - Use: Nurturing, LAL seed

11. LAL_SQLs_1pct
    - Seed: LEADS_Qualified_180d
    - Percentage: 1%
    - Use: Primary prospecting signal

12. LAL_Customers_1pct
    - Seed: CUSTOMERS_All_365d
    - Percentage: 1%
    - Use: Best prospecting signal
```

### Campaign Structure

**Lead Gen Prospecting**
```
Ad Set: Broad + LAL Signals
├── Targeting: Advantage+ Audience
├── Suggested: LAL_Customers_1pct, LAL_SQLs_1pct
├── Exclusions: LEADS_AllConverted_180d, CUSTOMERS_All_365d
└── Budget: 70% of total
```

**Lead Gen Retargeting**
```
Ad Set: Website Retargeting
├── Targeting: WEB_AllVisitors_180d
├── Exclusions: LEADS_AllConverted_180d, WEB_PricingViewers_60d
└── Budget: 15% of total

Ad Set: High-Intent
├── Targeting: WEB_PricingViewers_60d, WEB_DemoPageViewers_60d, ENG_LeadFormOpeners_90d
├── Exclusions: LEADS_AllConverted_30d
└── Budget: 15% of total
```

---

## SaaS / Subscription Audiences

### Foundation Set

```
1. SUBS_Active_Current
   - Source: Customer list
   - Filter: Active subscribers
   - Use: Exclusions, LAL seed

2. SUBS_Churned_365d
   - Source: Customer list
   - Filter: Cancelled last 365 days
   - Use: Win-back campaigns

3. TRIALS_Started_180d
   - Source: Pixel/CAPI
   - Event: StartTrial
   - Window: 180 days
   - Use: Exclusions, LAL seed

4. TRIALS_NotConverted_90d
   - Source: Pixel/CAPI
   - Event: StartTrial NOT Subscribe
   - Window: 90 days
   - Use: Trial conversion campaigns

5. WEB_AllVisitors_180d
   - Source: Pixel
   - Event: PageView
   - Window: 180 days
   - Use: Broad retargeting

6. WEB_PricingViewers_60d
   - Source: Pixel
   - Event: URL contains /pricing
   - Window: 60 days
   - Use: High-intent retargeting

7. WEB_FeaturesViewers_90d
   - Source: Pixel
   - Event: URL contains /features
   - Window: 90 days
   - Use: Consideration retargeting

8. SIGNUPS_NotTrial_90d
   - Source: Pixel/CAPI
   - Event: CompleteRegistration NOT StartTrial
   - Window: 90 days
   - Use: Signup to trial nurturing

9. ENG_VideoViewers75_365d
   - Source: Facebook/Instagram
   - Action: 75%+ video watched
   - Window: 365 days
   - Use: Engaged retargeting

10. LAL_ActiveSubs_1pct
    - Seed: SUBS_Active_Current
    - Percentage: 1%
    - Use: Best prospecting signal

11. LAL_TrialConverters_1pct
    - Seed: Converted trials (from CRM)
    - Percentage: 1%
    - Use: High-quality prospecting
```

### Campaign Structure

**Acquisition**
```
Ad Set: Broad Prospecting
├── Targeting: Advantage+ Audience
├── Suggested: LAL_ActiveSubs_1pct, LAL_TrialConverters_1pct
├── Exclusions: SUBS_Active_Current, TRIALS_Started_180d
└── Budget: 60% of total
```

**Trial Conversion**
```
Ad Set: Trial Nurturing
├── Targeting: TRIALS_NotConverted_90d
├── Exclusions: SUBS_Active_Current
└── Budget: 20% of total
```

**Win-back**
```
Ad Set: Churned Recovery
├── Targeting: SUBS_Churned_365d
├── Exclusions: SUBS_Active_Current
└── Budget: 10% of total
```

---

## Local Business Audiences

### Foundation Set

```
1. CUSTOMERS_All_365d
   - Source: Customer list (POS/CRM)
   - Use: Exclusions, LAL seed

2. CUSTOMERS_Regulars
   - Source: Customer list
   - Filter: 3+ visits in 180 days
   - Use: Best LAL seed

3. CUSTOMERS_Lapsed_180d
   - Source: Customer list
   - Filter: No visit in 180+ days
   - Use: Win-back campaigns

4. WEB_AllVisitors_180d
   - Source: Pixel
   - Event: PageView
   - Window: 180 days
   - Use: Broad retargeting

5. WEB_LocationPage_90d
   - Source: Pixel
   - Event: URL contains /location or /store
   - Window: 90 days
   - Use: Local intent retargeting

6. WEB_MenuViewers_60d
   - Source: Pixel
   - Event: URL contains /menu or /services
   - Window: 60 days
   - Use: Consideration retargeting

7. ENG_IGProfile_365d
   - Source: Instagram
   - Action: Profile visitors
   - Window: 365 days
   - Use: Local retargeting

8. ENG_PostEngagers_365d
   - Source: Facebook/Instagram
   - Action: Liked, commented, shared
   - Window: 365 days
   - Use: Engaged local audience

9. GEO_LocalRadius
   - Source: Location targeting
   - Radius: 10-25 miles from location
   - Use: Prospecting base

10. LAL_Customers_1pct
    - Seed: CUSTOMERS_All_365d
    - Percentage: 1%
    - Country: Limit to local region
    - Use: Local prospecting signal
```

### Campaign Structure

**Local Prospecting**
```
Ad Set: Local Broad
├── Targeting: GEO_LocalRadius
├── Suggested: LAL_Customers_1pct
├── Exclusions: CUSTOMERS_All_90d
└── Budget: 60% of total
```

**Local Retargeting**
```
Ad Set: Website + Engagement
├── Targeting: WEB_AllVisitors_180d, ENG_PostEngagers_365d
├── Geo: GEO_LocalRadius
├── Exclusions: CUSTOMERS_All_30d
└── Budget: 30% of total
```

---

## App Install / Mobile Audiences

### Foundation Set

```
1. APP_Installers_180d
   - Source: App SDK
   - Event: Install
   - Window: 180 days
   - Use: Exclusions, LAL seed

2. APP_ActiveUsers_30d
   - Source: App SDK
   - Event: App open
   - Window: 30 days
   - Use: Engagement campaigns

3. APP_Purchasers_180d
   - Source: App SDK
   - Event: Purchase
   - Window: 180 days
   - Use: Best LAL seed

4. APP_InactiveUsers_90d
   - Source: App SDK
   - Event: Install, no open 90+ days
   - Use: Re-engagement campaigns

5. WEB_AppPageViewers_60d
   - Source: Pixel
   - Event: URL contains /app or /download
   - Window: 60 days
   - Use: Install retargeting

6. ENG_VideoViewers75_365d
   - Source: Facebook/Instagram
   - Action: 75%+ video watched
   - Window: 365 days
   - Use: Warm prospecting

7. LAL_Purchasers_1pct
    - Seed: APP_Purchasers_180d
    - Percentage: 1%
    - Use: Best prospecting signal

8. LAL_ActiveUsers_3pct
    - Seed: APP_ActiveUsers_30d
    - Percentage: 3%
    - Use: Scale prospecting
```

### Campaign Structure

**App Install Prospecting**
```
Ad Set: Broad + LAL
├── Targeting: Advantage+ App
├── Suggested: LAL_Purchasers_1pct
├── Exclusions: APP_Installers_180d
└── Budget: 80% of total
```

**Re-engagement**
```
Ad Set: Inactive Users
├── Targeting: APP_InactiveUsers_90d
├── Exclusions: APP_ActiveUsers_30d
└── Budget: 20% of total
```

---

## Audience Size Guidelines

### Minimum Viable Sizes

| Audience Type | Minimum Size | Recommended Size |
|---------------|--------------|------------------|
| Retargeting | 1,000 | 10,000+ |
| Custom audience for ads | 100 matched | 1,000+ matched |
| Lookalike seed | 100 | 1,000-50,000 |
| Broad prospecting | 1M+ | 5M+ |

### When Audiences Are Too Small

If audience < 1,000:
- Extend lookback window (30d → 90d → 180d)
- Combine similar audiences
- Add engagement audiences
- Use broader event (PageView vs specific page)

### When Audiences Are Too Large

If audience overlap is high:
- Segment by recency (0-30d, 31-90d, 91-180d)
- Segment by intent (viewers vs cart vs checkout)
- Add exclusions to differentiate ad sets
