# Google Ads Policy Compliance Guide

## Critical Policy Rules

### Character & Formatting Rules

**Capitalization:**
- ❌ "BEST PRICE EVER" (excessive caps)
- ❌ "SaVe BiG" (gimmicky)
- ✅ "Best Price Guarantee" (acceptable for proper nouns/acronyms)
- Maximum 1 capitalized word per headline (unless proper noun)

**Punctuation:**
- ❌ "Amazing!!!" (excessive exclamation)
- ❌ "Best??? Really?" (question marks for emphasis)
- ✅ "Save 50%! Shop Now" (single exclamation acceptable)
- No symbols in headlines except: & | • - ( )
- No repeating punctuation (!!, ??, ..)

**Spacing:**
- No extra spaces for emphasis
- No incorrect spacing around punctuation
- Standard sentence spacing only

### Superlatives & Claims

**Superlatives Requiring Proof:**
- "Best", "Top", "#1", "Highest", "Lowest"
- "Fastest", "Easiest", "Most popular"
- Must be substantiated on landing page or qualify the claim

**Examples:**
- ❌ "Best CRM Software" (unqualified)
- ✅ "Best CRM - G2 Crowd 2024" (substantiated)
- ✅ "Rated Best by Forbes" (attributed)
- ✅ "Best for Small Teams" (qualified)

**Time-Based Claims:**
- ❌ "Results in 24 hours" (unless guaranteed)
- ✅ "Shipping within 24 hours" (service promise)
- ✅ "Most users see results in 30 days" (qualified)

### Prohibited Content

**Cannot Advertise:**
- Counterfeit goods
- Dangerous products/services
- Dishonest behavior
- Inappropriate content

**Cannot Use:**
- "Click here" / "Learn more here" as primary CTA
- Destination mismatch (ad promotes X, page is about Y)
- Non-functional display URLs
- Fake countdown timers (must be real)

### Industry-Specific Rules

**Healthcare:**
- No unsubstantiated health claims
- Cannot imply diagnosis/treatment
- Prescription drugs require certification
- OTC drugs have specific requirements
- Weight loss claims highly restricted

**Example:**
- ❌ "Cure diabetes naturally"
- ❌ "Lose 30 lbs in 30 days"
- ✅ "Doctor-approved weight management"
- ✅ "FDA-approved treatment option"

**Financial Services:**
- APR/interest rates must match landing page
- Required disclosures must be visible
- Cannot guarantee returns
- Lending requires specific disclaimers

**Example:**
- ❌ "Guaranteed 10% returns"
- ❌ "0% APR" (if conditions apply, must state)
- ✅ "Up to 10% returns historically"
- ✅ "0% APR for 12 months*" (with disclosure)

**Alcohol:**
- Cannot target under 21 (US)
- Cannot show consumption
- Cannot imply improved performance
- Regional restrictions apply

**Gambling:**
- Requires certification
- Geographic restrictions
- Cannot target minors
- Responsible gambling messaging

**Legal Services:**
- Cannot guarantee results
- Must include relevant disclosures
- State bar restrictions may apply

**Example:**
- ❌ "We'll win your case"
- ✅ "Free case evaluation by experienced attorneys"

## Extension-Specific Policies

**Sitelinks:**
- Must link to same domain as final URL
- Cannot have duplicate text
- Descriptions must add value
- Cannot use CTAs in link text ("Click Here")

**Callouts:**
- Must be accurate
- Cannot duplicate headline/description
- No promotional language requiring proof

**Structured Snippets:**
- Must use approved headers
- Values must match header category
- Cannot include prices/dates

**Call Extensions:**
- Phone number must be accurate
- Cannot be premium-rate number
- Business hours must be accurate

**Price Extensions:**
- Prices must match landing page
- Cannot show strikethrough unless sale is real
- Currency formatting must be correct

**Promotion Extensions:**
- Sale/offer must be real and current
- Cannot use "up to" discounts misleadingly
- Start/end dates must be accurate

## Trademark Policy

**Using Trademarks:**
- Can use in ad text if you're reseller/provider
- Cannot use to mislead about affiliation
- Competitor terms allowed in keywords (mostly)
- Cannot use in ad text to mislead

**Examples:**
- ✅ "Authorized Salesforce Partner"
- ❌ "Better than Salesforce" (using their mark)
- ✅ "CRM Alternative to [Competitor]" (comparison)

## Destination Requirements

**Landing Page Must:**
- Load quickly (<3 seconds)
- Be mobile-friendly
- Match ad promise
- Have clear navigation
- Show business information
- Have privacy policy (if collecting data)
- Not have misleading content

**Landing Page Cannot:**
- Use pop-ups that interfere with navigation
- Autoplay video with sound
- Have malware
- Phish for information
- Have broken functionality

## Common Violations to Avoid

### Gimmicky Formatting
- ❌ "C-h-e-a-p-e-s-t"
- ❌ "Free***"
- ❌ Unnecessary symbols for attention

### Repetitive Text
- ❌ "Shoes Shoes Shoes"
- ❌ Same headline 3 times
- Acceptable: Slight variations

### Generic Content
- ❌ "Click here to learn more"
- ❌ URLs in ad text (use display URL)
- ❌ "Buy now at example.com"

### Incorrect Grammar
- Generally must use proper grammar
- Some flexibility for brand voice
- Cannot be incomprehensible

## Best Practices for Compliance

1. **Substantiate Claims**: If you say it, prove it on landing page
2. **Be Specific**: "Save up to 50%" better than "Huge Savings"
3. **Match Landing Page**: Ad promise = Page delivery
4. **Use Proper Casing**: Title case or sentence case only
5. **Avoid Gimmicks**: Professional, clear copy performs better anyway
6. **Industry Check**: Know your industry restrictions
7. **Test First**: Preview ads before launching

## Pre-Launch Checklist

- [ ] No excessive capitalization
- [ ] No repeating punctuation
- [ ] Superlatives substantiated
- [ ] No prohibited content for industry
- [ ] Landing page matches ad
- [ ] All extensions link to same domain
- [ ] Prices/offers match landing page
- [ ] No trademark violations
- [ ] Mobile-friendly landing page
- [ ] Clear business information visible

## If Your Ad Gets Disapproved

**Common Fixes:**
1. **Capitalization**: Change to title/sentence case
2. **Superlatives**: Add qualification or remove
3. **Unsubstantiated**: Add proof to landing page or soften claim
4. **Destination mismatch**: Update landing page or ad copy
5. **Trademark**: Remove competitor name or get authorization

**Appeal Process:**
- Check disapproval reason in Google Ads
- Fix the issue
- Re-submit for review
- Appeals typically review within 1 business day
