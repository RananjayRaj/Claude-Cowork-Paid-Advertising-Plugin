---
name: google-ads-copy-generator
description: Create compliant Google Ads copy with headlines and extensions, featuring policy compliance checks, extension suggestions, character optimization, and landing page analysis
---

# Google Ads Copy Generator

Generates policy-compliant, high-performing Google Ads copy including responsive search ads, headlines, descriptions, and all extension types. Analyzes landing pages to ensure message match and maximize Quality Score.

## How to Use This Skill

### Quick Start
1. Provide your landing page URL or describe your offer
2. Specify your target keyword(s)
3. Receive complete ad copy ready to upload

### What You'll Need
- **Landing page URL** (preferred) OR description of offer/product
- **Target keyword(s)** - Primary keyword(s) you're bidding on
- **Campaign objective** (optional) - Awareness, leads, sales, etc.
- **Unique selling points** (optional) - What makes you different

## Core Workflow

When you provide a landing page or offer details, I will:

1. **Landing Page Analysis** - Extract key benefits, offers, and messaging
2. **Copy Generation** - Create multiple headline and description variations
3. **Extension Suggestions** - Recommend relevant sitelinks, callouts, snippets
4. **Policy Compliance Check** - Flag any potential policy violations
5. **Character Optimization** - Maximize impact within character limits

## What I Generate

### Responsive Search Ads (RSA)
- **15 Headlines** (30 chars) - Keyword-focused, benefit-driven, offer-based
- **4 Descriptions** (90 chars) - Value props, CTAs, trust signals

### Ad Extensions
- **Sitelinks** (4-10) - Strategic page links with descriptions
- **Callouts** (4-10) - Feature highlights and benefits
- **Structured Snippets** - Category-appropriate value lists
- **Call Extensions** - Phone formatting, call-only ads
- **Location/Price/Promotion** - Based on business type

## Key Features

### 1. Landing Page Analysis

Analyzes your landing page for headline messaging, key benefits, offers, trust signals, CTAs, and unique differentiators. Ensures **message match** for better Quality Score.

### 2. Policy Compliance

Checks for prohibited content (unsupported superlatives, trademark issues), restricted industry rules (healthcare, finance, gambling), and common violations (excessive caps, gimmicky formatting).

### 3. Character Optimization

Maximizes every character: front-loads keywords in headlines, uses complete sentences in descriptions, strategic symbol usage (| • & @).

### 4. Extension Strategy

Recommends extensions based on business type, landing page content, competitive advantage, and user intent.

## Example Requests

**Simple Request:**
"Create Google Ads copy for this landing page: [URL]"

**With Keyword:**
"Generate ads for 'cloud accounting software' targeting this page: [URL]"

**No Landing Page:**
"Create ads for CRM software. Main benefits: easy setup, affordable ($29/mo), integrates with everything."

**Specific Extensions:**
"I need sitelink extensions for my e-commerce homepage."

**Policy Check:**
"Review this ad copy for compliance: [paste copy]"

## Advanced Features

### Multiple Keyword Targeting

Generate ad sets for related keywords:
```
Keywords: 
- "project management software"
- "project management tool"  
- "pm software for teams"

I'll create variations tailored to each keyword's intent.
```

### Competitor Differentiation

Provide competitor info for unique positioning:
```
"Create ads that differentiate us from Asana and Monday.com. 
Our advantage: Built specifically for agencies."
```

### A/B Testing Variations

Request multiple concepts to test:
```
"Generate 3 different ad concepts:
1. Price-focused
2. Feature-focused  
3. Ease-of-use focused"
```

### Industry-Specific Copy

Mention your industry for tailored messaging:
- B2B SaaS
- E-commerce
- Local services
- Healthcare
- Financial services
- Legal
- Real estate
- Education

## Copy Strategy

### Headline Strategy

**Position 1 Headlines** (shown most often):
- Include target keyword
- Lead with strongest benefit
- Attention-grabbing

**Position 2 Headlines**:
- Supporting benefits
- Social proof elements
- Offer details

**Position 3 Headlines**:
- Calls-to-action
- Secondary benefits
- Trust signals

### Description Strategy

**Description 1**:
- Expand on headline promise
- Include 1-2 key benefits
- Clear call-to-action

**Description 2**:
- Additional value props
- Trust signals
- Urgency/scarcity if applicable

### Extension Hierarchy

1. **Sitelinks** - Most prominent, use for key pages
2. **Callouts** - Quick benefit statements
3. **Structured Snippets** - Category features
4. **Other Extensions** - Based on business needs

## Integration with Other Skills

Works well with:
- **Landing Page Optimizer** - Improve page before creating ads
- **Ad Performance Diagnostic** - Analyze existing ad performance
- **Creative Testing Framework** - Set up systematic ad tests
- **Negative Keyword Miner** - Complement with negative keyword strategy

## Reference Materials

For detailed guidelines and frameworks, I access:
- `references/policy-compliance-guide.md` - Google Ads policy requirements
- `references/copy-formulas.md` - Proven headline and description structures
- `references/extension-best-practices.md` - Extension optimization strategies
- `references/character-limits.md` - All Google Ads character limits and specs

## Output Formats

Choose your preferred format:
- **Copy Document** (formatted for easy copy-paste)
- **CSV Format** (for bulk upload to Google Ads)
- **Google Ads Editor Format** (ready to import)
- **A/B Test Matrix** (multiple variations organized)

## Tips for Best Results

1. **Provide Landing Page URL**: Better analysis = better copy
2. **Specify Target Keywords**: Ensures keyword inclusion and relevance
3. **Share Unique Selling Points**: Helps with differentiation
4. **Mention Compliance Concerns**: Healthcare, finance, etc. need extra care
5. **Include Offers/Promotions**: Sales, discounts, trials should be featured
6. **Describe Target Audience**: B2B vs B2C changes messaging approach

## Common Use Cases

### New Campaign Launch
Generate complete ad copy set for new campaigns with multiple ad groups.

### Ad Refresh
Update existing ads with fresh copy to combat ad fatigue.

### A/B Testing
Create variations to test different value propositions or messaging angles.

### Quality Score Improvement
Enhance ad relevance by aligning copy with keywords and landing pages.

### Competitive Response
Develop messaging that differentiates from competitors.

### Seasonal Campaigns
Adapt copy for holidays, sales events, or seasonal offerings.

### Extension Optimization
Add or update extensions to improve ad prominence and CTR.

## Policy Compliance Notes

I flag potential issues, but you should:
- Verify trademark usage rights
- Ensure claims are substantiated
- Review industry-specific regulations
- Test ads in Google Ads preview before launching

Google's final approval is required - this skill helps you avoid common violations but doesn't guarantee approval.

---

**Ready to create high-performing ad copy?** Share your landing page URL or offer details and I'll generate compliant, optimized Google Ads copy with all recommended extensions.
