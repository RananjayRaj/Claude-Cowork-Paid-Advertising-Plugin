---
name: linkedin-ads-audience-builder
description: Design and optimize LinkedIn Ads audiences for high-intent B2B targeting based on ideal customer profiles. Build prospecting, retargeting, and account-based segments using job titles, functions, seniority, industries, company size, skills, and matched audiences. Manage overlap, exclusions, and funnel alignment. Use when creating LinkedIn audiences, auditing existing targeting, mapping ICP to LinkedIn attributes, reducing wastage, aligning audiences to ABM strategy, or improving lead quality through CRM feedback loops.
---

# LinkedIn Ads Audience Builder

Strategic framework for designing, building, and optimizing LinkedIn Ads audiences for B2B marketing. Transforms Ideal Customer Profiles into precise targeting configurations that maximize lead quality while controlling costs.

## What This Skill Does

Designs and optimizes LinkedIn audiences across 7 key dimensions:

1. **ICP-to-LinkedIn Mapping** - Translate buyer personas into targeting attributes
2. **Job Function & Title Strategy** - Balance precision vs scale in professional targeting
3. **Company Targeting** - Size, industry, growth signals, and account lists
4. **Seniority & Skills Layering** - Reach decision-makers with right expertise
5. **Matched Audiences** - Website retargeting, contact lists, account lists, lookalikes
6. **Overlap & Exclusion Management** - Prevent audience cannibalization
7. **Performance Optimization** - Refine targeting using conversion and CRM data

**Output**: Complete audience architecture with specific targeting configurations, naming conventions, exclusion rules, and optimization roadmap.

## LinkedIn Audience Fundamentals

### Targeting Attribute Categories

| Category | Attributes | Precision Level |
|----------|-----------|-----------------|
| Company | Size, Industry, Name, Growth rate, Followers | High |
| Job | Title, Function, Seniority, Years of experience | High |
| Education | Degree, Field of study, School | Medium |
| Demographics | Location, Age (limited) | Medium |
| Interests | Member groups, Interests, Traits | Low-Medium |
| Matched | Contact lists, Account lists, Website, Lookalikes | Variable |

### Audience Size Guidelines

| Audience Size | Use Case | Expected CPL |
|---------------|----------|--------------|
| <10K | Too narrow, limited delivery | Very high |
| 10-50K | ABM, high-value targets | High ($75-150+) |
| 50-150K | Targeted campaigns | Medium-high ($40-80) |
| 150-500K | Balanced reach/precision | Medium ($25-50) |
| 500K-1M | Scale campaigns | Lower ($15-35) |
| >1M | Awareness, broad reach | Lowest ($10-25) |

**LinkedIn Minimum**: 300 members for campaign launch (1,000+ recommended)

## ICP-to-LinkedIn Mapping Framework

### Step 1: Define ICP Attributes

Map your Ideal Customer Profile to LinkedIn equivalents:

| ICP Element | LinkedIn Attribute | Mapping Approach |
|-------------|-------------------|------------------|
| Target companies | Company size + Industry | Direct match |
| Buyer persona | Job function + Seniority | Combination |
| Decision maker | Seniority + Title keywords | Layered |
| Technical buyer | Skills + Job function | Skill-based |
| Target accounts | Account list upload | ABM lists |
| Existing customers | Contact list upload | Matched audiences |

### Step 2: Attribute Prioritization

Rank attributes by impact on lead quality:

```
High Impact (Always Include):
├── Job Function - Core role alignment
├── Seniority - Decision authority
└── Company Size - Fit qualification

Medium Impact (Layer for Precision):
├── Industry - Vertical relevance
├── Job Title Keywords - Specific roles
└── Skills - Technical qualification

Lower Impact (Use for Scale):
├── Years of Experience - Proxy for seniority
├── Groups - Interest signals
└── Company Growth - Timing signals
```

### Step 3: AND vs OR Logic

LinkedIn uses AND between categories, OR within categories:

```
Example: Target Marketing Directors at Enterprise SaaS
├── Job Function: Marketing (OR Sales, Business Development)
├── AND Seniority: Director (OR VP, CXO)
├── AND Company Size: 1001-5000 (OR 5001-10000)
├── AND Industry: Software (OR IT Services)
```

**Critical**: Adding more attributes in different categories NARROWS audience. Adding more options within a category EXPANDS audience.

## Job Targeting Strategy

### Job Function Selection

| Function | When to Target | Overlap Considerations |
|----------|---------------|------------------------|
| Marketing | Marketing solutions | Overlaps with Sales slightly |
| Sales | Sales enablement, CRM | Often paired with BD |
| IT | Tech solutions, security | Very broad function |
| Finance | Fintech, accounting | Clear boundaries |
| HR | HR tech, recruiting | Clear boundaries |
| Operations | Process, logistics | Overlaps with multiple |
| Engineering | Dev tools, tech | Narrow by skills |

### Seniority Mapping

| Seniority Level | Decision Authority | Typical Role |
|-----------------|-------------------|--------------|
| CXO | Final budget approval | C-suite executives |
| VP | Department budget | Vice presidents |
| Director | Team/project budget | Department heads |
| Manager | Influence, champion | Team leads |
| Senior | Influence, evaluate | IC contributors |
| Entry | User, research | Junior roles |

**B2B Targeting Default**: Director+ for decision-makers, Manager+ for influencers

### Job Title Strategy

**Broad Approach** (Recommended for Scale):
- Use Job Functions + Seniority
- Let LinkedIn match variations
- Higher reach, good quality

**Narrow Approach** (For Precision):
- Specific job titles only
- Miss title variations
- Lower reach, higher precision

**Hybrid Approach** (Best Practice):
- Job Function + Seniority as base
- Exclude irrelevant title keywords
- OR include specific high-value titles

### Title Keywords: Include vs Exclude

**Include Keywords** (when targeting narrow roles):
```
Marketing: "demand gen", "growth", "digital", "performance"
Sales: "account executive", "business development", "enterprise"
IT: "security", "infrastructure", "devops", "architect"
```

**Exclude Keywords** (to improve quality):
```
Always Consider Excluding:
- "Intern", "Assistant", "Coordinator" (too junior)
- "Freelance", "Consultant" (may not be in-market)
- "Recruiter", "Talent" (wrong function overlap)
- "Student", "Graduate" (not decision-makers)
```

## Company Targeting

### Company Size Segmentation

| Segment | Employee Count | Characteristics |
|---------|---------------|-----------------|
| Startup | 1-10 | Founder-led, limited budget |
| Small | 11-50 | Growing, specific needs |
| SMB | 51-200 | Established process |
| Mid-Market | 201-1000 | Department budgets |
| Enterprise | 1001-5000 | Complex buying cycles |
| Large Enterprise | 5001-10000 | Multiple stakeholders |
| Global Enterprise | 10001+ | Long sales cycles |

### Industry Targeting

**Best Practice**: Start broad, refine by performance

| Strategy | When to Use |
|----------|------------|
| Single industry | Vertical-specific solution |
| Industry cluster | Related verticals |
| Cross-industry | Horizontal solution |
| Exclude industries | Filter out poor fits |

### Account List Targeting (ABM)

| List Type | Source | Use Case |
|-----------|--------|----------|
| Target accounts | CRM/sales team | ABM campaigns |
| Existing customers | CRM export | Upsell, exclusions |
| Competitor customers | Research | Conquest campaigns |
| Intent data accounts | 6sense, Bombora | In-market targeting |

**Upload Requirements**:
- Company name (required)
- Company website (improves match)
- LinkedIn Company Page URL (best match)
- Minimum 300 companies (1,000+ recommended)

## Matched Audiences

### Website Retargeting

| Audience | Definition | Use Case |
|----------|-----------|----------|
| All visitors | Any page view | Broad retargeting |
| Key page visitors | Pricing, demo, features | High-intent |
| Blog readers | Content pages | Nurture |
| Converters excluded | Visited NOT converted | Recovery |

**Requirements**: LinkedIn Insight Tag installed, 300+ matched members

### Contact Targeting

| List Type | Match Rate Expected | Refresh Cadence |
|-----------|---------------------|-----------------|
| Email list | 30-60% | Monthly |
| Enriched contacts | 50-80% | Monthly |
| CRM export | 40-70% | Weekly |

**Required Fields** (for best match):
- Email (primary identifier)
- First Name + Last Name
- Company Name
- Job Title

### Lookalike Audiences

| Seed Source | Quality | Recommended Size |
|-------------|---------|------------------|
| Customer list | High | 1,000+ contacts |
| Website converters | High | 300+ members |
| Engagement audience | Medium | 1,000+ members |

**Note**: LinkedIn lookalikes tend to be broader than Meta. Use additional attribute layers for precision.

## Audience Architecture

### Recommended Campaign Structure

```
Campaign: [Product/Objective]
├── Audience 1: ICP Prospecting
│   ├── Targeting: Function + Seniority + Size + Industry
│   ├── Exclusions: Existing customers, recent converters
│   └── Budget: 50-60%
│
├── Audience 2: ABM Accounts
│   ├── Targeting: Account list + Function + Seniority
│   ├── Exclusions: Won accounts
│   └── Budget: 20-30%
│
└── Audience 3: Retargeting
    ├── Targeting: Website visitors + engagement
    ├── Exclusions: Converters (30d)
    └── Budget: 15-20%
```

### Funnel-Aligned Targeting

**TOFU (Awareness)**:
- Broad professional targeting
- Job function + Seniority only
- Skills/interests for signals
- Larger audiences (500K+)

**MOFU (Consideration)**:
- Website retargeting
- Engagement audiences
- Lookalikes from converters
- Medium audiences (50-300K)

**BOFU (Decision)**:
- High-intent page visitors
- Contact list matches
- ABM account targets
- Smaller audiences (10-100K)

## Overlap & Exclusion Management

### Standard Exclusions

| Campaign Type | Exclude |
|---------------|---------|
| Prospecting | Customers, recent leads, employees |
| ABM | Won accounts, disqualified |
| Retargeting | Recent converters (30-90d) |
| Awareness | Engaged users (to maximize new reach) |

### Overlap Prevention

1. **Separate by Funnel Stage**: Prospect vs Retarget vs ABM
2. **Clear Exclusion Logic**: Each audience excludes others
3. **Account Hierarchy**: ABM excludes from broad prospecting
4. **Frequency Caps**: 3-5 impressions/member/week

### Exclusion Implementation Checklist

- [ ] Exclude existing customers from prospecting
- [ ] Exclude ABM accounts from broad campaigns
- [ ] Exclude recent converters from retargeting
- [ ] Exclude employees/company members
- [ ] Exclude disqualified leads (if identifiable)
- [ ] Exclude competitor companies (if needed)

## Performance Optimization

### CRM Feedback Integration

| Data Point | Action |
|------------|--------|
| Closed-won titles | Expand title targeting |
| Disqualified titles | Add to exclusions |
| Best-fit industries | Increase bids/budget |
| Low-quality sources | Exclude or reduce |
| Average deal size by segment | Adjust CPL targets |

### Optimization Signals

| Metric | Healthy Range | Action if Outside |
|--------|---------------|-------------------|
| CTR | 0.4-1.0% | Creative or audience issue |
| Conversion rate | 5-15% | Offer or landing page |
| Lead quality score | 60%+ qualified | Tighten targeting |
| CPL | Varies by segment | Adjust bids or targeting |
| Frequency | <5/week | Expand audience |

### Iterative Refinement

1. **Week 1-2**: Gather baseline data
2. **Week 3-4**: Analyze by attribute breakdowns
3. **Monthly**: Review CRM feedback on lead quality
4. **Quarterly**: Major audience restructuring

## Naming Conventions

Standard format: `[Type]_[Function]_[Seniority]_[Size]_[Modifier]_[Date]`

Examples:
- `PROSP_Marketing_Dir+_Enterprise_SaaS_2025-01`
- `ABM_TargetAccounts_AllRoles_Tier1_2025-01`
- `RT_WebVisitors_HighIntent_30d_2025-01`

## Reference Files

For detailed guidance, access:
- `references/attribute-library.md` - Complete LinkedIn targeting attributes
- `references/icp-templates.md` - Pre-built audience templates by use case
- `references/optimization-playbook.md` - Performance analysis and refinement

## How to Use This Skill

### New Audience Strategy
```
Build a LinkedIn audience strategy for [product/service]
- Target buyer: [ICP description]
- Company targets: [size, industry, specific accounts]
- Budget: $X/month
- Goal: [leads/awareness/pipeline]
```

### ICP Mapping
```
Map my ICP to LinkedIn targeting:
- Target title: [e.g., VP Marketing at SaaS companies]
- Company profile: [size, industry, characteristics]
- Decision criteria: [what makes them qualified]
```

### Audience Audit
```
Audit my LinkedIn targeting for waste and overlap:
[paste current targeting configuration]
Current results: [CPL, lead quality]
```

---

**Ready to build your LinkedIn audience strategy?** Share your ICP and campaign goals, and I'll design a complete targeting architecture with specific attribute configurations, exclusion rules, and optimization recommendations.
