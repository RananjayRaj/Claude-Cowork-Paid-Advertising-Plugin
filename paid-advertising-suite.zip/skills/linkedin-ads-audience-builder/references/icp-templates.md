# ICP-to-LinkedIn Templates

Pre-built audience configurations for common B2B targeting scenarios. Adapt based on your specific ICP and market.

## SaaS & Software Templates

### Template: SaaS Decision Makers (Enterprise)

**ICP**: VP/Director+ at enterprise companies evaluating software

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Information Technology
- Engineering  
- Product Management

Seniority:
- CXO
- VP
- Director

Company Size:
- 1,001-5,000
- 5,001-10,000
- 10,001+

Industries:
- Computer Software
- Information Technology & Services
- Internet
- Financial Services (if relevant)

EXCLUSIONS
----------
- Current customers (contact list)
- Competitors (company list)
- Job seekers

EXPECTED METRICS
----------------
Audience size: 150K-500K (US)
Expected CPL: $50-100
Lead quality: High
```

### Template: DevTools Technical Buyers

**ICP**: Engineering leaders evaluating developer tools

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Engineering
- Information Technology

Seniority:
- Director
- Manager
- Senior (for IC evaluators)

Company Size:
- 201-500
- 501-1,000
- 1,001-5,000

Skills (AND layer):
- Software Development
- DevOps
- Cloud Computing
- Any specific tech (Python, Kubernetes, etc.)

EXCLUSIONS
----------
- Title contains: "Intern", "Junior", "Graduate"
- Recruiting/HR functions

EXPECTED METRICS
----------------
Audience size: 50K-200K (US)
Expected CPL: $60-120
Lead quality: Very high (technical fit)
```

### Template: Marketing Technology Buyers

**ICP**: Marketing leaders evaluating MarTech solutions

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Marketing

Seniority:
- CXO (CMO)
- VP
- Director

Company Size:
- 201-500
- 501-1,000
- 1,001-5,000

Skills (optional layer):
- Marketing Automation
- Digital Marketing
- Demand Generation
- ABM

Industries (optional):
- Computer Software
- Information Technology & Services
- E-Learning

EXCLUSIONS
----------
- Title contains: "Content", "Social Media" (if not target)
- Current customers
- Agencies (if B2B only)

EXPECTED METRICS
----------------
Audience size: 100K-300K (US)
Expected CPL: $40-80
Lead quality: High
```

## Professional Services Templates

### Template: Enterprise Consulting Buyers

**ICP**: C-suite and VPs at large companies seeking consulting

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Operations
- Finance
- Human Resources
- Business Development

Seniority:
- CXO
- VP

Company Size:
- 1,001-5,000
- 5,001-10,000
- 10,001+

Industries:
- Financial Services
- Banking
- Insurance
- Healthcare
- Manufacturing

EXCLUSIONS
----------
- Consulting firms (company list)
- Staffing/recruiting companies
- Competitors

EXPECTED METRICS
----------------
Audience size: 50K-150K (US)
Expected CPL: $100-200
Lead quality: High (but long sales cycle)
```

### Template: HR Services Buyers

**ICP**: HR leaders evaluating HR outsourcing/services

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Human Resources

Seniority:
- CXO (CHRO)
- VP
- Director

Company Size:
- 201-500
- 501-1,000
- 1,001-5,000

Skills (optional):
- HR Management
- Talent Acquisition
- Employee Relations
- HRIS

EXCLUSIONS
----------
- Staffing/recruiting agencies
- HR consulting firms
- Title contains: "Recruiter" (if not target)

EXPECTED METRICS
----------------
Audience size: 80K-200K (US)
Expected CPL: $50-90
Lead quality: High
```

## Financial Services Templates

### Template: CFO/Finance Decision Makers

**ICP**: Finance leaders evaluating financial solutions

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Finance
- Accounting

Seniority:
- CXO (CFO)
- VP
- Director

Company Size:
- 501-1,000
- 1,001-5,000
- 5,001-10,000

Industries (optional):
- All (horizontal solution)
- OR specific verticals

Skills (optional layer):
- Financial Analysis
- Financial Planning
- Corporate Finance

EXCLUSIONS
----------
- Accounting firms
- Financial advisory firms
- Banks (if not target)

EXPECTED METRICS
----------------
Audience size: 100K-250K (US)
Expected CPL: $70-130
Lead quality: Very high
```

### Template: FinTech Early Adopters

**ICP**: Tech-forward finance professionals at growth companies

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Finance
- Accounting
- Operations

Seniority:
- Director
- Manager
- Senior

Company Size:
- 51-200
- 201-500
- 501-1,000

Company Growth:
- Growing companies (if available)

Industries:
- Computer Software
- Internet
- Financial Services
- E-commerce

EXCLUSIONS
----------
- Traditional banks
- Title contains: "Analyst" (if too junior)

EXPECTED METRICS
----------------
Audience size: 50K-150K (US)
Expected CPL: $40-80
Lead quality: High (innovation-minded)
```

## Healthcare & Life Sciences Templates

### Template: Healthcare IT Decision Makers

**ICP**: IT leaders at healthcare organizations

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Information Technology
- Engineering

Seniority:
- CXO (CIO, CTO, CISO)
- VP
- Director

Industries:
- Hospital & Health Care
- Pharmaceuticals
- Medical Devices
- Biotechnology

Company Size:
- 501-1,000
- 1,001-5,000
- 5,001-10,000
- 10,001+

Skills (optional):
- Healthcare IT
- HIPAA
- Electronic Health Records

EXCLUSIONS
----------
- Staffing agencies
- Consulting firms

EXPECTED METRICS
----------------
Audience size: 30K-100K (US)
Expected CPL: $80-150
Lead quality: High (regulated industry)
```

### Template: Life Sciences R&D Leaders

**ICP**: Research leaders at pharma/biotech companies

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Research
- Engineering
- Product Management

Seniority:
- CXO (CSO)
- VP
- Director

Industries:
- Pharmaceuticals
- Biotechnology
- Medical Devices

Company Size:
- 201-500
- 501-1,000
- 1,001-5,000
- 5,001-10,000

EXCLUSIONS
----------
- CROs/service providers
- Academic institutions (if not target)

EXPECTED METRICS
----------------
Audience size: 20K-60K (US)
Expected CPL: $100-180
Lead quality: Very high (specialized)
```

## SMB & Mid-Market Templates

### Template: SMB Business Owners

**ICP**: Owners and executives at small businesses

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- All (Owner/CXO level makes function less relevant)

Seniority:
- Owner
- CXO
- Partner

Company Size:
- 11-50
- 51-200

Industries:
- By vertical relevance
- OR broad for horizontal solutions

EXCLUSIONS
----------
- Consultants/freelancers
- Title contains: "Freelance", "Independent"

EXPECTED METRICS
----------------
Audience size: 500K-2M (US)
Expected CPL: $20-50
Lead quality: Medium (varied fit)
```

### Template: Mid-Market Ops Leaders

**ICP**: Operations leaders at mid-sized companies

```
TARGETING CONFIGURATION
-----------------------
Job Functions:
- Operations
- Program and Project Management
- Administrative

Seniority:
- VP
- Director
- Manager

Company Size:
- 201-500
- 501-1,000

Industries:
- Manufacturing
- Logistics
- Healthcare
- Professional Services

EXCLUSIONS
----------
- Consulting firms
- Title contains: "Coordinator", "Assistant"

EXPECTED METRICS
----------------
Audience size: 100K-300K (US)
Expected CPL: $35-70
Lead quality: High
```

## ABM Campaign Templates

### Template: Target Account - Full Coverage

**ICP**: All relevant roles at named accounts

```
TARGETING CONFIGURATION
-----------------------
Matched Audiences:
- Account list (target companies)

Job Functions:
- Primary buying function
- Secondary influencer functions

Seniority:
- CXO
- VP
- Director
- Manager

No additional company filters (list is filter)

EXCLUSIONS
----------
- Won/existing customers
- Disqualified accounts
- Competitor employees (if on list)

EXPECTED METRICS
----------------
Audience size: 5K-50K (per 100 accounts)
Expected CPL: $100-250
Lead quality: Very high (named accounts)
```

### Template: Target Account - Decision Makers Only

**ICP**: Senior leaders at named accounts

```
TARGETING CONFIGURATION
-----------------------
Matched Audiences:
- Account list (target companies)

Job Functions:
- Primary buying function only

Seniority:
- CXO
- VP

No additional company filters

EXCLUSIONS
----------
- Won accounts
- Recently engaged (30d)

EXPECTED METRICS
----------------
Audience size: 1K-10K (per 100 accounts)
Expected CPL: $150-300
Lead quality: Highest (decision makers only)
```

### Template: Competitive Conquest

**ICP**: Users of competitor products

```
TARGETING CONFIGURATION
-----------------------
Company Followers:
- Competitor company pages

Job Functions:
- Primary user function

Seniority:
- Director
- Manager
- Senior

Company Size:
- Match your target market

EXCLUSIONS
----------
- Competitor employees
- Current customers

EXPECTED METRICS
----------------
Audience size: 20K-100K
Expected CPL: $50-100
Lead quality: High (competitor familiarity)
```

## Retargeting Templates

### Template: Website Retargeting - High Intent

**ICP**: Recent website visitors showing buying signals

```
TARGETING CONFIGURATION
-----------------------
Website Audiences:
- Pricing page visitors (30 days)
- Demo/trial page visitors (30 days)
- Product page visitors (60 days)

Exclude:
- Converters (30 days)
- Current customers

No additional attribute targeting
(Let website behavior qualify)

EXPECTED METRICS
----------------
Audience size: 1K-20K (depends on traffic)
Expected CPL: $30-60
Lead quality: Very high (demonstrated intent)
```

### Template: Website Retargeting - Nurture

**ICP**: Content engaged visitors needing nurture

```
TARGETING CONFIGURATION
-----------------------
Website Audiences:
- Blog visitors (90 days)
- Resource page visitors (90 days)
- All visitors (180 days)

Exclude:
- High-intent page visitors (separate campaign)
- Converters

Layer (optional):
- Job function alignment
- Seniority: Manager+

EXPECTED METRICS
----------------
Audience size: 5K-50K
Expected CPL: $40-80
Lead quality: Medium (awareness stage)
```

### Template: Engagement Retargeting

**ICP**: Users who engaged with LinkedIn content

```
TARGETING CONFIGURATION
-----------------------
Engagement Audiences:
- Video viewers (50%+) - 180 days
- Lead gen form openers - 90 days
- Company page visitors - 180 days
- Single image ad engagers - 90 days

Exclude:
- Converters
- Current customers

EXPECTED METRICS
----------------
Audience size: 5K-30K
Expected CPL: $30-70
Lead quality: Medium-high (engaged)
```

## Lookalike Templates

### Template: Lookalike - Customer Expansion

**ICP**: Profiles similar to best customers

```
TARGETING CONFIGURATION
-----------------------
Seed Audience:
- Customer contact list (best customers)
- Minimum 1,000 contacts

Lookalike Settings:
- Country: [Target market]
- Size: Use LinkedIn default

Layer (recommended):
- Job function match
- Seniority: Director+
- Company size alignment

EXCLUSIONS
----------
- Seed list (existing customers)
- Recent leads (90 days)

EXPECTED METRICS
----------------
Audience size: 200K-500K
Expected CPL: $40-70
Lead quality: Medium-high
```

### Template: Lookalike - Converter Expansion

**ICP**: Profiles similar to website converters

```
TARGETING CONFIGURATION
-----------------------
Seed Audience:
- Website converters
- Minimum 300 members

Layer (recommended):
- Job function alignment
- Company size match

EXCLUSIONS
----------
- Website retargeting audiences
- Current customers

EXPECTED METRICS
----------------
Audience size: 300K-800K
Expected CPL: $35-60
Lead quality: Medium
```

## Usage Guidelines

### Selecting the Right Template

1. **Identify your ICP**: Who is your ideal buyer?
2. **Match to template**: Find closest match
3. **Customize**: Adjust attributes to your specifics
4. **Size check**: Ensure 50K+ for testing
5. **Launch and iterate**: Refine based on performance

### Customization Priorities

When adapting templates:

1. **Company Size**: Match your actual deal sizes
2. **Industries**: Align with your vertical focus
3. **Seniority**: Match your buying cycle
4. **Skills**: Add only if critical to fit
5. **Exclusions**: Always exclude customers

### Template Combinations

For multi-audience campaigns:

```
Campaign Structure Example:
├── Audience 1: ICP Prospecting template
├── Audience 2: ABM Full Coverage template  
├── Audience 3: Website Retargeting - High Intent
└── Budget split: 50% / 30% / 20%
```
