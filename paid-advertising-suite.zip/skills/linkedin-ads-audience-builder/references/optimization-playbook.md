# LinkedIn Ads Audience Optimization Playbook

Systematic approach to analyzing and refining LinkedIn audience targeting based on performance data and CRM feedback.

## Performance Analysis Framework

### Key Metrics by Funnel Stage

| Stage | Primary Metrics | Target Ranges |
|-------|----------------|---------------|
| Awareness | Impressions, CPM, Reach | CPM $8-15 |
| Engagement | CTR, Engagement Rate | CTR 0.4-1.0% |
| Conversion | Conversion Rate, CPL | CVR 5-15%, CPL varies |
| Quality | MQL Rate, SQL Rate, Pipeline | 40%+ MQL rate |

### Metric Benchmarks by Campaign Type

**Lead Gen Campaigns**:
| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| CTR | <0.3% | 0.3-0.5% | 0.5-0.8% | >0.8% |
| CVR | <3% | 3-8% | 8-15% | >15% |
| CPL | >$150 | $80-150 | $40-80 | <$40 |
| MQL Rate | <30% | 30-50% | 50-70% | >70% |

**Sponsored Content**:
| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| CTR | <0.35% | 0.35-0.5% | 0.5-0.7% | >0.7% |
| Engagement | <0.5% | 0.5-1% | 1-2% | >2% |
| CPM | >$15 | $10-15 | $6-10 | <$6 |

**Message Ads**:
| Metric | Poor | Average | Good | Excellent |
|--------|------|---------|------|-----------|
| Open Rate | <30% | 30-45% | 45-60% | >60% |
| CTR | <2% | 2-5% | 5-10% | >10% |
| Cost/Send | >$1 | $0.60-1 | $0.30-0.60 | <$0.30 |

## Diagnostic Framework

### Low CTR Diagnosis

**Potential Causes**:
1. Audience-creative mismatch
2. Weak offer/value proposition
3. Audience fatigue (high frequency)
4. Wrong funnel stage messaging

**Diagnostic Questions**:
- Is CTR consistent across all audiences? → Creative issue
- Is CTR low on one audience only? → Targeting mismatch
- Has CTR declined over time? → Audience fatigue
- Is frequency >5/week? → Audience exhaustion

**Solutions by Cause**:
| Cause | Solution |
|-------|----------|
| Creative mismatch | Test new creative angles |
| Weak offer | Test different offers/CTAs |
| Audience fatigue | Expand audience, refresh creative |
| Wrong stage | Align message to audience awareness |

### High CPL Diagnosis

**Potential Causes**:
1. Audience too narrow (limited competition)
2. Audience too broad (low relevance)
3. Low conversion rate (landing page)
4. High CPC (competitive audience)

**Diagnostic Questions**:
- Is audience <50K? → May be too narrow
- Is CTR good but CVR low? → Landing page issue
- Is CTR low? → Targeting or creative issue
- Are specific segments driving up CPL? → Targeting refinement needed

**Solutions by Cause**:
| Cause | Solution |
|-------|----------|
| Too narrow | Expand seniority or function |
| Too broad | Add targeting layers |
| Low CVR | Optimize landing page |
| High CPC | Adjust bid strategy, test new segments |

### Low Lead Quality Diagnosis

**Potential Causes**:
1. Too junior targeting (seniority too low)
2. Wrong function (role mismatch)
3. Company size mismatch (too small/large)
4. Industry misalignment

**Diagnostic Questions**:
- What titles are converting? → Title alignment issue
- What company sizes are converting? → Size targeting issue
- What industries are converting? → Industry focus needed
- Are leads engaged but unqualified? → Offer attracting wrong fit

**Solutions by Cause**:
| Cause | Solution |
|-------|----------|
| Junior leads | Exclude junior seniorities/titles |
| Wrong function | Narrow to core function only |
| Size mismatch | Adjust company size brackets |
| Industry issue | Focus on converting industries |

## CRM Feedback Integration

### Data Points to Track

**From CRM/Sales**:
| Data Point | Use Case |
|------------|----------|
| Lead status changes | MQL/SQL rates by source |
| Won/lost reasons | ICP refinement |
| Job titles of wins | Title targeting optimization |
| Company attributes of wins | Company targeting refinement |
| Time to close | Campaign attribution |
| Deal size by segment | ROI calculation |

### Feedback Loop Process

**Weekly**:
1. Pull lead status by LinkedIn campaign
2. Calculate MQL rate by audience
3. Flag low-quality segments

**Monthly**:
1. Analyze SQL rates by audience
2. Review title/company patterns in wins
3. Identify exclusion candidates

**Quarterly**:
1. Full CRM attribution analysis
2. Major audience restructuring
3. Update exclusion lists
4. Refresh targeting based on closed-won profile

### Quality Score Calculation

```
Lead Quality Score Formula:
--------------------------
MQL Rate: 30% weight
SQL Rate: 40% weight
Won Rate: 30% weight

Score = (MQL% × 0.3) + (SQL% × 0.4) + (Won% × 0.3)

Example:
MQL Rate: 50%
SQL Rate: 30%
Won Rate: 10%

Score = (50 × 0.3) + (30 × 0.4) + (10 × 0.3)
Score = 15 + 12 + 3 = 30 (out of 100)
```

### Segment Performance Tracking

Track by audience segment:

| Segment | Leads | MQLs | SQLs | Opps | Wins | Quality Score |
|---------|-------|------|------|------|------|---------------|
| Enterprise VP+ | 50 | 35 | 20 | 10 | 3 | 62 |
| Mid-Market Dir | 80 | 45 | 25 | 12 | 4 | 51 |
| SMB Manager | 120 | 40 | 15 | 5 | 1 | 28 |
| ABM Accounts | 20 | 16 | 12 | 8 | 4 | 80 |

**Action**: Shift budget to segments with highest quality scores.

## Optimization Playbooks

### Playbook: New Campaign Launch

**Week 1-2: Baseline**
- [ ] Launch with 3-5 audience variations
- [ ] Even budget split across audiences
- [ ] Gather 1,000+ impressions per audience
- [ ] Track CTR and initial conversion rate

**Week 3-4: Initial Optimization**
- [ ] Pause audiences with CTR <0.3%
- [ ] Increase budget on CTR >0.5%
- [ ] Check lead quality feedback
- [ ] Refine exclusions based on poor leads

**Month 2: Scaling**
- [ ] Double down on top performers
- [ ] Test expansion variations of winners
- [ ] Implement exclusion learnings
- [ ] Introduce retargeting

**Month 3+: Mature Optimization**
- [ ] Monthly audience refresh
- [ ] Quarterly restructuring
- [ ] Continuous exclusion updates
- [ ] CRM feedback integration

### Playbook: Declining Performance

**Diagnosis Phase (Week 1)**:
- [ ] Identify when decline started
- [ ] Check audience sizes (shrinking?)
- [ ] Review frequency metrics
- [ ] Analyze by audience segment

**Quick Fixes (Week 2)**:
- [ ] Refresh creative (new images, copy)
- [ ] Expand audience size by 20-30%
- [ ] Adjust bid strategy
- [ ] Update exclusions

**Structural Changes (Week 3-4)**:
- [ ] Test new audience segments
- [ ] Restructure campaign architecture
- [ ] Update targeting based on CRM feedback
- [ ] Consider new offer/lead magnet

**Long-term (Month 2+)**:
- [ ] Full audience audit
- [ ] Competitive analysis
- [ ] ICP reassessment
- [ ] Platform diversification (if needed)

### Playbook: Scaling Successful Campaign

**Phase 1: Horizontal Scaling**
- [ ] Test adjacent job functions
- [ ] Expand seniority range (carefully)
- [ ] Add related industries
- [ ] Increase company size range

**Phase 2: Vertical Scaling**
- [ ] Increase budgets on winners
- [ ] Create lookalike audiences
- [ ] Launch retargeting for conversions
- [ ] Test new geographies

**Phase 3: Full Funnel**
- [ ] Add awareness layer (content)
- [ ] Implement sequential messaging
- [ ] Integrate ABM for enterprise
- [ ] Connect retargeting across stages

**Scaling Risks**:
| Risk | Mitigation |
|------|------------|
| Quality decline | Monitor MQL rates weekly |
| CPL increase | Gradual expansion, bid caps |
| Audience overlap | Clear exclusion structure |
| Creative fatigue | Fresh creative monthly |

## Audience Testing Framework

### A/B Testing Methodology

**Test One Variable at a Time**:
- Audience A: VP + Director + Manager
- Audience B: VP + Director only
- Control: Same creative, offer, budget

**Minimum Test Duration**: 2 weeks or 50 conversions

**Statistical Significance**:
- Need 95% confidence before declaring winner
- Use LinkedIn's built-in testing or external calculator

### Testing Priority Matrix

| Test Type | Impact | Effort | Priority |
|-----------|--------|--------|----------|
| Seniority levels | High | Low | 1st |
| Company size | High | Low | 2nd |
| Job function expansion | Medium | Low | 3rd |
| Industry focus | Medium | Low | 4th |
| Skills layer | High | Medium | 5th |
| Title keywords | Medium | Medium | 6th |
| Lookalike vs direct | High | Medium | 7th |

### Testing Calendar

**Month 1**: Foundation tests
- Seniority variations (3 tests)
- Company size variations (2 tests)

**Month 2**: Targeting tests
- Function expansion (2 tests)
- Industry focus (2 tests)

**Month 3**: Advanced tests
- Skills layers (2 tests)
- Matched audiences (2 tests)

**Ongoing**: 
- 1-2 active tests at all times
- Document all learnings
- Apply winners to all campaigns

## Exclusion Optimization

### Exclusion Audit Checklist

**Monthly Review**:
- [ ] Customer list uploaded and current
- [ ] Recent converters excluded (30-90d)
- [ ] Disqualified leads added
- [ ] Employee exclusion active
- [ ] Competitor exclusion reviewed

### Dynamic Exclusion Updates

| Trigger | Action |
|---------|--------|
| New customer closes | Add to exclusion list |
| Lead disqualified | Add to exclusion list |
| Employee joins | Update employee exclusion |
| Competitor identified | Add to competitor exclusion |

### Exclusion Impact Analysis

Track exclusion impact:

| Exclusion Type | Size | Impact on Reach | Impact on Quality |
|----------------|------|-----------------|-------------------|
| Customers | 5,000 | -2% | +10% quality |
| Disqualified | 2,000 | -1% | +15% quality |
| Competitors | 500 | <1% | +5% quality |
| Employees | 200 | <1% | +2% quality |

## Reporting Templates

### Weekly Performance Report

```
LINKEDIN ADS WEEKLY REPORT
Week of: [Date]

SUMMARY METRICS
--------------
Spend: $X,XXX
Impressions: XXX,XXX
Clicks: X,XXX
CTR: X.XX%
Conversions: XX
CVR: X.X%
CPL: $XX

TOP PERFORMING AUDIENCES
------------------------
1. [Audience Name] - CPL: $XX, Leads: XX
2. [Audience Name] - CPL: $XX, Leads: XX
3. [Audience Name] - CPL: $XX, Leads: XX

ACTION ITEMS
------------
- [ ] [Optimization action]
- [ ] [Testing action]
- [ ] [Exclusion update]

NEXT WEEK FOCUS
---------------
[Priority for next week]
```

### Monthly Quality Report

```
LINKEDIN ADS QUALITY REPORT
Month: [Month Year]

LEAD QUALITY BY AUDIENCE
------------------------
| Audience | Leads | MQLs | MQL% | SQLs | SQL% |
|----------|-------|------|------|------|------|
| [Name]   | XX    | XX   | XX%  | XX   | XX%  |

TOP CONVERTING SEGMENTS
-----------------------
Titles: [List of high-converting titles]
Industries: [List of high-converting industries]
Company sizes: [List of high-converting sizes]

EXCLUSION CANDIDATES
--------------------
[Segments with <30% MQL rate to consider excluding]

RECOMMENDATIONS
---------------
1. [Targeting recommendation]
2. [Budget recommendation]
3. [Exclusion recommendation]
```

### Quarterly Strategy Review

```
LINKEDIN ADS QUARTERLY REVIEW
Quarter: [Q# Year]

PERFORMANCE SUMMARY
-------------------
Total spend: $XX,XXX
Total leads: XXX
Average CPL: $XX
Total MQLs: XXX
Total SQLs: XX
Pipeline generated: $XXX,XXX

ROI ANALYSIS
------------
Marketing investment: $XX,XXX
Pipeline value: $XXX,XXX
ROI: X.Xx

AUDIENCE PERFORMANCE RANKING
----------------------------
[Rank all audiences by quality score]

STRATEGIC RECOMMENDATIONS
-------------------------
1. [Major targeting change]
2. [Budget reallocation]
3. [New audience opportunities]
4. [Exclusion strategy update]

NEXT QUARTER PRIORITIES
-----------------------
[List of strategic priorities]
```
