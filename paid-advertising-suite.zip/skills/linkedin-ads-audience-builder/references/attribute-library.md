# LinkedIn Targeting Attribute Library

Complete reference for all LinkedIn Ads targeting attributes, options, and recommended combinations.

## Job Function Attributes

### Complete Job Function List

| Function | Description | Best Paired With |
|----------|-------------|------------------|
| Accounting | Finance professionals | Finance function |
| Administrative | Office support roles | Operations |
| Arts and Design | Creative professionals | Marketing |
| Business Development | Growth-focused roles | Sales |
| Community and Social Services | Nonprofit, social work | Education |
| Consulting | Advisory roles | Multiple |
| Education | Teaching, training | HR for L&D |
| Engineering | Technical builders | Product, IT |
| Entrepreneurship | Founders, startup roles | C-suite |
| Finance | Financial management | Accounting |
| Healthcare Services | Medical professionals | Operations |
| Human Resources | People operations | Administrative |
| Information Technology | Tech infrastructure | Engineering |
| Legal | Legal professionals | Finance |
| Marketing | Demand gen, brand | Sales, BD |
| Media and Communications | PR, journalism | Marketing |
| Military and Protective Services | Defense, security | IT (cybersecurity) |
| Operations | Business operations | Multiple |
| Product Management | Product strategy | Engineering |
| Program and Project Management | Delivery roles | Operations |
| Purchasing | Procurement | Finance |
| Quality Assurance | QA roles | Engineering |
| Real Estate | Property professionals | Finance |
| Research | R&D roles | Engineering |
| Sales | Revenue generation | BD, Marketing |
| Support | Customer success | Sales |

### Function Combinations by Solution Type

**SaaS/Software Products**:
- Primary: IT, Engineering, Product Management
- Secondary: Operations, Program Management
- Decision: Finance (for budget approval)

**Marketing Technology**:
- Primary: Marketing
- Secondary: Sales, Business Development
- Decision: Marketing + Finance

**HR Technology**:
- Primary: Human Resources
- Secondary: Operations, Administrative
- Decision: HR + Finance

**Sales Technology**:
- Primary: Sales, Business Development
- Secondary: Marketing, Operations
- Decision: Sales + Finance

**Finance/Accounting Solutions**:
- Primary: Finance, Accounting
- Secondary: Operations
- Decision: Finance + C-suite

## Seniority Levels

### Complete Seniority Options

| Level | LinkedIn Definition | Typical Titles |
|-------|--------------------|--------------------|
| Owner | Business owners | Founder, Co-founder, Owner |
| Partner | Professional partnerships | Partner, Principal |
| CXO | C-suite executives | CEO, CFO, CTO, CMO, COO |
| VP | Vice president level | VP, SVP, EVP |
| Director | Department leadership | Director, Senior Director |
| Manager | Team leadership | Manager, Senior Manager |
| Senior | Experienced individual | Senior [Role], Lead |
| Entry | Early career | Associate, Analyst, Coordinator |
| Training | Learning/intern | Intern, Trainee, Apprentice |
| Unpaid | Volunteer roles | Volunteer |

### Seniority Combinations by Campaign Goal

**Decision Maker Targeting**:
```
Seniority: CXO + VP + Director
Use case: Enterprise deals, budget approval
```

**Influencer Targeting**:
```
Seniority: Manager + Senior
Use case: Product evaluation, champions
```

**Full Committee**:
```
Seniority: CXO + VP + Director + Manager
Use case: Complex buying cycles
```

**SMB Targeting**:
```
Seniority: Owner + CXO + VP
Use case: Smaller companies where titles run senior
```

## Company Attributes

### Company Size Brackets

| LinkedIn Option | Employee Range | Market Segment |
|-----------------|---------------|----------------|
| Self-employed | 1 | Freelancers |
| 1-10 | 1-10 | Micro business |
| 11-50 | 11-50 | Small business |
| 51-200 | 51-200 | SMB |
| 201-500 | 201-500 | Mid-market |
| 501-1,000 | 501-1,000 | Mid-market |
| 1,001-5,000 | 1,001-5,000 | Enterprise |
| 5,001-10,000 | 5,001-10,000 | Large enterprise |
| 10,001+ | 10,001+ | Global enterprise |

### Company Size by Go-to-Market

**PLG/Self-Serve Focus**:
```
Targets: Self-employed, 1-10, 11-50
Note: Higher volume, lower deal size
```

**SMB Sales**:
```
Targets: 51-200, 201-500
Note: Balanced volume and deal size
```

**Mid-Market Sales**:
```
Targets: 201-500, 501-1,000, 1,001-5,000
Note: Sweet spot for many B2B
```

**Enterprise Sales**:
```
Targets: 1,001-5,000, 5,001-10,000, 10,001+
Note: Lower volume, higher deal size
```

### Industry Categories

#### Technology & Software
- Computer Software
- Information Technology & Services
- Internet
- Computer & Network Security
- Computer Networking
- Telecommunications

#### Financial Services
- Financial Services
- Banking
- Insurance
- Investment Banking
- Investment Management
- Venture Capital & Private Equity

#### Professional Services
- Management Consulting
- Legal Services
- Accounting
- Human Resources
- Staffing and Recruiting

#### Healthcare
- Hospital & Health Care
- Pharmaceuticals
- Biotechnology
- Medical Devices
- Health, Wellness and Fitness

#### Manufacturing & Industrial
- Industrial Automation
- Machinery
- Automotive
- Aviation & Aerospace
- Electrical/Electronic Manufacturing

#### Retail & Consumer
- Retail
- Consumer Goods
- Food & Beverages
- Apparel & Fashion
- E-Learning

#### Other Common Industries
- Real Estate
- Construction
- Transportation/Trucking/Railroad
- Education Management
- Marketing and Advertising
- Media Production

### Company Growth Rate

| Growth Signal | Use Case |
|---------------|----------|
| Growing companies | In expansion mode, more budget |
| Flat/stable | Established but less urgency |
| Declining | Cost-cutting focus |

**Note**: Growth rate targeting limits audience significantly. Use sparingly.

### Company Followers

Target members who follow specific company pages:
- Competitor followers
- Industry leader followers
- Publication/media followers

**Best for**: Competitive conquesting, industry-aware audiences

## Skills Targeting

### Technology Skills Categories

**Programming Languages**:
Python, JavaScript, Java, SQL, R, C++, Ruby, Go, TypeScript

**Cloud Platforms**:
AWS, Azure, Google Cloud Platform, Salesforce, Oracle Cloud

**Data & Analytics**:
Data Analysis, Machine Learning, Business Intelligence, Tableau, Power BI

**DevOps & Infrastructure**:
Docker, Kubernetes, CI/CD, Jenkins, Terraform, Ansible

**Security**:
Cybersecurity, Network Security, Information Security, Penetration Testing

### Business Skills Categories

**Marketing**:
Digital Marketing, SEO, Content Marketing, Marketing Automation, ABM

**Sales**:
Sales Management, Account Management, Business Development, CRM

**Leadership**:
Strategic Planning, Team Leadership, Change Management, Executive Management

**Operations**:
Project Management, Process Improvement, Six Sigma, Agile Methodologies

### Skills Targeting Strategy

**Narrow by Technical Skills**:
```
Base: IT Function + Director+ Seniority
Layer: Skills = "Kubernetes" OR "Docker"
Result: Infrastructure decision-makers
```

**Narrow by Business Skills**:
```
Base: Marketing Function + Manager+ Seniority
Layer: Skills = "Marketing Automation" OR "ABM"
Result: Marketing ops professionals
```

**Exclude by Skills**:
```
Base: IT Function
Exclude: Skills = "Student" OR "Intern level skills"
Result: Experienced IT professionals
```

## Member Groups

### High-Value Group Categories

**Executive Groups**:
- C-Suite Network
- CEO Networking Groups
- VP/Director communities

**Industry Groups**:
- SaaS Founders/Leaders
- FinTech Professionals
- Healthcare IT
- MarTech community

**Function Groups**:
- CMO Coffee Talk
- Sales Development Leaders
- HR Tech Community
- Product Management groups

### Group Targeting Strategy

Groups indicate interest and engagement. Best used as:
1. **Signal layers** on top of function/seniority
2. **Expansion** for niche topics
3. **Alternative** when function targeting is too broad

## Member Interests & Traits

### Interest Categories

**Technology Interests**:
Artificial Intelligence, Cloud Computing, Big Data, IoT, Blockchain

**Business Interests**:
Entrepreneurship, Leadership, Marketing, Sales, Finance

**Industry Interests**:
Healthcare, Financial Services, Technology, Manufacturing

### Member Traits

| Trait | Definition | Use Case |
|-------|------------|----------|
| Job Seeker | Active job searching | Recruiting |
| Frequent Traveler | Business travel patterns | Travel solutions |
| Open to Education | Learning-oriented | Training products |
| Desktop User | Primary device | Software targeting |
| Mobile User | Primary device | Mobile-first products |

**Note**: Traits significantly narrow audiences. Test carefully.

## Education Targeting

### Degree Levels

| Degree | Typical Use |
|--------|------------|
| Associate | Entry-level roles |
| Bachelor | Professional roles |
| Master | Senior/specialized |
| Doctorate | Academic, research |
| Professional | Law, medicine |

### Fields of Study

Target by educational background for:
- Technical roles (Computer Science, Engineering)
- Business roles (MBA, Business Administration)
- Specialized roles (Finance, Marketing)

### Schools

Target alumni of specific universities for:
- Executive programs (HBS, Stanford GSB)
- Technical talent (MIT, Stanford, CMU)
- Regional targeting

## Demographics

### Location Targeting

| Level | Use Case |
|-------|----------|
| Country | National campaigns |
| State/Province | Regional focus |
| Metro/City | Local targeting |
| Postal Code | Hyper-local |

**Radius Targeting**: Available for cities/addresses

### Age Targeting

| Range | Use Case |
|-------|----------|
| 18-24 | Entry level |
| 25-34 | Early career |
| 35-54 | Mid-career, decision makers |
| 55+ | Senior executives |

**Note**: Age targeting is limited and often unnecessary with seniority.

## Matched Audience Types

### Website Audiences

| Type | Requirement | Best Use |
|------|-------------|----------|
| All website visitors | Insight Tag | Broad retargeting |
| Specific page visitors | URL rules | Intent-based |
| Event-based | Event tracking | Action-based |

### Contact Lists

| Format | Match Fields |
|--------|-------------|
| CSV upload | Email, First Name, Last Name, Company, Title |
| Integration | Salesforce, HubSpot, Marketo sync |

### Company Lists

| Format | Match Fields |
|--------|-------------|
| CSV upload | Company Name, Website, LinkedIn URL |
| Integration | ABM platform sync |

### Lookalike Audiences

| Seed Type | Minimum Size | Quality |
|-----------|--------------|---------|
| Contact list | 300 | High |
| Company list | 300 | High |
| Website visitors | 300 | Medium-High |
| Single Image Ad engagers | 300 | Medium |
| Video viewers | 300 | Medium |

## Attribute Combination Rules

### AND Logic (Between Categories)

Each additional category NARROWS the audience:
```
Job Function: Marketing
AND Seniority: Director+
AND Company Size: 1000+
AND Industry: Software
= Smaller, more precise audience
```

### OR Logic (Within Categories)

Multiple selections within a category EXPAND:
```
Job Function: Marketing OR Sales OR Business Development
= Larger audience
```

### Exclusion Logic

Exclusions remove matching members:
```
Include: Marketing function
Exclude: Title contains "Intern"
= Marketing pros minus interns
```

## Audience Size Impact by Attribute

| Attribute Added | Typical Impact |
|-----------------|----------------|
| Country | Sets base size |
| Job Function (single) | -60-80% |
| Seniority (2-3 levels) | -40-60% |
| Company Size (2-3 brackets) | -30-50% |
| Industry (single) | -70-90% |
| Skills (single) | -80-95% |
| Company list | Limits to list |

### Size Expansion Strategies

When audience is too small:
1. Add more seniority levels
2. Add related job functions
3. Expand company size brackets
4. Add related industries
5. Remove skill requirements
6. Use lookalike expansion

### Size Restriction Strategies

When audience is too large:
1. Add skill requirements
2. Narrow company size
3. Add company list overlay
4. Limit to single industry
5. Add title exclusions
6. Use AND logic between categories
