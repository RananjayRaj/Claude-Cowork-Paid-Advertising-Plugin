#!/usr/bin/env python3
"""
Analyze Historical Campaign Data
Extract performance patterns from historical ad campaign data to identify winning creative elements.
"""

import pandas as pd
import json
import re
from collections import Counter
from datetime import datetime, timedelta

def load_data(file_path):
    """Load historical campaign data from CSV or Excel"""
    if file_path.endswith('.csv'):
        return pd.read_csv(file_path)
    elif file_path.endswith(('.xlsx', '.xls')):
        return pd.read_excel(file_path)
    else:
        raise ValueError("Unsupported file format. Use CSV or Excel.")

def calculate_performance_percentiles(df, metric_column):
    """Identify top and bottom performers"""
    df['performance_percentile'] = df[metric_column].rank(pct=True)
    
    top_performers = df[df['performance_percentile'] >= 0.8].copy()
    bottom_performers = df[df['performance_percentile'] <= 0.2].copy()
    
    return top_performers, bottom_performers

def extract_text_features(text):
    """Extract key features from ad text"""
    if pd.isna(text) or text == '':
        return {}
    
    text = str(text)
    
    features = {
        'length': len(text),
        'word_count': len(text.split()),
        'has_question': '?' in text,
        'has_exclamation': '!' in text,
        'has_numbers': bool(re.search(r'\d', text)),
        'has_percentage': '%' in text or 'percent' in text.lower(),
        'has_dollar': '$' in text or 'dollar' in text.lower(),
        'has_emoji': bool(re.search(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', text)),
        'has_brackets': bool(re.search(r'[\[\]\(\)]', text)),
        'all_caps_words': len(re.findall(r'\b[A-Z]{2,}\b', text)),
        'has_you': bool(re.search(r'\byou\b|\byour\b', text.lower())),
        'has_we': bool(re.search(r'\bwe\b|\bour\b', text.lower())),
    }
    
    # CTA detection
    cta_words = ['learn', 'discover', 'get', 'start', 'try', 'sign up', 'download', 
                 'register', 'join', 'buy', 'shop', 'order', 'request', 'book', 'schedule']
    features['has_cta'] = any(word in text.lower() for word in cta_words)
    
    # Urgency words
    urgency_words = ['now', 'today', 'limited', 'hurry', 'soon', 'deadline', 'expires', 'last chance']
    features['has_urgency'] = any(word in text.lower() for word in urgency_words)
    
    # Social proof
    social_proof_words = ['trusted', 'proven', 'award', 'leading', 'top', '#1', 'best', 'customers', 'reviews']
    features['has_social_proof'] = any(word in text.lower() for word in social_proof_words)
    
    return features

def extract_patterns(top_performers, bottom_performers, text_column='headline'):
    """Extract patterns that differentiate winners from losers"""
    
    patterns = {
        'top_performers': {
            'count': len(top_performers),
            'features': Counter()
        },
        'bottom_performers': {
            'count': len(bottom_performers),
            'features': Counter()
        },
        'insights': []
    }
    
    # Analyze text features for top performers
    for idx, row in top_performers.iterrows():
        if text_column in row and pd.notna(row[text_column]):
            features = extract_text_features(row[text_column])
            for feature, value in features.items():
                if value is True or (isinstance(value, (int, float)) and value > 0):
                    patterns['top_performers']['features'][feature] += 1
    
    # Analyze text features for bottom performers
    for idx, row in bottom_performers.iterrows():
        if text_column in row and pd.notna(row[text_column]):
            features = extract_text_features(row[text_column])
            for feature, value in features.items():
                if value is True or (isinstance(value, (int, float)) and value > 0):
                    patterns['bottom_performers']['features'][feature] += 1
    
    # Calculate pattern strength
    for feature in patterns['top_performers']['features']:
        top_rate = patterns['top_performers']['features'][feature] / patterns['top_performers']['count']
        bottom_rate = patterns['bottom_performers']['features'].get(feature, 0) / max(patterns['bottom_performers']['count'], 1)
        
        if top_rate >= 0.7 and bottom_rate < 0.3:
            patterns['insights'].append({
                'feature': feature,
                'pattern_type': 'strong_positive',
                'top_rate': f"{top_rate:.1%}",
                'bottom_rate': f"{bottom_rate:.1%}",
                'recommendation': f"Include this element - present in {top_rate:.0%} of top performers"
            })
        elif top_rate >= 0.5 and top_rate > bottom_rate * 1.5:
            patterns['insights'].append({
                'feature': feature,
                'pattern_type': 'moderate_positive',
                'top_rate': f"{top_rate:.1%}",
                'bottom_rate': f"{bottom_rate:.1%}",
                'recommendation': f"Consider this element - {top_rate:.0%} presence in winners"
            })
        elif bottom_rate >= 0.6 and top_rate < 0.3:
            patterns['insights'].append({
                'feature': feature,
                'pattern_type': 'negative',
                'top_rate': f"{top_rate:.1%}",
                'bottom_rate': f"{bottom_rate:.1%}",
                'recommendation': f"Avoid this element - present in {bottom_rate:.0%} of poor performers"
            })
    
    return patterns

def calculate_metric_benchmarks(df, metric_columns):
    """Calculate performance benchmarks for each metric"""
    benchmarks = {}
    
    for metric in metric_columns:
        if metric in df.columns:
            benchmarks[metric] = {
                'mean': df[metric].mean(),
                'median': df[metric].median(),
                'top_20_pct': df[metric].quantile(0.8),
                'top_10_pct': df[metric].quantile(0.9),
                'bottom_20_pct': df[metric].quantile(0.2),
                'std_dev': df[metric].std()
            }
    
    return benchmarks

def analyze_by_platform(df, platform_column='platform'):
    """Analyze performance patterns by platform"""
    if platform_column not in df.columns:
        return None
    
    platform_insights = {}
    
    for platform in df[platform_column].unique():
        platform_data = df[df[platform_column] == platform]
        platform_insights[platform] = {
            'count': len(platform_data),
            'avg_performance': {}
        }
    
    return platform_insights

def analyze_recency(df, date_column='date'):
    """Apply recency weighting to patterns"""
    if date_column not in df.columns:
        return df
    
    df = df.copy()
    df[date_column] = pd.to_datetime(df[date_column])
    
    # Calculate days since campaign
    most_recent = df[date_column].max()
    df['days_ago'] = (most_recent - df[date_column]).dt.days
    
    # Apply exponential decay (half-life of 90 days)
    df['recency_weight'] = 0.5 ** (df['days_ago'] / 90)
    
    return df

def generate_analysis_report(df, primary_metric='ctr', text_columns=['headline', 'description']):
    """Generate comprehensive analysis report"""
    
    report = {
        'summary': {
            'total_campaigns': len(df),
            'date_range': f"{df['date'].min()} to {df['date'].max()}" if 'date' in df.columns else 'Unknown',
            'primary_metric': primary_metric
        },
        'benchmarks': {},
        'patterns': {},
        'recommendations': []
    }
    
    # Calculate benchmarks
    metric_columns = ['ctr', 'conversion_rate', 'cpc', 'engagement_rate', 'roas']
    report['benchmarks'] = calculate_metric_benchmarks(df, metric_columns)
    
    # Extract patterns for each text column
    top_performers, bottom_performers = calculate_performance_percentiles(df, primary_metric)
    
    for col in text_columns:
        if col in df.columns:
            patterns = extract_patterns(top_performers, bottom_performers, col)
            report['patterns'][col] = patterns
    
    # Generate recommendations
    for col, pattern_data in report['patterns'].items():
        for insight in pattern_data.get('insights', []):
            if insight['pattern_type'] in ['strong_positive', 'moderate_positive']:
                report['recommendations'].append({
                    'element': col,
                    'feature': insight['feature'],
                    'action': 'include',
                    'strength': insight['pattern_type'],
                    'rationale': insight['recommendation']
                })
    
    return report

def main():
    """Main execution function"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python analyze_historical_data.py <data_file.csv> [primary_metric]")
        print("Example: python analyze_historical_data.py campaigns.csv ctr")
        sys.exit(1)
    
    file_path = sys.argv[1]
    primary_metric = sys.argv[2] if len(sys.argv) > 2 else 'ctr'
    
    print(f"Loading data from {file_path}...")
    df = load_data(file_path)
    
    print(f"Analyzing {len(df)} campaigns...")
    
    # Apply recency weighting if date column exists
    if 'date' in df.columns:
        df = analyze_recency(df, 'date')
    
    # Generate analysis
    report = generate_analysis_report(df, primary_metric=primary_metric)
    
    # Save report
    output_file = file_path.replace('.csv', '_analysis.json').replace('.xlsx', '_analysis.json')
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"\nAnalysis complete! Report saved to: {output_file}")
    print(f"\nKey Findings:")
    print(f"- Analyzed {report['summary']['total_campaigns']} campaigns")
    print(f"- Primary metric: {primary_metric.upper()}")
    print(f"- Found {len(report['recommendations'])} actionable patterns")
    
    print("\nTop Recommendations:")
    for i, rec in enumerate(report['recommendations'][:5], 1):
        print(f"{i}. {rec['feature']}: {rec['rationale']}")

if __name__ == "__main__":
    main()
