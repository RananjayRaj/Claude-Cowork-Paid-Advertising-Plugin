#!/usr/bin/env python3
"""
Score Creative Concepts
Score new ad creative concepts against historical performance patterns.
"""

import json
import re
from typing import Dict, List, Any

def extract_creative_features(creative_concept: Dict[str, str]) -> Dict[str, Any]:
    """Extract features from a creative concept"""
    features = {}
    
    # Extract text features from each component
    for field in ['headline', 'description', 'body', 'cta']:
        if field in creative_concept and creative_concept[field]:
            text = creative_concept[field]
            features[f'{field}_length'] = len(text)
            features[f'{field}_word_count'] = len(text.split())
            features[f'{field}_has_question'] = '?' in text
            features[f'{field}_has_exclamation'] = '!' in text
            features[f'{field}_has_numbers'] = bool(re.search(r'\d', text))
            features[f'{field}_has_percentage'] = '%' in text or 'percent' in text.lower()
            features[f'{field}_has_dollar'] = '$' in text
            features[f'{field}_has_emoji'] = bool(re.search(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', text))
            features[f'{field}_has_you'] = bool(re.search(r'\byou\b|\byour\b', text.lower()))
            features[f'{field}_has_urgency'] = bool(re.search(r'\bnow\b|\btoday\b|\blimited\b|\bhurry\b', text.lower()))
            features[f'{field}_has_social_proof'] = bool(re.search(r'\btrusted\b|\bproven\b|\baward\b|\bleading\b', text.lower()))
    
    # Visual features (if provided)
    if 'visual_type' in creative_concept:
        features['visual_type'] = creative_concept['visual_type']
    
    if 'has_people' in creative_concept:
        features['has_people'] = creative_concept['has_people']
    
    if 'color_scheme' in creative_concept:
        features['color_scheme'] = creative_concept['color_scheme']
    
    # Platform
    if 'platform' in creative_concept:
        features['platform'] = creative_concept['platform']
    
    return features

def calculate_feature_score(feature_name: str, feature_value: Any, patterns: Dict) -> float:
    """Calculate score for a single feature based on historical patterns"""
    
    # Look for this feature in patterns
    for insight in patterns.get('insights', []):
        if insight['feature'] == feature_name:
            if insight['pattern_type'] == 'strong_positive':
                return 10.0  # Strong boost
            elif insight['pattern_type'] == 'moderate_positive':
                return 5.0   # Moderate boost
            elif insight['pattern_type'] == 'negative':
                return -10.0  # Penalty
    
    return 0.0  # Neutral

def score_creative(creative_concept: Dict[str, str], historical_patterns: Dict, 
                  benchmarks: Dict, primary_metric: str = 'ctr') -> Dict[str, Any]:
    """Score a single creative concept"""
    
    # Extract features from creative
    features = extract_creative_features(creative_concept)
    
    # Initialize scoring components
    score_components = {
        'text_score': 0,
        'visual_score': 0,
        'platform_score': 0,
        'offer_score': 0
    }
    
    feature_scores = []
    
    # Score each feature against patterns
    for pattern_field in ['headline', 'description']:
        if pattern_field in historical_patterns:
            field_patterns = historical_patterns[pattern_field]
            
            for feature_name, feature_value in features.items():
                if pattern_field in feature_name and feature_value:
                    feature_score = calculate_feature_score(feature_name, feature_value, field_patterns)
                    if feature_score != 0:
                        feature_scores.append({
                            'feature': feature_name,
                            'score': feature_score,
                            'impact': 'positive' if feature_score > 0 else 'negative'
                        })
                        
                        # Add to appropriate component
                        if 'cta' in feature_name or 'offer' in feature_name:
                            score_components['offer_score'] += feature_score
                        else:
                            score_components['text_score'] += feature_score
    
    # Calculate composite score
    # Weights: Text 35%, Visual 30%, Platform 15%, Offer 20%
    base_score = 60  # Start at 60 (neutral baseline)
    
    # Normalize component scores to 0-100 range and apply weights
    text_contribution = (score_components['text_score'] / 50 * 35) if score_components['text_score'] != 0 else 0
    visual_contribution = (score_components['visual_score'] / 30 * 30) if score_components['visual_score'] != 0 else 0
    platform_contribution = (score_components['platform_score'] / 15 * 15) if score_components['platform_score'] != 0 else 0
    offer_contribution = (score_components['offer_score'] / 20 * 20) if score_components['offer_score'] != 0 else 0
    
    final_score = base_score + text_contribution + visual_contribution + platform_contribution + offer_contribution
    
    # Clamp score to 0-100
    final_score = max(0, min(100, final_score))
    
    # Calculate confidence based on pattern strength and data availability
    confidence = calculate_confidence(features, historical_patterns)
    
    # Generate predictions for specific metrics
    predictions = generate_metric_predictions(final_score, benchmarks, primary_metric)
    
    return {
        'creative_id': creative_concept.get('id', 'unknown'),
        'overall_score': round(final_score, 1),
        'confidence': confidence,
        'score_components': score_components,
        'feature_impacts': feature_scores,
        'predictions': predictions,
        'recommendation': generate_recommendation(final_score, confidence),
        'improvements': suggest_improvements(feature_scores, creative_concept)
    }

def calculate_confidence(features: Dict, patterns: Dict) -> str:
    """Calculate confidence level based on pattern coverage"""
    
    matched_patterns = 0
    total_features = len(features)
    
    for pattern_data in patterns.values():
        if isinstance(pattern_data, dict) and 'insights' in pattern_data:
            matched_patterns += len(pattern_data['insights'])
    
    if matched_patterns >= 10 and total_features >= 5:
        return "High (85-95%)"
    elif matched_patterns >= 5:
        return "Medium (70-84%)"
    else:
        return "Low (50-69%)"

def generate_metric_predictions(score: float, benchmarks: Dict, primary_metric: str) -> Dict:
    """Generate specific metric predictions based on score"""
    
    if primary_metric not in benchmarks:
        return {}
    
    benchmark_data = benchmarks[primary_metric]
    
    # Map score to performance tier
    if score >= 85:
        multiplier = 1.3  # Top tier: 30% above median
    elif score >= 75:
        multiplier = 1.15  # Good tier: 15% above median
    elif score >= 60:
        multiplier = 1.0  # Average tier: at median
    elif score >= 45:
        multiplier = 0.85  # Below average: 15% below median
    else:
        multiplier = 0.7  # Poor tier: 30% below median
    
    median = benchmark_data.get('median', 0)
    
    predictions = {
        primary_metric: {
            'predicted_value': median * multiplier,
            'benchmark_median': median,
            'vs_median': f"{((multiplier - 1) * 100):+.0f}%"
        }
    }
    
    return predictions

def generate_recommendation(score: float, confidence: str) -> str:
    """Generate recommendation based on score and confidence"""
    
    if score >= 90:
        return "🚀 Highly recommended - Strong winner potential. Scale aggressively."
    elif score >= 75:
        return "✅ Recommended - Solid performer. Standard allocation."
    elif score >= 60:
        return "⚠️ Proceed with caution - Average performer. Test carefully."
    elif score >= 45:
        return "🔴 Not recommended - Below average. Consider revisions."
    else:
        return "❌ High risk - Strong negative signals. Significant revision needed."

def suggest_improvements(feature_scores: List[Dict], creative_concept: Dict) -> List[str]:
    """Suggest specific improvements based on missing positive signals"""
    
    improvements = []
    
    # Check for common winning patterns
    has_urgency = any('urgency' in f['feature'] for f in feature_scores if f['score'] > 0)
    has_social_proof = any('social_proof' in f['feature'] for f in feature_scores if f['score'] > 0)
    has_numbers = any('numbers' in f['feature'] for f in feature_scores if f['score'] > 0)
    has_question = any('question' in f['feature'] for f in feature_scores if f['score'] > 0)
    
    if not has_urgency:
        improvements.append("Add urgency element (e.g., 'Today', 'Now', 'Limited Time')")
    
    if not has_social_proof:
        improvements.append("Include social proof (e.g., '10,000+ customers', 'Award-winning', 'Trusted by')")
    
    if not has_numbers:
        improvements.append("Add specific numbers or statistics to increase credibility")
    
    if not has_question and 'headline' in creative_concept:
        improvements.append("Consider using a question in headline to increase engagement")
    
    # Check for negative patterns
    negative_features = [f for f in feature_scores if f['score'] < 0]
    if negative_features:
        improvements.append(f"Remove negative signals: {', '.join(f['feature'] for f in negative_features[:3])}")
    
    return improvements[:5]  # Return top 5 suggestions

def compare_creatives(creative_concepts: List[Dict], historical_patterns: Dict, 
                     benchmarks: Dict, primary_metric: str = 'ctr') -> Dict:
    """Score and compare multiple creative concepts"""
    
    scores = []
    
    for concept in creative_concepts:
        score_result = score_creative(concept, historical_patterns, benchmarks, primary_metric)
        scores.append(score_result)
    
    # Sort by score
    scores.sort(key=lambda x: x['overall_score'], reverse=True)
    
    # Calculate relative performance
    avg_score = sum(s['overall_score'] for s in scores) / len(scores)
    
    for score in scores:
        score['vs_average'] = f"{((score['overall_score'] / avg_score - 1) * 100):+.1f}%"
        score['rank'] = scores.index(score) + 1
    
    return {
        'total_creatives': len(scores),
        'average_score': round(avg_score, 1),
        'scores': scores,
        'winner': scores[0],
        'summary': generate_comparison_summary(scores)
    }

def generate_comparison_summary(scores: List[Dict]) -> str:
    """Generate a summary of the creative comparison"""
    
    winner = scores[0]
    loser = scores[-1]
    
    summary = f"Top performer: Creative {winner['creative_id']} (Score: {winner['overall_score']}) "
    summary += f"is predicted to outperform the lowest-scoring creative by "
    summary += f"{((winner['overall_score'] / loser['overall_score'] - 1) * 100):.0f}%. "
    
    high_confidence_count = sum(1 for s in scores if 'High' in s['confidence'])
    if high_confidence_count > 0:
        summary += f"{high_confidence_count} creative(s) have high confidence predictions."
    
    return summary

def main():
    """Main execution function"""
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python score_creative_concepts.py <analysis_file.json> <creatives_file.json> [primary_metric]")
        print("Example: python score_creative_concepts.py campaigns_analysis.json new_creatives.json ctr")
        sys.exit(1)
    
    analysis_file = sys.argv[1]
    creatives_file = sys.argv[2]
    primary_metric = sys.argv[3] if len(sys.argv) > 3 else 'ctr'
    
    # Load historical patterns
    print(f"Loading historical analysis from {analysis_file}...")
    with open(analysis_file, 'r') as f:
        analysis = json.load(f)
    
    patterns = analysis.get('patterns', {})
    benchmarks = analysis.get('benchmarks', {})
    
    # Load creative concepts
    print(f"Loading creative concepts from {creatives_file}...")
    with open(creatives_file, 'r') as f:
        creatives = json.load(f)
    
    # Handle both single creative and list of creatives
    if isinstance(creatives, dict) and 'creatives' in creatives:
        creatives = creatives['creatives']
    elif isinstance(creatives, dict):
        creatives = [creatives]
    
    print(f"\nScoring {len(creatives)} creative concept(s)...")
    
    # Score and compare
    results = compare_creatives(creatives, patterns, benchmarks, primary_metric)
    
    # Save results
    output_file = creatives_file.replace('.json', '_scores.json')
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nScoring complete! Results saved to: {output_file}")
    print(f"\n{results['summary']}")
    print(f"\n{'='*60}")
    print("Detailed Scores:")
    print(f"{'='*60}")
    
    for score in results['scores']:
        print(f"\n🎯 Creative {score['creative_id']} - Rank #{score['rank']}")
        print(f"   Score: {score['overall_score']}/100 ({score['confidence']})")
        print(f"   Prediction: {score['recommendation']}")
        if score['predictions']:
            for metric, pred in score['predictions'].items():
                print(f"   {metric.upper()}: {pred['predicted_value']:.2%} ({pred['vs_median']} vs median)")
        if score['improvements']:
            print(f"   Improvements:")
            for imp in score['improvements']:
                print(f"     • {imp}")

if __name__ == "__main__":
    main()
