---
name: ad-creative-performance-predictor
description: Score ad creative concepts based on historical performance patterns across all platforms (Google Ads, Meta, LinkedIn, TikTok, etc.). Use when you need to predict which creative concepts will perform best, compare multiple creative options, identify winning creative elements, or optimize creative based on historical campaign data. Works with CSV exports, Google Sheets, and campaign reports analyzing CTR, conversion rate, CPC, engagement rate, and ROAS.
---

# Ad Creative Performance Predictor

Predict creative performance by analyzing historical campaign data to identify winning patterns and score new creative concepts across all ad platforms.

## Quick Start Workflow

### 1. Load Historical Performance Data

**Accepted Data Sources**:
- CSV exports from ad platforms (Google Ads, Meta Ads Manager, LinkedIn Campaign Manager)
- Google Sheets with campaign data
- Excel reports from third-party tools (HubSpot, Salesforce, etc.)

**Required Data Columns** (flexible naming):
- Creative identifier (ad_id, creative_id, ad_name)
- Creative text elements (headline, description, body, ad_copy)
- Performance metrics (at least one): ctr, clicks, impressions, conversion_rate, conversions, cpc, cost, engagement_rate, roas, revenue
- Optional but helpful: date, platform, campaign_name, audience, placement

**Load Data**:
```python
# If user provides CSV file
import pandas as pd
df = pd.read_csv('campaign_data.csv')

# If user provides Google Sheets URL
# Use Google Sheets integration to load data

# If user uploads Excel file
df = pd.read_excel('campaign_report.xlsx')
```

**Data Validation**:
- Check for required columns
- Verify metric columns are numeric
- Handle missing values appropriately
- Confirm date format if present

### 2. Analyze Historical Patterns

Run the pattern extraction script to identify what makes creatives succeed or fail:

```bash
python scripts/analyze_historical_data.py campaign_data.csv ctr
```

**The script will**:
1. Identify top 20% and bottom 20% performers
2. Extract features from creative text (headlines, descriptions, CTAs)
3. Compare feature prevalence in winners vs losers
4. Calculate statistical significance of patterns
5. Generate benchmarks for each metric
6. Apply recency weighting (recent data weighted higher)
7. Output analysis to JSON file

**Output**: `campaign_data_analysis.json` containing:
- Performance benchmarks (mean, median, percentiles)
- Winning patterns (strong positive, moderate positive)
- Losing patterns (negative signals)
- Platform-specific insights
- Actionable recommendations

**Manual Analysis Alternative**:
If the script doesn't fit your needs, manually analyze by:
1. Sorting campaigns by primary metric (descending)
2. Examining top 20% for common elements
3. Examining bottom 20% for anti-patterns
4. Documenting patterns in structured format

### 3. Define Creative Concepts to Score

**Input Format**: Create JSON file with creative concepts following the template in `assets/creative-scoring-template.json`

**Required Fields**:
- `id`: Unique identifier for the creative
- At least one text field: `headline`, `description`, `body`, or `cta`

**Optional Fields** (improve accuracy):
- `platform`: Target platform (Google_Search, LinkedIn, Meta_Feed, etc.)
- `visual_type`: Image/video description (product_shot, lifestyle, animation, ugc)
- `has_people`: Boolean - does creative show people?
- `color_scheme`: Dominant colors (blue_professional, red_urgent, minimalist)
- `offer_type`: Type of offer (free_trial, demo, discount, content)

**Example Creative Concept**:
```json
{
  "id": "Creative_A",
  "headline": "Transform Your B2B Marketing in 30 Days",
  "description": "Get 40% more qualified leads with our proven automation platform. Try free for 14 days.",
  "cta": "Start Free Trial",
  "platform": "LinkedIn",
  "visual_type": "professional_product",
  "has_people": true
}
```

### 4. Score Creative Concepts

Run the scoring script to predict performance:

```bash
python scripts/score_creative_concepts.py campaign_data_analysis.json new_creatives.json ctr
```

**The script will**:
1. Extract features from each creative concept
2. Match features against historical patterns
3. Calculate composite score (0-100)
4. Generate confidence interval
5. Predict specific metrics (CTR, conversion rate, etc.)
6. Rank creatives by predicted performance
7. Suggest improvements for each creative

**Output**: `new_creatives_scores.json` containing:
- Overall score for each creative (0-100)
- Confidence level (High/Medium/Low)
- Ranking (which creative is predicted to win)
- Metric predictions with benchmark comparison
- Feature impact breakdown
- Specific improvement recommendations

### 5. Interpret Results and Take Action

**Score Interpretation**:
- **90-100**: 🚀 Highly likely winner - Scale aggressively
- **75-89**: ✅ Good performer - Standard allocation
- **60-74**: ⚠️ Average performer - Test carefully
- **45-59**: 🔴 Below average - Revise before launch
- **0-44**: ❌ High risk - Significant revision needed

**Confidence Levels**:
- **High (85-95%)**: Strong historical data, clear patterns, proceed with confidence
- **Medium (70-84%)**: Moderate data, some clear patterns, test but watch closely
- **Low (50-69%)**: Limited data or novel approach, recommend A/B test

**Recommended Actions**:
1. **For clear winners**: Allocate 50-60% of budget to test
2. **For good performers**: Standard 20-30% budget allocation
3. **For average performers**: Small 10-15% test budget
4. **For poor performers**: Revise based on improvement suggestions before testing
5. **When confidence is low**: Run structured A/B test with equal budget split

## Advanced Usage

### Multi-Metric Scoring

Score creatives across multiple metrics simultaneously:

```python
# Score for CTR
ctr_results = score_creative(creative, patterns, benchmarks, 'ctr')

# Score for Conversion Rate  
conv_results = score_creative(creative, patterns, benchmarks, 'conversion_rate')

# Score for ROAS
roas_results = score_creative(creative, patterns, benchmarks, 'roas')

# Combine scores based on campaign objective
if objective == 'awareness':
    composite_score = (ctr_results['overall_score'] * 0.6 + 
                      conv_results['overall_score'] * 0.2 +
                      roas_results['overall_score'] * 0.2)
elif objective == 'conversion':
    composite_score = (ctr_results['overall_score'] * 0.2 + 
                      conv_results['overall_score'] * 0.5 +
                      roas_results['overall_score'] * 0.3)
```

### Platform-Specific Scoring

When scoring for a specific platform, review `references/platform-specifics.md` first for:
- Format requirements and constraints
- Platform-specific scoring factors
- Unique creative elements to consider
- Cross-platform compatibility multipliers

Apply platform-specific adjustments:
```python
# Base score
score = calculate_base_score(creative, patterns)

# Apply platform multiplier
if creative['platform'] == 'TikTok' and creative['visual_type'] == 'ugc':
    score += 10  # UGC performs exceptionally well on TikTok
elif creative['platform'] == 'LinkedIn' and 'professional' in creative['tone']:
    score += 5   # Professional tone fits LinkedIn
```

### Comprehensive Element Analysis

For deep-dive analysis, review `references/creative-elements.md` which covers:
- **Text Elements**: Headlines, body copy, CTAs, tone
- **Visual Elements**: Composition, colors, imagery type, video specifics
- **Platform-Specific Elements**: Format compliance, native look
- **Messaging Elements**: Value proposition, audience signals, offers
- **Technical Elements**: Landing page alignment, targeting indicators
- **Competitive Elements**: Market positioning, competitive angles

Use this reference to:
1. Manually audit creatives for missing high-impact elements
2. Build custom scoring logic for specialized campaigns
3. Train team members on creative best practices
4. Create creative briefs for designers/copywriters

### Continuous Learning

After launching scored creatives:

1. **Track Actual Performance**: Collect real campaign data
2. **Compare Predictions vs Reality**: Calculate prediction accuracy
3. **Identify Systematic Errors**: Which patterns were wrong?
4. **Update Pattern Weights**: Adjust scoring for confirmed patterns
5. **Retrain Model**: Re-run analysis with new data included

**Feedback Loop**:
```python
# After campaign runs for 2 weeks
actual_ctr = 0.034
predicted_ctr = 0.029
error = actual_ctr - predicted_ctr

# Update pattern confidence
if error > 0:
    # Creative outperformed - strengthen these patterns
    increase_pattern_weight(creative_features)
else:
    # Creative underperformed - reduce pattern confidence
    decrease_pattern_weight(creative_features)
```

## Detailed Scoring Methodology

For complete understanding of how scores are calculated, see `references/scoring-methodology.md` which explains:
- Historical pattern extraction process
- Feature scoring formula with weights
- Composite score calculation
- Metric-specific prediction methods
- Confidence interval calculation
- Multi-metric composite scoring
- Edge case handling

## Best Practices

### Data Quality
- **Minimum Dataset**: 50+ campaigns for basic patterns, 200+ for high confidence
- **Recency**: Weight last 3 months heavily, include up to 12 months of history
- **Consistency**: Ensure metric definitions are consistent across data
- **Clean Data**: Remove outliers, test campaigns, or paused campaigns

### Creative Testing Strategy
1. **Test winner + 2 alternatives**: Don't put all budget on predicted winner
2. **Equal initial allocation**: Give each creative fair chance in first 3-7 days
3. **Scale winner gradually**: Don't immediately shift 100% to winner
4. **Keep testing**: Even winners fatigue over time (30-90 days)

### Interpretation Caution
- **Scores are predictions, not guarantees**: Real performance varies
- **Context matters**: Audience, timing, budget affect results
- **Novel approaches**: Low scores on innovative creatives don't mean failure
- **Platform differences**: Same creative performs differently across platforms

### When to Override Predictions
- **Brand constraints**: Must use certain messaging/visuals
- **Strategic initiatives**: Testing new positioning or market
- **Competitive response**: Reacting to competitor campaigns
- **Seasonal factors**: Holiday/event-specific creative needs
- **Gut instinct with expertise**: Domain knowledge trumps data with limited history

## Common Workflows

### Workflow 1: New Campaign Launch
1. Export last 6 months of campaign data
2. Run historical analysis (15 min)
3. Creative team develops 5 concepts (2 days)
4. Score all 5 concepts (5 min)
5. Select top 3 for testing (same day)
6. Launch with split budget allocation
7. Monitor for 1 week, scale winner

### Workflow 2: Creative Refresh
1. Identify fatiguing campaigns (declining performance)
2. Analyze what made original creative work
3. Develop variations maintaining winning elements
4. Score variations against updated historical data
5. Launch top scorer alongside original
6. Gradually phase out original if new wins

### Workflow 3: Platform Expansion
1. Analyze performance on current platform(s)
2. Review platform-specifics for target platform
3. Adapt winning creative to new platform format
4. Apply platform compatibility multiplier to score
5. Launch conservative test budget
6. Collect platform-specific learnings for future

### Workflow 4: Competitive Response
1. Analyze competitor creative (screenshot/URL)
2. Extract their creative elements
3. Score their approach against your data
4. Identify why it might work/fail for you
5. Develop counter-creative or adapted version
6. Score your response
7. Launch if score is competitive

## Troubleshooting

**Issue**: "Low confidence on all creatives"
- **Cause**: Limited historical data or novel creative approach
- **Solution**: Run A/B test with equal allocation, use as learning opportunity

**Issue**: "Scores all very similar (60-70 range)"
- **Cause**: Creatives are too similar or data doesn't show strong patterns
- **Solution**: Develop more diverse creative concepts, ensure data includes clear winners/losers

**Issue**: "Prediction was very wrong"
- **Cause**: Historical data not representative, audience changed, or outlier event
- **Solution**: Update patterns with new data, check for external factors (seasonality, competition, platform changes)

**Issue**: "Script errors on data import"
- **Cause**: Column naming mismatch or data type issues
- **Solution**: Standardize column names, ensure metrics are numeric, check date formats

## Output Formats

### Summary Report (Markdown)
```markdown
# Creative Performance Predictions
**Campaign**: Q1 2024 B2B Lead Gen
**Analysis Date**: 2024-01-15
**Historical Data**: 235 campaigns (6 months)

## Rankings
1. **Creative A** - Score: 87/100 (High Confidence)
   - Predicted CTR: 3.2% (+35% vs median)
   - Recommendation: Primary allocation (50% budget)
   
2. **Creative B** - Score: 76/100 (Medium Confidence)
   - Predicted CTR: 2.6% (+10% vs median)
   - Recommendation: Secondary test (30% budget)

## Key Insights
- Headlines with questions performed 40% better
- Social proof increased conversion by 25%
- Urgency language showed in 85% of top performers
```

### Detailed JSON Export
Complete analysis with all scores, feature impacts, and recommendations saved for further processing or dashboard integration.

### Visual Dashboard (Optional)
Create visualizations showing:
- Score comparison bar chart
- Feature impact spider chart
- Confidence vs score scatter plot
- Predicted performance ranges

## Related Skills

- **campaign-strategy-planning**: Develop overall campaign strategy before creative
- **competitive-ads-extractor**: Analyze competitor creative for insights
- **content-engagement-analyzer**: Analyze organic content performance
- **seo-keyword-optimization**: Align ad creative with search intent
