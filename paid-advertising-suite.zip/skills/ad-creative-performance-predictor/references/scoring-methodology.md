# Scoring Methodology

## Overview

The scoring system predicts creative performance by identifying patterns in historical data and matching them against new creative concepts. Scores range from 0-100 with confidence intervals.

## Core Scoring Process

### 1. Historical Pattern Extraction

**Identify winning patterns** from historical data:
- Top 20% performers by primary metric (CTR, conversion rate, etc.)
- Extract common elements across winners
- Calculate statistical significance of each element
- Identify losing patterns from bottom 20% for inverse signals

**Pattern Types**:
- **Strong Positive**: Element present in >70% of top performers, <30% of poor performers
- **Moderate Positive**: Element present in 50-70% of top performers
- **Neutral**: No clear correlation
- **Negative**: Element present in >60% of poor performers

### 2. Feature Scoring

Each creative element receives a score based on:

**Element Score = (Historical Success Rate × Frequency Weight × Recency Factor)**

- **Historical Success Rate**: % of top performers with this element
- **Frequency Weight**: How often element appeared in dataset (higher weight for more data)
- **Recency Factor**: Time-decay multiplier (more recent data weighted higher)

### 3. Composite Score Calculation

**Base Score Components**:
- Text Elements: 35% weight
- Visual Elements: 30% weight  
- Platform Alignment: 15% weight
- Offer/Value Prop: 20% weight

**Formula**:
```
Predicted Score = Σ(Element Score × Category Weight × Element Impact)
```

**Adjustments**:
- **Freshness Bonus**: +5-10 points for novel approaches not in training data
- **Fatigue Penalty**: -5-15 points for overused patterns
- **Platform Penalty**: -10 points for format mismatches
- **Audience Mismatch**: -15 points for wrong targeting signals

### 4. Confidence Intervals

**High Confidence (90-100%)**: 
- >100 similar creatives in historical data
- Clear patterns with >80% success rate
- Recent data (<3 months)

**Medium Confidence (70-89%)**:
- 50-100 similar creatives
- Moderate patterns (60-80% success)
- Data 3-6 months old

**Low Confidence (50-69%)**:
- <50 similar creatives
- Weak patterns (<60% success)
- Older data (>6 months)
- High concept novelty

## Metric-Specific Scoring

### CTR Prediction
**Primary Factors** (80% weight):
- Headline strength and emotional triggers
- Visual hook quality (first impression)
- Ad format and placement
- Relevance to search intent/audience

**Secondary Factors** (20% weight):
- Brand recognition
- Offer clarity
- Social proof indicators

**Benchmark Ranges**:
- Google Search: 3-8% (B2B), 5-12% (B2C)
- Meta Feed: 0.8-2% (B2B), 1.5-3% (B2C)
- LinkedIn: 0.3-1.2% (B2B)
- Display: 0.1-0.5%

### Conversion Rate Prediction
**Primary Factors** (80% weight):
- Landing page message match
- Offer quality and clarity
- Friction level (form fields, steps)
- Trust signals and proof points

**Secondary Factors** (20% weight):
- Ad-to-LP visual continuity
- Target audience precision
- Device optimization

**Benchmark Ranges**:
- B2B Lead Gen: 2-8%
- B2B Demo Request: 1-5%
- B2C E-commerce: 1-4%
- B2C High-Ticket: 0.5-2%

### CPC Prediction
**Primary Factors** (80% weight):
- Quality Score indicators (relevance, expected CTR)
- Competition level for targeting
- Platform and placement
- Audience size and specificity

**Secondary Factors** (20% weight):
- Ad format
- Creative quality
- Historical account performance

**Score Translation**:
- High predicted CPC: 50-70 score
- Medium predicted CPC: 70-85 score  
- Low predicted CPC: 85-100 score

### Engagement Rate Prediction (Social)
**Primary Factors** (80% weight):
- Content value (educational, entertaining, inspiring)
- Visual appeal and stop-scroll factor
- Community resonance (memes, trends, relatability)
- Interactive elements (questions, polls)

**Secondary Factors** (20% weight):
- Post length and readability
- Timing and frequency
- Brand presence (subtle vs prominent)

**Benchmark Ranges**:
- Meta Organic: 1-3%
- Meta Paid: 3-6%
- LinkedIn Organic: 2-5%
- LinkedIn Paid: 0.5-2%

### ROAS Prediction
**Primary Factors** (80% weight):
- Historical conversion rate × predicted AOV
- Customer LTV signals in messaging
- Price positioning and offer structure
- Target audience value indicators

**Secondary Factors** (20% weight):
- Funnel stage alignment
- Upsell/cross-sell signals
- Retention messaging

**Score Calculation**:
```
Predicted ROAS = (Predicted Revenue / Predicted Spend)
Score = min(100, (Predicted ROAS / Target ROAS) × 100)
```

## Multi-Metric Composite

When scoring across multiple metrics:

**Weighted Score**:
```
Composite = (CTR_Score × 0.25) + (Conv_Score × 0.35) + (CPC_Score × 0.20) + (Eng_Score × 0.10) + (ROAS_Score × 0.10)
```

**Adjust weights** based on campaign objective:
- Awareness: CTR 40%, Engagement 30%, CPC 30%
- Consideration: CTR 30%, Engagement 30%, Conv 40%
- Conversion: Conv 50%, ROAS 30%, CPC 20%

## Competitive Comparison

When scoring multiple creatives:

**Relative Scoring**:
1. Score each creative independently (absolute score)
2. Rank creatives by score
3. Calculate relative lift potential
4. Flag high-risk vs safe-bet options

**Output Format**:
- Creative A: 87/100 (High confidence) - Projected winner, +35% vs average
- Creative B: 76/100 (Medium confidence) - Safe performer, +15% vs average
- Creative C: 64/100 (Low confidence) - Risky, potential -10% vs average
- Creative D: 91/100 (Medium confidence) - Top performer, +45% vs average
- Creative E: 58/100 (High confidence) - Likely underperformer, -20% vs average

## Edge Cases & Adjustments

### New Market/Audience
- Reduce confidence by 20 points
- Apply industry benchmarks instead of account history
- Flag as "exploration needed"

### Creative Innovation
- Novel approaches get 60-75 base score (unknown territory)
- Add variance: ±15 points
- Recommend A/B test allocation strategy

### Platform Expansion
- Use cross-platform learnings with 0.7 multiplier
- Apply platform-specific benchmarks
- Flag format-specific risks

### Seasonal/Event-Based
- Identify seasonal patterns in history
- Apply seasonal multipliers (holiday, industry events)
- Adjust benchmarks for known seasonality

## Score Interpretation Guide

**90-100**: Highly likely winner
- Strong pattern match with proven winners
- Multiple positive signals
- No major red flags
- Recommendation: Scale aggressively

**75-89**: Good performer
- Solid fundamentals
- Some strong positive signals
- Minor concerns
- Recommendation: Standard allocation

**60-74**: Average performer  
- Mixed signals
- Some concerns
- May perform at baseline
- Recommendation: Test carefully

**45-59**: Below average
- Weak patterns
- Multiple concerns
- Likely underperformer
- Recommendation: Revise before launch

**0-44**: High risk
- Strong negative signals
- Pattern match with historical losers
- Major red flags
- Recommendation: Significant revision needed

## Continuous Learning

After launch:
1. Track actual vs predicted performance
2. Identify prediction errors
3. Update pattern weights
4. Refine scoring model
5. Feed learnings back into system
