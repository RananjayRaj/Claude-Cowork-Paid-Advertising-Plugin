# Creative Elements Analysis Framework

## Text Elements

### Headlines
- **Length**: Character count, word count
- **Structure**: Question vs statement vs command
- **Emotional Triggers**: Urgency, curiosity, fear, aspiration, social proof
- **Numbers**: Presence of statistics, percentages, dollar amounts
- **Power Words**: Action verbs, sensory words, emotional triggers
- **Personalization**: Use of "you", "your", first/second person
- **Brackets/Parentheses**: Presence and positioning
- **Capitalization**: ALL CAPS words, Title Case vs Sentence case

### Body Copy
- **Length**: Short (<50 chars), Medium (50-150), Long (>150)
- **Readability**: Flesch-Kincaid score, sentence complexity
- **Feature vs Benefit**: Ratio of features mentioned vs benefits
- **Pain Points**: Direct mention of problems/challenges
- **Social Proof**: Testimonials, client names, statistics
- **Scarcity/Urgency**: Time-limited offers, limited availability
- **Storytelling**: Narrative structure vs direct pitch

### Call-to-Action (CTA)
- **Type**: Learn More, Sign Up, Get Started, Download, Request Demo, Buy Now, Try Free
- **Urgency**: Now, Today, Limited Time, Don't Miss
- **Value Proposition**: What user gets (Free, Save, Discover)
- **Friction**: High (Buy, Purchase) vs Low (Learn, Explore)
- **Action Verb**: Strong action words vs passive
- **Length**: 1-2 words vs 3-5 words vs longer

### Tone & Voice
- **Formality**: Professional, Casual, Conversational, Technical
- **Emotion**: Serious, Playful, Inspirational, Authoritative
- **Perspective**: First person (We), Second person (You), Third person
- **Confidence Level**: Guaranteed, Proven, May, Could, Possibly

## Visual Elements (Image/Video Ads)

### Composition
- **Subject Placement**: Rule of thirds, center-focused, asymmetric
- **Human Presence**: People count, faces visible, eye contact
- **Product Visibility**: Clear product shot vs contextual use vs abstract
- **Text Overlay**: Amount, placement, readability
- **White Space**: Cluttered vs minimalist
- **Orientation**: Square, Landscape, Portrait, Vertical (9:16)

### Color Psychology
- **Dominant Colors**: Red (urgency), Blue (trust), Green (growth), Yellow (optimism)
- **Color Saturation**: Vibrant vs muted vs monochrome
- **Contrast Ratio**: High contrast vs subtle
- **Brand Consistency**: On-brand colors vs experimental

### Visual Hierarchy
- **Focal Point**: Clear vs ambiguous
- **Visual Flow**: Top-to-bottom, left-to-right, circular
- **Size Hierarchy**: Clear primary/secondary elements
- **Layering**: Depth and dimension vs flat design

### Imagery Type
- **Photography**: Stock vs custom, lifestyle vs product-focused
- **Illustration**: Abstract, icons, hand-drawn, vector
- **Screenshots**: Product UI, data visualization, testimonials
- **Video**: Animation style, live-action, screen recording, UGC
- **Memes/Trends**: Recognizable formats, viral templates

### Video-Specific Elements
- **Duration**: <6s, 6-15s, 15-30s, 30-60s, >60s
- **Hook Strength**: First 3 seconds engagement potential
- **Captions**: Presence, style, burned-in vs dynamic
- **Sound Design**: Music genre, voiceover presence, sound effects
- **Editing Pace**: Cuts per second, transitions, motion graphics
- **Format**: Talking head, B-roll, animation, mixed media

## Platform-Specific Elements

### Google Ads (Search/Display)
- **Headline Variations**: Number of headlines, variety in messaging
- **Description Variations**: Number of descriptions
- **Extensions Used**: Sitelink, callout, structured snippet, price
- **URL Display Path**: Keyword relevance, clarity
- **Responsive vs Static**: Flexibility in asset combinations

### Meta (Facebook/Instagram)
- **Post Type**: Single image, carousel, video, collection
- **Carousel Elements**: Number of cards, story flow
- **Format Compliance**: Feed, Story, Reel specifications
- **Interactive Elements**: Polls, questions, AR effects
- **UGC Elements**: Authentic content style, testimonial format

### LinkedIn
- **Professional Tone**: Industry language, corporate vs casual
- **B2B Signals**: Role mentions, company size, industry terms
- **Thought Leadership**: Insights, data, trends
- **Lead Gen Form**: Pre-filled vs custom fields
- **Document Ads**: PDF previews, SlideShare style

### Display/Programmatic
- **Animation**: Static vs animated, subtle vs dynamic
- **Size Compliance**: IAB standard sizes (300x250, 728x90, etc.)
- **File Weight**: Loading speed optimization
- **Brand Safety**: Clear brand presence, professional design

## Messaging Elements

### Value Proposition
- **Specificity**: Vague vs precise benefits
- **Quantification**: Percentage improvements, time savings, cost reduction
- **Differentiation**: Unique vs generic claims
- **Proof Points**: Awards, certifications, research data

### Target Audience Signals
- **Role/Title**: Decision-maker language vs end-user
- **Industry**: Vertical-specific terminology
- **Pain Point**: Explicitly named challenge
- **Stage**: Awareness vs consideration vs decision

### Offer Type
- **Free Trial**: Duration, credit card required or not
- **Discount**: Percentage vs dollar amount vs BOGO
- **Demo/Consultation**: Live demo, recorded demo, consultation
- **Content**: Whitepaper, ebook, webinar, case study, template
- **Product Access**: Freemium, free tier, limited features

## Technical Elements

### Landing Page Alignment
- **Message Match**: Headline consistency
- **Visual Continuity**: Design consistency
- **Friction Points**: Form fields, navigation clarity

### Targeting Indicators
- **Audience**: Cold vs warm vs retargeting
- **Placement**: Platform/position performance
- **Device**: Mobile-optimized vs desktop-first
- **Time**: Day-parting, seasonal relevance

## Competitive Elements

### Market Position
- **Price Positioning**: Premium vs budget vs value
- **Feature Focus**: Innovation vs reliability vs simplicity
- **Brand Recognition**: Established vs challenger vs new entrant

### Competitive Angle
- **Direct Comparison**: Named competitors vs implied
- **Alternative Framing**: "Instead of X" messaging
- **Category Creation**: New solution category vs existing

## Testing History Signals

### Creative Iteration
- **Variation Type**: Major reframe vs minor tweak
- **Test Lineage**: Connection to previous winners/losers
- **Concept Freshness**: New angle vs proven formula

### Historical Patterns
- **Seasonality**: Time of year performance
- **Audience Fatigue**: Declining performance over time
- **Format Effectiveness**: Platform-specific format success
