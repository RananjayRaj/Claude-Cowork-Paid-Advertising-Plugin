# Platform-Specific Considerations

## Google Ads

### Search Ads (Text)
**Format Requirements**:
- 3 headlines (30 chars each)
- 2 descriptions (90 chars each)
- Display path (15 chars each)

**Scoring Focus**:
- Keyword relevance in headlines (Quality Score factor)
- Ad rank predictors: CTR history, relevance, landing page
- Extension utilization impact
- Mobile vs desktop performance split

**Unique Elements**:
- Dynamic keyword insertion patterns
- Match type alignment (broad, phrase, exact)
- Search intent matching (informational, navigational, transactional)
- Competitor keyword performance

**Historical Patterns to Extract**:
- High-QS ad characteristics
- Extension combinations that drive CTR
- Headline position performance (H1 vs H2 vs H3)
- Description message strategies

### Display/GDN
**Format Requirements**:
- Multiple sizes (300x250, 728x90, 160x600, 320x50, 336x280)
- Responsive display ads (images + text)
- 15-second video cap for bumper ads

**Scoring Focus**:
- Visual attention capture in <2 seconds
- Brand presence without overwhelming
- Contextual relevance to placement
- Frequency/reach optimization

**Unique Elements**:
- Responsive vs static performance
- Image prominence vs text-heavy
- Animation impact on CTR
- Placement network performance (YouTube, Gmail, Discovery)

### Performance Max
**Format Requirements**:
- 5 headlines (30 chars)
- 5 descriptions (90 chars)
- Up to 20 images (various ratios)
- Up to 5 videos

**Scoring Focus**:
- Asset diversity and quality
- Cross-channel potential (Search, Display, YouTube, Gmail)
- Automated optimization signals

**Unique Elements**:
- Asset group strategy
- Final URL expansion potential
- Audience signal strength

### YouTube Ads
**Format Requirements**:
- Skippable (12s+ or 6s bumper)
- Non-skippable (15-20s)
- In-feed discovery ads

**Scoring Focus**:
- 5-second hook strength (pre-skip decision)
- Sound-off viewing experience
- Brand integration timing
- CTA timing and prominence

## Meta (Facebook/Instagram)

### Feed Ads
**Format Requirements**:
- Text: 125 chars (truncates after)
- Headline: 27 chars
- Description: 27 chars
- Image: 1.91:1 or 1:1 ratio

**Scoring Focus**:
- Scroll-stopping visual
- Relevance score predictors
- Engagement potential (reactions, comments, shares)
- Native content look vs branded ad

**Unique Elements**:
- Engagement bait avoidance (don't ask for likes/tags)
- 20% text rule (legacy, now recommendation)
- Social proof integration (page likes, mutual friends)
- Multi-product ad layouts

### Stories/Reels
**Format Requirements**:
- 9:16 vertical format
- 15 seconds max (Stories)
- Up to 90 seconds (Reels)
- Safe zones for UI elements

**Scoring Focus**:
- Instant hook (no context needed)
- Full-screen immersion
- Sound-on vs sound-off design
- Interactive elements (polls, sliders, questions)

**Unique Elements**:
- Swipe-up CTA effectiveness
- AR filter integration
- UGC aesthetic performance
- Trending audio usage

### Carousel Ads
**Format Requirements**:
- 2-10 cards
- 1:1 ratio images
- Separate headlines/links per card

**Scoring Focus**:
- Story flow across cards
- Card completion rate
- Click position (which card performs)
- Product showcase vs storytelling approach

### Advantage+ Shopping
**Format Requirements**:
- Automated creative combinations
- Up to 50 images/videos per ad

**Scoring Focus**:
- Catalog product highlight strategies
- Dynamic product ads performance patterns
- Price display vs hidden pricing
- Urgency indicators (stock levels, sales)

## LinkedIn

### Sponsored Content
**Format Requirements**:
- Intro text: 150 chars visible (600 max)
- Headline: 200 chars
- Description: 300 chars (desktop only)
- Image: 1.91:1 ratio

**Scoring Focus**:
- Professional tone vs conversational
- Value proposition for business audience
- Thought leadership signals
- Decision-maker language

**Unique Elements**:
- Company page engagement history
- Member seniority/title performance
- Industry-specific messaging
- B2B buying cycle stage

### Message Ads (InMail)
**Format Requirements**:
- Subject: 60 chars
- Body: 1,500 chars
- CTA button text: 20 chars

**Scoring Focus**:
- Personalization indicators
- Value exchange clarity
- Sender credibility signals
- Send time optimization

### Lead Gen Forms
**Format Requirements**:
- Pre-filled fields from profile
- Custom questions (up to 12)
- Thank you message customization

**Scoring Focus**:
- Form field count impact on conversion
- Question relevance and friction
- Asset value perception (what they get)
- Follow-up promise clarity

### Video Ads
**Format Requirements**:
- 3 seconds to 30 minutes
- Square (1:1) or vertical (9:16)
- Captions required (85% watch without sound)

**Scoring Focus**:
- Professional production value vs authentic
- Speaker credibility
- Data/insights presentation
- Length vs completion rate

## TikTok

### In-Feed Ads
**Format Requirements**:
- 9:16 vertical video
- 5-60 seconds (optimal: 21-34s)
- Sound-on default viewing

**Scoring Focus**:
- Trend alignment
- Native content mimicry
- Creator-style authenticity
- Music/audio hook

**Unique Elements**:
- Hashtag challenge integration
- Duet/stitch format leverage
- Effect/filter usage
- Jump cut pacing

## Twitter/X

### Promoted Tweets
**Format Requirements**:
- 280 characters text
- Image: 1200x675px
- Video: up to 2:20

**Scoring Focus**:
- Reply/quote tweet potential
- Conversational tone
- Timely/topical relevance
- Thread engagement likelihood

**Unique Elements**:
- News-jacking opportunities
- Community note risk
- Brand voice authenticity
- Controversial topic navigation

## Pinterest

### Promoted Pins
**Format Requirements**:
- Vertical format (2:3 ratio optimal)
- Title: 100 chars
- Description: 500 chars

**Scoring Focus**:
- Visual inspiration quality
- Save-ability (pin-worthy)
- Search keyword optimization
- Seasonal/occasion alignment

**Unique Elements**:
- Shopping intent signals
- DIY/tutorial value
- Aspirational aesthetic
- Collection/board placement

## Reddit

### Promoted Posts
**Format Requirements**:
- Title: 300 chars
- Body: text or image/video
- Subreddit targeting

**Scoring Focus**:
- Community relevance
- Non-promotional tone
- Genuine value provision
- Upvote potential

**Unique Elements**:
- Subreddit culture alignment
- AMA-style engagement
- Downvote risk mitigation
- Comment strategy

## Snapchat

### Snap Ads
**Format Requirements**:
- 9:16 vertical video
- 3-180 seconds
- Instant Experience attachments

**Scoring Focus**:
- Youth culture relevance
- AR lens integration
- Sound-on creative design
- Swipe-up action clarity

## Platform Migration Patterns

### Cross-Platform Learnings
**What Transfers Well** (0.8-1.0 multiplier):
- Strong value propositions
- Compelling visuals
- Clear CTAs
- Social proof elements

**What Needs Adaptation** (0.4-0.6 multiplier):
- Tone and formality
- Creative length
- Visual style
- CTA language

**What Doesn't Transfer** (0.1-0.3 multiplier):
- Platform-specific formats
- Native vs polished aesthetic
- Engagement mechanics
- Trending formats

### Expansion Priority Framework
When expanding to new platform, score based on:
1. Audience overlap (50% weight)
2. Creative format compatibility (30% weight)
3. Performance objective alignment (20% weight)

**Example**: B2B SaaS performing well on LinkedIn
- Google Search: 0.85 compatibility (similar audience, professional intent)
- Meta Feed: 0.60 compatibility (broader audience, needs different creative approach)
- TikTok: 0.30 compatibility (very different audience and creative requirements)
