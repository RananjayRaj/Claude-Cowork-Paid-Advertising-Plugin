---
name: creative-testing-framework
description: Design creative A/B test matrices with hypothesis, metrics, and statistical rigor. Use when planning creative tests for ads, landing pages, emails, or UI elements. Key features include test design (matrices, variants, comparisons), hypothesis framework (structure, rationale, confidence levels), variable isolation (single vs multivariate), success criteria (metrics, statistical significance, sample sizes), and methodology-agnostic approach. For agencies managing multiple clients or teams running optimization programs.
---

# Creative Testing Framework

Systematic framework for designing, executing, and analyzing creative A/B tests across all channels with statistical rigor.

## Quick Start

To design a creative test, provide:
1. **What you're testing** - Ad creative, landing page, email, etc.
2. **Your hypothesis** - What you expect to happen and why
3. **Your goal** - What metric you want to improve
4. **Your context** - Traffic volume, current performance, timeline

Example: "I want to test lifestyle images vs product shots in Facebook ads. I think lifestyle will increase CTR because our audience research shows they respond to aspirational content. Current CTR is 2.1% and we get 10,000 impressions per day."

## Core Test Design Process

### 1. Formulate Hypothesis

Create a testable hypothesis using this structure:

**Formula:** If we [CHANGE] for [AUDIENCE], then [METRIC] will [DIRECTION] by [AMOUNT]% because [RATIONALE].

**Example:** "If we use lifestyle imagery instead of product shots for millennial women (25-34), then click-through rate will increase by 15-25% because customer research shows this segment responds to aspirational, context-rich visuals."

**Hypothesis strength indicators:**
- Backed by data or research
- Specific audience identified
- Single variable being tested
- Measurable outcome defined
- Clear rationale provided

For detailed hypothesis frameworks, formulas, and examples across all creative types, see `references/hypothesis-framework.md`.

### 2. Design Test Matrix

Structure your test to ensure proper comparison and variable isolation.

**Basic A/B Test (2 variants):**
```
┌─────────┬────────────────┬──────────────┐
│ Variant │ Variable       │ Expected CTR │
├─────────┼────────────────┼──────────────┤
│ A       │ Product image  │ 2.1% (base)  │
│ B       │ Lifestyle image│ 2.7% (+28%)  │
└─────────┴────────────────┴──────────────┘
```

**A/B/C Test (3 variants):**
Test multiple approaches to same variable.

**Multivariate Test (2x2):**
Test combinations of 2 variables simultaneously.

For complete test matrix templates, channel-specific structures, and multivariate designs, see `references/test-design-templates.md`.

### 3. Isolate Variables

**Golden rule:** Test one variable at a time (unless intentionally doing multivariate).

**Good isolation:**
- Control: Product image + "Learn More" + Current copy
- Variant: Lifestyle image + "Learn More" + Current copy
- Only the image changed

**Bad isolation (multiple variables):**
- Control: Product image + "Learn More" + Long copy
- Variant: Lifestyle image + "Get Started" + Short copy
- Can't tell what caused the difference!

For variable isolation techniques, common mistakes, and troubleshooting, see `references/variable-isolation.md`.

### 4. Define Success Criteria

Specify exactly what success looks like before running the test.

**Primary metric:** Main goal (CTR, conversion rate, revenue)
**Secondary metrics:** Supporting indicators
**Guardrail metrics:** Things that shouldn't get worse
**Minimum detectable effect:** Smallest lift worth detecting (usually 5-10%)
**Statistical significance:** 95% confidence (p < 0.05)
**Sample size:** Number needed for reliable results

**Quick estimation:**
- Low baseline (1-2%): Need 10,000-50,000+ per variant
- Medium baseline (5-10%): Need 3,000-15,000 per variant
- High baseline (20%+): Need 1,000-5,000 per variant

For detailed statistical calculations, sample size tables, and significance testing, see `references/statistical-methods.md`.

### 5. Document Test Plan

Use the comprehensive test brief template to document all aspects of your test before launch.

The template is located at `assets/test-brief-template.md` and includes:
- Executive summary
- Hypothesis with supporting evidence
- Test matrix and variants
- Success criteria and statistical plan
- Technical implementation checklist
- Risk assessment
- Results and analysis sections
- Learning documentation

Copy this template for each test to maintain consistency across your testing program.

## Test Design Decision Tree

**Start here:** What are you testing?

### → Single Variable (A/B Test)
**When:** Testing one element (image, headline, CTA, etc.)
**Traffic needed:** Moderate (1,000-10,000 conversions per variant)
**Analysis:** Simple comparison
**Best for:** Most tests, especially early optimization

**Design approach:**
1. Define the single variable changing
2. Keep everything else identical
3. Create 2-3 variants max
4. Calculate sample size needed
5. Set test duration (minimum 1 week)

### → Multiple Variables (Multivariate Test)
**When:** Testing element combinations or interaction effects
**Traffic needed:** High (2,000-5,000 conversions per combination)
**Analysis:** Complex, evaluates combinations
**Best for:** High-traffic sites, mature programs

**Design approach:**
1. Identify 2-3 variables to test
2. Create all combinations (2x2 = 4 variants, 3x2 = 6 variants)
3. Ensure sufficient traffic for all combinations
4. Plan analysis for main effects and interactions
5. Set extended test duration

### → Sequential Tests
**When:** Multiple hypotheses, limited traffic
**Traffic needed:** Moderate per test
**Analysis:** Simple but takes longer
**Best for:** Low-medium traffic sites, learning programs

**Design approach:**
1. Prioritize tests by impact × confidence
2. Run tests sequentially (not simultaneously)
3. Each test builds on previous winners
4. Document cumulative learnings
5. Measure holistic program impact with holdout group

## Common Test Scenarios

### Testing Ad Creative
**Typical variables:** Image type, headline angle, value proposition, CTA
**Key metrics:** CTR, CPC, conversion rate, CPA
**Isolation concerns:** Keep audience, placement, landing page constant
**Sample approach:** A/B test image type first, then iterate on winner

### Testing Landing Pages
**Typical variables:** Hero copy, value props, social proof, CTA placement
**Key metrics:** Conversion rate, bounce rate, time on page
**Isolation concerns:** Ensure consistent traffic sources, load times
**Sample approach:** Test major elements (hero) before minor elements (button color)

### Testing Email Campaigns
**Typical variables:** Subject lines, preview text, layout, CTA
**Key metrics:** Open rate, click rate, conversion rate
**Isolation concerns:** Same send time, same segment, same from name
**Sample approach:** Test subject line first (affects open), then content (affects click)

### Testing UI Elements
**Typical variables:** Button copy, form length, navigation, layout
**Key metrics:** Conversion rate, task completion, user engagement
**Isolation concerns:** Technical implementation, device consistency
**Sample approach:** Progressive testing (high-impact to low-impact)

## Statistical Requirements

### Sample Size Calculation

**For conversion rate tests:**
```
Required per variant ≈ 16 × p × (1-p) / (MDE)²

Where:
- p = baseline conversion rate
- MDE = minimum detectable effect (as decimal)
```

**Example:**
```
Baseline: 5%
MDE: 20% relative (1 percentage point absolute)
n ≈ 16 × 0.05 × 0.95 / (0.01)² = 7,600 per variant
```

### Test Duration

**Minimum:** 1 week (capture weekly patterns)
**Ideal:** 2 weeks (full business cycles)
**Maximum:** 4 weeks (if not significant, effect too small)

**Formula:**
```
Days = (Sample size × variants) / daily traffic
```

### Significance Testing

**Standard threshold:** p < 0.05 (95% confidence)
**Interpretation:** Less than 5% chance result is due to random variation

**When to use higher threshold:**
- Critical changes: 99% confidence (p < 0.01)
- Early exploration: 90% confidence (p < 0.10)

## Agency Best Practices

### Multi-Client Management

**Standardization:**
- Use consistent test brief template
- Apply same statistical standards
- Document all tests in central repository
- Share learnings across clients where relevant

**Client-Specific Adaptation:**
- Different traffic levels → adjust test complexity
- Different goals → customize success criteria
- Different verticals → apply industry benchmarks
- Different risk tolerance → adjust confidence thresholds

### Testing Program Structure

**Prioritization framework:**
- High impact + High confidence → Test first
- High impact + Low confidence → Test second
- Low impact + High confidence → Test third
- Low impact + Low confidence → Skip or defer

**Quarterly planning:**
- Set testing roadmap by channel
- Allocate budget across test types
- Plan sequential dependencies
- Track cumulative program impact

**Learning documentation:**
- Document all tests (winners and losers)
- Extract transferable insights
- Build hypothesis library
- Create industry-specific playbooks

## Reference Files

This skill includes comprehensive reference documentation for deep dives:

**`references/hypothesis-framework.md`** (12,000+ words)
- Hypothesis structure and formulas
- Examples by creative type (ads, landing pages, emails, UI)
- Common mistakes and how to avoid them
- Hypothesis categories and strength assessment
- Documentation templates

**`references/test-design-templates.md`** (10,000+ words)
- Test matrix fundamentals (A/B, A/B/C, multivariate)
- Channel-specific test structures (Facebook, Google, landing pages, email)
- Sequential testing strategy
- Holdout group methodology
- Complete test design checklist

**`references/statistical-methods.md`** (11,000+ words)
- Core statistical concepts (significance, power, MDE)
- Sample size calculations with tables
- Significance testing formulas
- Effect size calculations
- Common statistical mistakes
- Results reporting template

**`references/variable-isolation.md`** (9,000+ words)
- Variable isolation techniques
- Common isolation mistakes
- Sequential vs multivariate testing
- Controlling for external variables
- Isolation checklist by channel
- Troubleshooting guide

## Assets

**`assets/test-brief-template.md`**
Comprehensive test documentation template covering:
- Executive summary and business impact
- Hypothesis with supporting evidence
- Test matrix and variant specifications
- Success criteria and statistical plan
- Technical implementation checklist
- Risk assessment and rollback plan
- Results and analysis documentation
- Learning capture and next steps

Copy this template for each test to maintain consistency and completeness.

## Example Workflow

**Request:** "I want to test different headlines on my SaaS landing page. Current conversion rate is 8% with about 5,000 visitors per month. I think a benefit-focused headline will outperform our current feature-focused headline."

**Response:**

**1. Hypothesis**
"If we use a benefit-focused headline instead of feature-focused for SaaS buyers, then conversion rate will increase by 15-25% because buyer interviews show that 73% prioritize business outcomes over specific features."

**2. Test Matrix**
```
┌─────────┬────────────────────────┬──────────────┐
│ Variant │ Headline               │ Expected CVR │
├─────────┼────────────────────────┼──────────────┤
│ A       │ "Powerful Project Mgmt"│ 8.0% (base)  │
│ B       │ "Save 10 Hours/Week"   │ 9.6% (+20%)  │
└─────────┴────────────────────────┴──────────────┘
```

**3. Statistical Plan**
- Sample needed: ~3,200 per variant (6,400 total)
- Test duration: ~43 days at 5,000/month
- Significance: 95% confidence (p < 0.05)
- MDE: 15% relative lift minimum

**4. Variable Isolation**
- Only changing: Headline text
- Keeping constant: Layout, CTA, images, copy, navigation
- Traffic source: All sources included randomly

**5. Success Criteria**
- Primary: Conversion rate increase >15%
- Secondary: Time on page, scroll depth
- Guardrail: Bounce rate stays within 10% of baseline

**6. Next Steps**
- Copy test brief template from `assets/test-brief-template.md`
- Set up test in your platform
- Run QA on both variants
- Monitor for 1 week minimum
- Analyze results with statistical significance calculator

Would you like me to:
- Create a detailed test brief for this scenario?
- Calculate exact sample sizes for different MDEs?
- Design a follow-up test based on these results?
- Provide statistical analysis formulas?
