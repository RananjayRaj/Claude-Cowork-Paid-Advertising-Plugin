# Creative A/B Test Brief Template

**Test ID:** [Unique identifier, e.g., TEST-001]
**Test Name:** [Descriptive name, e.g., "Homepage Hero Image: Product vs Lifestyle"]
**Owner:** [Team member responsible]
**Stakeholders:** [Other team members who should be informed]
**Created:** [Date]
**Status:** [Planning | In Progress | Complete | Paused | Cancelled]

---

## Executive Summary

**One-sentence description:**
[What are you testing and why? E.g., "Testing lifestyle imagery vs product shots in Facebook ads to increase CTR among millennial women."]

**Expected outcome:**
[What do you expect to happen? E.g., "Lifestyle imagery will increase CTR by 15-25%."]

**Business impact if successful:**
[Why does this matter? E.g., "20% CTR improvement = $50K additional monthly revenue at current spend levels."]

---

## Hypothesis

**Hypothesis statement:**
If we [CHANGE] for [AUDIENCE], then [METRIC] will [INCREASE/DECREASE] by [AMOUNT]% because [RATIONALE].

**Example:**
"If we use lifestyle imagery instead of product shots for millennial women (25-34), then click-through rate will increase by 15-25% because customer research shows this segment responds to aspirational, context-rich visuals that demonstrate lifestyle benefits over product features."

**Confidence level:** [High | Medium | Low]
- High (70-90%): Backed by strong data/research
- Medium (40-70%): Logical with some supporting evidence
- Low (10-40%): Exploratory/learning-focused

**Supporting evidence:**
- [Data point or research finding 1]
- [Data point or research finding 2]
- [Data point or research finding 3]

---

## Test Details

### Test Type
[Select one or more:]
- [ ] A/B Test (single variable, 2 variants)
- [ ] A/B/C Test (single variable, 3+ variants)
- [ ] Multivariate Test (multiple variables, all combinations)
- [ ] Sequential Test (part of series)

### Channel/Platform
[Where is this test running?]
- Platform: [Facebook | Google Ads | Landing Page | Email | etc.]
- Specific location: [Campaign name, page URL, email campaign name]

### Target Audience
**Primary audience:**
- Demographics: [Age, gender, location, etc.]
- Behaviors: [Past actions, purchase history, engagement level]
- Segment size: [Approximate number of people]

**Exclusions:**
- [Any audiences to exclude]

**Audience split:**
- [ ] Even split (50/50)
- [ ] Custom split: [Specify %]
- [ ] Winner allocation (gradually shift traffic)

---

## Test Matrix

### Variables Being Tested

**Independent variable(s):**
[What you're changing]
- Variable 1: [Name and description]
- Variable 2: [If multivariate]

**Dependent variable(s):**
[What you're measuring]
- Primary metric: [Main success metric]
- Secondary metrics: [Supporting metrics]

### Test Variants

**Control (Variant A):**
- Description: [Current/baseline version]
- Variable values: [Specific settings]
- Screenshot/Mock: [Link or attachment]

**Variant B:**
- Description: [What's different]
- Variable values: [Specific settings]
- Screenshot/Mock: [Link or attachment]

**Variant C:** [If applicable]
- Description: [What's different]
- Variable values: [Specific settings]
- Screenshot/Mock: [Link or attachment]

### Visual Test Matrix

```
┌─────────┬─────────────┬─────────────┬──────────────┬──────────────┐
│ Variant │ [Variable 1]│ [Variable 2]│ Expected [M] │ Notes        │
├─────────┼─────────────┼─────────────┼──────────────┼──────────────┤
│ A       │ [Value]     │ [Value]     │ [X]%         │ Control      │
│ B       │ [Value]     │ [Value]     │ [Y]%         │ Test version │
└─────────┴─────────────┴─────────────┴──────────────┴──────────────┘
```

---

## Success Criteria

### Primary Metric
**Metric:** [e.g., Click-through rate, Conversion rate, Revenue per visitor]
**Current baseline:** [X]%
**Target improvement:** [Y]% (relative lift)
**Minimum detectable effect (MDE):** [Z]%
**Success threshold:** [Minimum lift to consider implementing]

### Secondary Metrics
**Metric 1:** [Name]
- Baseline: [X]%
- Expected change: [Direction and magnitude]

**Metric 2:** [Name]
- Baseline: [X]%
- Expected change: [Direction and magnitude]

### Guardrail Metrics
[Metrics that shouldn't get worse]
- [Metric]: Maximum acceptable decrease: [X]%
- [Metric]: Maximum acceptable decrease: [X]%

---

## Statistical Plan

### Sample Size Requirements

**Calculation inputs:**
- Baseline conversion rate: [X]%
- Minimum detectable effect: [Y]% relative
- Statistical significance: 95% (α = 0.05)
- Statistical power: 80% (β = 0.20)

**Required sample size:**
- Per variant: [N] visitors/impressions
- Total: [N × number of variants]

### Test Duration

**Traffic estimate:**
- Daily traffic: [N] visitors/impressions
- Expected test duration: [X] days/weeks

**Timeline:**
- Start date: [Date]
- Expected end date: [Date]
- Latest end date: [Date] (maximum test duration)

**Minimum duration:** [X] days
[Justification: Must capture weekly cycles, business cycles, etc.]

### Analysis Plan

**When to check results:**
- Checkpoint 1: [After X days/samples]
- Checkpoint 2: [After X days/samples]
- Final analysis: [At planned sample size]

**Stopping rules:**
- Early winner: [Criteria for stopping early, if any]
- No winner: Stop after [X] weeks if not significant
- Negative result: Stop immediately if significant harm detected

---

## Segment Analysis Plan

**Pre-planned segments to analyze:**
(Don't wait to find these after the test)

**By device:**
- [ ] Desktop
- [ ] Mobile
- [ ] Tablet

**By traffic source:**
- [ ] Paid (specify: Facebook, Google, etc.)
- [ ] Organic
- [ ] Direct
- [ ] Email
- [ ] Social

**By user type:**
- [ ] New visitors
- [ ] Returning visitors
- [ ] Logged in users
- [ ] Logged out users

**By demographics:** [If available]
- [ ] Age groups
- [ ] Gender
- [ ] Geography

**Custom segments:**
- [Segment 1 description]
- [Segment 2 description]

---

## Technical Implementation

### Platform/Tool
- Testing platform: [Optimizely, VWO, Google Optimize, Custom, etc.]
- Analytics platform: [Google Analytics, Adobe, Mixpanel, etc.]

### Setup Checklist
- [ ] Test created in platform
- [ ] Traffic split configured
- [ ] Targeting/audience set correctly
- [ ] All variants load correctly
- [ ] Mobile rendering verified
- [ ] Tracking pixels/events implemented
- [ ] Goal/conversion events verified
- [ ] Baseline data collected
- [ ] QA completed on all variants
- [ ] Cross-browser testing completed
- [ ] Load time comparable across variants

### Technical Specifications
**Page load requirements:**
- All variants must load in < [X] seconds
- Core Web Vitals: [Requirements]

**Browser support:**
- [List required browsers and versions]

**Device support:**
- [List required devices]

---

## Risk Assessment

### Brand Risk
**Level:** [Low | Medium | High]
**Details:** [How might this affect brand perception?]
**Mitigation:** [How to reduce risk?]

### Technical Risk
**Level:** [Low | Medium | High]
**Details:** [What could break? Any dependencies?]
**Mitigation:** [Backup plan? Rollback process?]

### Revenue Risk
**Level:** [Low | Medium | High]
**Details:** [Downside if variant loses?]
**Mitigation:** [Traffic allocation? Monitoring plan?]

### Rollback Plan
**Trigger conditions:**
- [Condition 1: e.g., >10% drop in conversion rate]
- [Condition 2: e.g., Critical bug discovered]

**Rollback process:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Responsible party:** [Name]

---

## Learning Objectives

**Primary learning goal:**
[What's the main thing we want to learn? E.g., "Do lifestyle images resonate better than product shots with our target audience?"]

**Secondary learning goals:**
[What else do we hope to learn?]
- [Learning goal 1]
- [Learning goal 2]

**Future test ideas this could spawn:**
- [If variant B wins: Next test idea]
- [If control wins: Alternative test idea]

---

## Resource Requirements

### Time Investment
- Design/creative: [X hours]
- Development: [X hours]
- QA/testing: [X hours]
- Analysis: [X hours]
- Total: [X hours]

### Budget
- Creative production: $[X]
- Ad spend (if applicable): $[X]
- Platform costs: $[X]
- Total: $[X]

### Team Members
- Test designer: [Name]
- Creative: [Name]
- Developer: [Name]
- Analyst: [Name]
- Approver: [Name]

---

## Communication Plan

### Pre-Launch
- [ ] Stakeholder buy-in obtained
- [ ] Team briefed on test
- [ ] Support team informed (if customer-facing)

### During Test
**Update frequency:** [Weekly | At checkpoints | As needed]
**Update format:** [Slack, email, dashboard]
**Recipients:** [List]

### Post-Test
- [ ] Results shared with stakeholders
- [ ] Learning documented
- [ ] Implementation plan created (if winner)
- [ ] Next test planned

---

## Results & Analysis

[Complete this section after test concludes]

### Test Outcome
**Winner:** [Variant A | Variant B | No winner | Inconclusive]
**Statistical significance:** [Yes/No] (p = [value])
**Effect size:** [X]% relative lift ([X] percentage points absolute)

### Final Results

```
┌─────────┬───────────┬─────────────┬──────────┬─────────┬───────────┐
│ Variant │ Visitors  │ Conversions │ CVR      │ Lift    │ Sig?      │
├─────────┼───────────┼─────────────┼──────────┼─────────┼───────────┤
│ A       │ [N]       │ [N]         │ [X]%     │ Base    │ -         │
│ B       │ [N]       │ [N]         │ [X]%     │ [+X]%   │ [Y/N]     │
└─────────┴───────────┴─────────────┴──────────┴─────────┴───────────┘
```

### Statistical Details
- Z-score: [X]
- P-value: [X]
- Confidence level: [X]%
- 95% Confidence interval: [[X]%, [X]%]

### Secondary Metrics Results
- [Metric 1]: [Result]
- [Metric 2]: [Result]

### Segment Analysis
[Key findings from segment analysis]

**By device:**
- Desktop: [Results]
- Mobile: [Results]

**By traffic source:**
- Paid: [Results]
- Organic: [Results]

---

## Recommendation & Next Steps

### Decision
[Implement Variant B | Keep Control | Run Follow-up Test | Inconclusive]

### Rationale
[Why this decision? Consider statistical significance, practical significance, segment insights, and business context]

### Implementation Plan
[If implementing winner:]
- [ ] Task 1: [Description] - Owner: [Name] - Due: [Date]
- [ ] Task 2: [Description] - Owner: [Name] - Due: [Date]
- [ ] Task 3: [Description] - Owner: [Name] - Due: [Date]

### Learnings

**What worked:**
- [Key insight 1]
- [Key insight 2]

**What didn't work:**
- [Key insight 3]
- [Key insight 4]

**Surprises:**
- [Unexpected finding 1]
- [Unexpected finding 2]

### Future Test Ideas

**High priority:**
1. [Test idea spawned from this result]
2. [Test idea spawned from this result]

**Future exploration:**
1. [Longer-term test idea]
2. [Longer-term test idea]

---

## Notes & Updates

**[Date]:** [Status update or note]
**[Date]:** [Status update or note]
**[Date]:** [Status update or note]

---

## Attachments & Links

- Creative assets: [Link to folder]
- Design mocks: [Link]
- Analytics dashboard: [Link]
- Test in platform: [Link]
- Related tests: [Links to related test briefs]
- Research/data: [Links to supporting research]
