# Statistical Methods for Creative Testing

This document provides practical statistical methods, calculations, and interpretation guidance for creative A/B testing.

## Core Statistical Concepts

### Statistical Significance

**Definition:** The probability that your results are not due to random chance.

**Standard:** 95% confidence level (p-value < 0.05)
- Means: Less than 5% chance results are due to luck
- In other words: 95% confident the difference is real

**Higher confidence levels for critical tests:**
- 99% confidence (p < 0.01) for major changes
- 90% confidence (p < 0.10) acceptable for early-stage tests

---

### Sample Size

**Definition:** Number of observations needed to detect a meaningful difference.

**Depends on:**
1. Baseline conversion rate
2. Minimum detectable effect (MDE)
3. Desired statistical power (typically 80%)
4. Significance level (typically 95%)

**General rule:** Lower baseline rates or smaller expected lifts require larger samples.

---

### Statistical Power

**Definition:** Probability of detecting a true effect when it exists.

**Standard:** 80% power
- Means: 80% chance of detecting a real difference if it exists
- Balances sample size requirements with reliability
- Higher power (90%, 95%) requires larger samples

---

### Minimum Detectable Effect (MDE)

**Definition:** Smallest difference you want to be able to detect.

**Practical considerations:**
- Business significance: Is a 2% lift worth implementing?
- Statistical feasibility: Can you reach sample size in reasonable time?
- Industry benchmarks: What's typical in your vertical?

**Common MDEs:**
- 5-10% lift for established programs
- 15-25% lift for early testing/learning phase
- 20-50% lift for radical redesigns

---

## Sample Size Calculations

### For Conversion Rate Tests

**Formula:**
```
n = [Z(1-α/2) + Z(1-β)]² × [p₁(1-p₁) + p₂(1-p₂)] / (p₂ - p₁)²

Where:
- n = sample size per variant
- Z(1-α/2) = Z-score for significance level (1.96 for 95%)
- Z(1-β) = Z-score for power (0.84 for 80%)
- p₁ = baseline conversion rate (control)
- p₂ = expected conversion rate (variant)
```

**Simplified Calculation:**
```
n ≈ 16 × p × (1-p) / (MDE)²

Where:
- p = baseline conversion rate
- MDE = minimum detectable effect (as decimal)
```

**Example:**
```
Baseline: 5% conversion rate
MDE: 20% relative lift (5% → 6% = 1 percentage point)

n ≈ 16 × 0.05 × 0.95 / (0.01)²
n ≈ 16 × 0.0475 / 0.0001
n ≈ 7,600 visitors per variant
```

### Quick Reference Table

Sample sizes needed per variant at 95% confidence, 80% power:

**Baseline 1% Conversion Rate:**
```
MDE (relative) │ Sample Size per Variant
10%           │ ~152,000
20%           │ ~38,000
30%           │ ~17,000
50%           │ ~6,100
```

**Baseline 5% Conversion Rate:**
```
MDE (relative) │ Sample Size per Variant
10%           │ ~28,900
20%           │ ~7,300
30%           │ ~3,200
50%           │ ~1,150
```

**Baseline 10% Conversion Rate:**
```
MDE (relative) │ Sample Size per Variant
10%           │ ~13,800
20%           │ ~3,500
30%           │ ~1,550
50%           │ ~560
```

**Baseline 20% Conversion Rate:**
```
MDE (relative) │ Sample Size per Variant
10%           │ ~6,150
20%           │ ~1,550
30%           │ ~690
50%           │ ~250
```

---

### Test Duration Estimation

**Formula:**
```
Test Duration (days) = Sample Size Required × 2 / Daily Traffic
```

**Example:**
```
Sample needed: 7,600 per variant × 2 variants = 15,200 total
Daily traffic: 1,000 visitors
Duration: 15,200 / 1,000 = 15.2 days ≈ 16 days
```

**Minimum test duration:**
- At least 1 week (to capture weekly patterns)
- Ideally 2 weeks (to capture 2 full weeks)
- Never less than 1 business cycle for B2B

**Maximum test duration:**
- 4 weeks typically sufficient
- If not significant after 4 weeks, effect is likely too small to matter

---

## Significance Testing

### Z-Test for Proportions (Most Common)

**When to use:** Testing conversion rates, click-through rates, etc.

**Formula:**
```
Z = (p₂ - p₁) / SE

Where:
SE = √[p(1-p) × (1/n₁ + 1/n₂)]
p = pooled proportion = (x₁ + x₂) / (n₁ + n₂)
```

**Example Calculation:**
```
Control (A):
- Visitors: 10,000
- Conversions: 500
- Rate: 5.0%

Variant (B):
- Visitors: 10,000
- Conversions: 600
- Rate: 6.0%

Pooled proportion:
p = (500 + 600) / (10,000 + 10,000) = 1,100 / 20,000 = 0.055

Standard Error:
SE = √[0.055 × 0.945 × (1/10,000 + 1/10,000)]
SE = √[0.051975 × 0.0002]
SE = √0.0000104
SE = 0.00322

Z-score:
Z = (0.06 - 0.05) / 0.00322
Z = 0.01 / 0.00322
Z = 3.11

P-value (two-tailed): 0.0019

Result: Statistically significant (p < 0.05)
```

### Interpretation

**Z-score thresholds:**
- |Z| > 1.96 → Significant at 95% confidence (p < 0.05)
- |Z| > 2.58 → Significant at 99% confidence (p < 0.01)
- |Z| > 1.65 → Significant at 90% confidence (p < 0.10)

**P-value interpretation:**
- p < 0.05 → Significant (less than 5% chance of random)
- p < 0.01 → Highly significant (less than 1% chance)
- p > 0.05 → Not significant (could be random chance)

---

### Confidence Intervals

**Definition:** Range where the true value likely falls.

**Formula for 95% CI:**
```
CI = p ± 1.96 × √[p(1-p)/n]
```

**Example:**
```
Variant B: 600 conversions / 10,000 visitors = 6.0%

SE = √[0.06 × 0.94 / 10,000] = 0.00237

95% CI = 6.0% ± (1.96 × 0.237%)
95% CI = 6.0% ± 0.46%
95% CI = [5.54%, 6.46%]
```

**Interpretation:** We're 95% confident the true conversion rate for variant B is between 5.54% and 6.46%.

**Practical use:** If confidence intervals don't overlap, results are significant.

---

## Effect Size Calculations

### Relative Lift

**Formula:**
```
Relative Lift = (Variant Rate - Control Rate) / Control Rate × 100%
```

**Example:**
```
Control: 5.0%
Variant: 6.0%
Relative Lift = (6.0 - 5.0) / 5.0 × 100% = 20% lift
```

---

### Absolute Lift

**Formula:**
```
Absolute Lift = Variant Rate - Control Rate
```

**Example:**
```
Control: 5.0%
Variant: 6.0%
Absolute Lift = 6.0 - 5.0 = 1.0 percentage points
```

---

### Practical Significance

Statistical significance ≠ practical significance.

**Ask:**
1. Is the lift large enough to matter to the business?
2. Is the lift worth the implementation cost?
3. Does the lift justify potential risks?

**Example:**
```
Statistically significant: Yes (p = 0.001)
Lift: 0.5% absolute (2.5% → 3.0%)
Annual revenue impact: +$50,000
Implementation cost: $30,000
Time to implement: 2 months

Decision: Maybe not worth it (small ROI, high opportunity cost)
```

**Rule of thumb:** Minimum 5-10% relative lift usually needed for practical significance.

---

## Multiple Comparison Correction

**Problem:** When testing multiple variants, false positive risk increases.

**Example:**
- Testing 3 variants (A vs B vs C)
- Each comparison at 95% confidence
- Overall false positive risk: ~14% (not 5%)

### Bonferroni Correction

**Method:** Divide significance level by number of comparisons.

**Formula:**
```
Adjusted α = α / number of comparisons
```

**Example:**
```
Testing 3 variants (3 comparisons: A vs B, A vs C, B vs C)
Standard α = 0.05
Adjusted α = 0.05 / 3 = 0.0167

Use 98.3% confidence level instead of 95%
```

**Trade-off:** More conservative, requires larger samples.

---

### Sequential Testing (Peeking)

**Problem:** Checking results repeatedly increases false positive risk.

**Solution: Use adjusted significance thresholds**

**Always-Valid P-Value Method:**
```
Required p-value drops with each peek:
- 1st peek: p < 0.01
- 2nd peek: p < 0.01
- Final: p < 0.05
```

**Best practice:** Minimize peeking, use pre-planned checkpoints.

---

## Common Statistical Mistakes

### Mistake 1: Stopping Too Early

**Error:** Declaring winner before reaching sample size.

**Risk:** False positive (Type I error).

**Solution:** Wait for planned sample size OR use sequential testing methods.

**Example:**
```
Planned sample: 10,000 per variant
Current sample: 2,000 per variant
Current p-value: 0.03 (significant!)

Decision: Keep running - not yet at planned sample size
```

---

### Mistake 2: Running Too Long

**Error:** Extending test hoping for significance.

**Risk:** False positive from cherry-picking.

**Solution:** Set duration up front, stop when reached.

---

### Mistake 3: Testing Too Many Variants

**Error:** Running 10+ variants simultaneously.

**Risk:** Increased false positive risk, harder to reach significance.

**Solution:** Limit to 2-4 variants, use sequential testing for more.

---

### Mistake 4: Ignoring Segmentation Effects

**Error:** Looking only at overall results.

**Risk:** Missing important segment-specific insights.

**Solution:** Pre-plan key segments to analyze (but don't mine for significance).

---

### Mistake 5: Confusing Statistical and Practical Significance

**Error:** Implementing tiny lifts just because they're significant.

**Risk:** Wasted resources on negligible improvements.

**Solution:** Set minimum practical lift threshold (usually 5-10% relative).

---

## Bayesian Approach (Alternative Method)

**Philosophy:** Update beliefs based on evidence.

**Advantages:**
- Can incorporate prior knowledge
- Provides probability statements
- Allows continuous monitoring
- More intuitive for business stakeholders

**Disadvantages:**
- Requires prior specification
- More complex calculation
- Less standardized

**When to use:**
- Low traffic situations
- Want probability statements ("90% chance variant is better")
- Have strong prior information
- Continuous monitoring needed

**Interpretation:**
Instead of p-value, get probability statements:
- "95% probability variant B has higher conversion rate"
- "Expected lift: 12% (95% credible interval: 8-16%)"

**Tools:** Most A/B testing platforms (Optimizely, VWO) offer Bayesian analysis.

---

## Quick Decision Framework

**When results show:**

**p < 0.05 and lift > practical threshold:**
→ **Implement winner** ✓

**p < 0.05 but lift < practical threshold:**
→ **Don't implement** (not worth it)

**p > 0.05 but large lift observed:**
→ **Continue test** or **increase sample size**

**p > 0.05 and small/no lift:**
→ **No winner**, try different approach

**Unexpected negative results:**
→ **Investigate** - check for bugs, segment analysis

---

## Reporting Template

```markdown
## Test Results: [Test Name]

**Test Period:** [Start] - [End] ([X] days)
**Status:** ✓ Complete | ⚠ Incomplete | ✗ Invalid

### Hypothesis
[Original hypothesis statement]

### Results Summary

**Winner:** [Variant Name] | No winner
**Statistical Significance:** [Yes/No] (p = [X])
**Lift:** [X]% relative ([X] percentage points absolute)
**Confidence Level:** [95%/99%]

### Detailed Metrics

┌─────────┬───────────┬─────────────┬──────────┬───────────┐
│ Variant │ Visitors  │ Conversions │ CVR      │ Lift      │
├─────────┼───────────┼─────────────┼──────────┼───────────┤
│ A (Ctrl)│ 10,000    │ 500         │ 5.00%    │ Baseline  │
│ B (Test)│ 10,000    │ 600         │ 6.00%    │ +20.0%    │
└─────────┴───────────┴─────────────┴──────────┴───────────┘

**Statistical Analysis:**
- Z-score: [X]
- P-value: [X]
- 95% Confidence Interval: [[X]%, [X]%]

**Secondary Metrics:**
- [Metric 1]: [Result]
- [Metric 2]: [Result]

### Segment Analysis

**By Device:**
- Desktop: [Results]
- Mobile: [Results]

**By Traffic Source:**
- Paid: [Results]
- Organic: [Results]

### Recommendation

**Action:** [Implement B | Keep A | Run follow-up test | Inconclusive]

**Rationale:** [Why this decision based on data]

**Next Steps:**
1. [Action item 1]
2. [Action item 2]

### Learnings

**What worked:**
- [Learning 1]
- [Learning 2]

**What didn't work:**
- [Learning 3]

**Future test ideas:**
- [Hypothesis 1]
- [Hypothesis 2]
```

---

## Statistical Resources

**Online Calculators:**
- Evan Miller's A/B Test Calculator: https://www.evanmiller.org/ab-testing/
- Optimizely Sample Size Calculator: https://www.optimizely.com/sample-size-calculator/
- AB Test Guide Calculator: https://abtestguide.com/calc/

**Statistical Significance:**
- Use z-test for proportions (conversion rates)
- Use t-test for continuous metrics (revenue, time on site)
- Account for multiple comparisons when testing 3+ variants
- Always report confidence intervals, not just p-values
