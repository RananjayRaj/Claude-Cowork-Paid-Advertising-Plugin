# Hypothesis Framework

A well-structured hypothesis is the foundation of any effective creative test. This document provides frameworks for writing testable hypotheses with clear success criteria.

## Hypothesis Structure

A complete test hypothesis should include:

1. **Target audience/segment** - Who are we testing with?
2. **Independent variable** - What are we changing?
3. **Dependent variable** - What are we measuring?
4. **Expected direction** - Will it increase or decrease?
5. **Rationale** - Why do we believe this?

### Basic Formula

```
If we [CHANGE] for [AUDIENCE], then [METRIC] will [DIRECTION] because [RATIONALE].
```

### Enhanced Formula (with control)

```
We hypothesize that [VARIANT] will outperform [CONTROL] for [AUDIENCE] 
by [EXPECTED LIFT]% in [PRIMARY METRIC] because [RATIONALE].
```

## Examples by Creative Type

### Ad Creative Hypothesis

**Basic:**
"If we use lifestyle imagery instead of product shots for millennial women, then click-through rate will increase because lifestyle images create emotional connection and show product in use."

**Enhanced:**
"We hypothesize that lifestyle imagery will outperform product shots for millennial women (25-34) by 15-25% in click-through rate because our customer research shows this segment responds to aspirational, context-rich visuals that demonstrate lifestyle benefits over product features."

**Elements identified:**
- Audience: Millennial women (25-34)
- Independent variable: Image type (lifestyle vs product)
- Dependent variable: Click-through rate
- Expected direction: Increase by 15-25%
- Rationale: Customer research on segment preferences

---

### Landing Page Hypothesis

**Basic:**
"If we emphasize cost savings over feature benefits in the hero section for SMB owners, then conversion rate will increase because this segment is price-sensitive and ROI-focused."

**Enhanced:**
"We hypothesize that a cost-savings-focused hero section will outperform a feature-focused hero section for SMB owners by 10-20% in demo request rate because discovery interviews revealed that 73% of SMB buyers cite ROI as their primary decision factor, while only 34% mentioned specific features."

**Elements identified:**
- Audience: SMB owners
- Independent variable: Value proposition framing (cost savings vs features)
- Dependent variable: Demo request rate
- Expected direction: Increase by 10-20%
- Rationale: Discovery interview data

---

### Email Campaign Hypothesis

**Basic:**
"If we use urgency-driven subject lines instead of benefit-focused subject lines for inactive users, then open rate will increase because urgency creates FOMO and prompts immediate action."

**Enhanced:**
"We hypothesize that urgency-driven subject lines will outperform benefit-focused subject lines for users inactive >30 days by 8-15% in open rate because behavioral data shows this segment responds to re-engagement tactics with time-bound offers, with previous urgency campaigns showing 12% lift."

**Elements identified:**
- Audience: Users inactive >30 days
- Independent variable: Subject line type (urgency vs benefit)
- Dependent variable: Open rate
- Expected direction: Increase by 8-15%
- Rationale: Historical campaign data

---

### UI Element Hypothesis

**Basic:**
"If we change the CTA button from 'Learn More' to 'Get Started' on the pricing page, then conversion rate will increase because 'Get Started' implies immediate action and value."

**Enhanced:**
"We hypothesize that a 'Get Started' CTA will outperform 'Learn More' on the pricing page by 5-12% in trial signups because heatmap analysis shows users clicking 'Learn More' then returning to pricing 64% of the time, suggesting confusion about next steps, while 'Get Started' provides clear action-oriented direction."

**Elements identified:**
- Location: Pricing page
- Independent variable: CTA copy ('Get Started' vs 'Learn More')
- Dependent variable: Trial signup rate
- Expected direction: Increase by 5-12%
- Rationale: Heatmap and user journey analysis

---

## Common Hypothesis Mistakes

### Too Vague
❌ "Changing the image will improve performance."
✅ "If we use lifestyle imagery instead of product shots for millennial women, then CTR will increase by 15-25% because this segment responds to aspirational, context-rich visuals."

### Multiple Variables
❌ "If we change the headline, image, and CTA color, then conversion will increase."
✅ "If we change the headline from feature-focused to benefit-focused, then conversion will increase by 10% because customer surveys show 68% prioritize outcomes over features." (Test one variable at a time)

### No Measurable Outcome
❌ "Using video will create better engagement."
✅ "Using video instead of static images will increase video view rate by 30% and time on page by 45 seconds."

### Missing Rationale
❌ "We think red buttons will perform better than blue buttons."
✅ "We hypothesize red buttons will outperform blue buttons by 8-12% in CTR because red creates visual contrast against our blue brand palette and draws attention in our eye-tracking studies."

### Unrealistic Expectations
❌ "Changing the button color will increase conversion by 300%."
✅ "Changing the button color to improve contrast will increase conversion by 5-10%, based on industry benchmarks for accessibility improvements."

---

## Hypothesis Categories

### Problem-Solution Hypothesis
Testing solutions to identified problems.

**Structure:** "Because [PROBLEM] exists for [AUDIENCE], we hypothesize that [SOLUTION] will improve [METRIC] by [AMOUNT]."

**Example:** "Because cart abandonment is 72% for mobile users, we hypothesize that adding Apple Pay will reduce abandonment by 15-20% by removing friction at checkout."

---

### Audience-Insight Hypothesis
Testing based on audience research or segmentation.

**Structure:** "Because [AUDIENCE INSIGHT], we hypothesize that [VARIANT] will resonate better than [CONTROL] with [SEGMENT], improving [METRIC] by [AMOUNT]."

**Example:** "Because Gen Z users (18-24) prefer authentic, user-generated content over polished brand content (per social listening analysis), we hypothesize that UGC-style video ads will outperform studio-produced ads by 25-35% in engagement rate."

---

### Best Practice Hypothesis
Testing industry standards or proven patterns.

**Structure:** "Based on [INDUSTRY DATA/BEST PRACTICE], we hypothesize that implementing [CHANGE] will improve [METRIC] by [AMOUNT] for [AUDIENCE]."

**Example:** "Based on industry research showing that social proof increases conversion by an average of 15%, we hypothesize that adding customer testimonials to our pricing page will increase trial signups by 10-18% for enterprise prospects."

---

### Optimization Hypothesis
Iterating on existing elements.

**Structure:** "We hypothesize that optimizing [ELEMENT] by [SPECIFIC CHANGE] will improve [METRIC] by [AMOUNT] because [DATA-DRIVEN RATIONALE]."

**Example:** "We hypothesize that reducing our signup form from 8 fields to 4 fields will increase completion rate by 20-30% because analytics show 58% of users abandon at field 5, and industry benchmarks show each field reduces completion by 5-10%."

---

## Supporting Your Hypothesis

Strong hypotheses are backed by:

### Quantitative Data
- Analytics data (bounce rate, time on page, conversion funnel)
- Historical test results
- Industry benchmarks
- A/B test archives
- Customer behavior data

### Qualitative Insights
- User interviews
- Customer feedback
- Support ticket analysis
- User testing sessions
- Heatmaps and session recordings

### Competitive Analysis
- Competitor creative analysis
- Industry trend research
- Successful campaigns in your vertical
- Cross-industry inspiration with proven results

### Theoretical Frameworks
- Psychology principles (scarcity, social proof, reciprocity)
- Persuasion techniques
- UX best practices
- Accessibility standards
- Design principles

---

## Hypothesis Strength Assessment

Evaluate your hypothesis using these criteria:

**Strong Hypothesis Checklist:**
- [ ] Specific audience identified
- [ ] Single variable being tested
- [ ] Measurable outcome defined
- [ ] Expected direction stated
- [ ] Magnitude of change estimated
- [ ] Clear rationale provided
- [ ] Based on data or research
- [ ] Falsifiable (can be proven wrong)
- [ ] Realistic expectations

**Confidence Levels:**

**High Confidence (70-90% confident)**
- Backed by multiple data sources
- Aligned with past test results
- Supported by strong user research
- Industry best practices

**Medium Confidence (40-70% confident)**
- Backed by one data source
- Some supporting evidence
- Logical rationale but untested

**Low Confidence (10-40% confident)**
- Based on intuition or assumption
- Limited supporting evidence
- Exploratory test
- Learning-focused rather than optimization-focused

**Label your hypotheses with confidence levels** - this helps prioritize testing and sets appropriate expectations.

---

## Hypothesis Documentation Template

```markdown
## Test Hypothesis: [Descriptive Name]

**Hypothesis Statement:**
[If we change X for audience Y, then metric Z will increase/decrease by N% because rationale.]

**Test Type:** [A/B Test | Multivariate | Sequential]
**Confidence Level:** [High | Medium | Low]

**Independent Variable:**
- Control: [Current version]
- Variant(s): [New version(s)]

**Dependent Variable:**
- Primary Metric: [Main success metric]
- Secondary Metrics: [Supporting metrics]

**Target Audience/Segment:**
[Who is this test for?]

**Expected Impact:**
- Primary Metric: [X]% lift
- Secondary Metrics: [Any expected changes]

**Rationale:**
[Why do we believe this will work? Include data, research, or insights.]

**Supporting Evidence:**
- [Data point 1]
- [Data point 2]
- [Research finding 3]

**Success Criteria:**
- Minimum Detectable Effect: [X]%
- Statistical Significance: 95% confidence
- Sample Size Needed: [N] per variant
- Test Duration: [X] days/weeks

**Learning Objectives:**
[What will we learn from this test, regardless of outcome?]

**Risk Assessment:**
- Brand Risk: [Low | Medium | High]
- Technical Risk: [Low | Medium | High]
- Revenue Risk: [Low | Medium | High]
```

---

## Common Testing Scenarios and Hypothesis Templates

### Scenario 1: Testing New Creative Direction

**Template:**
"We hypothesize that [NEW CREATIVE APPROACH] will outperform [CURRENT APPROACH] for [TARGET AUDIENCE] by [X]% in [PRIMARY METRIC] because [AUDIENCE INSIGHT OR MARKET TREND]."

**Example:**
"We hypothesize that minimalist design will outperform feature-heavy design for SaaS buyers by 12-18% in demo request rate because our buyer interviews revealed that 81% of respondents find current B2B SaaS sites 'overwhelming' and prefer 'clean, simple' designs."

---

### Scenario 2: Testing Message Hierarchy

**Template:**
"We hypothesize that leading with [PRIMARY MESSAGE] instead of [SECONDARY MESSAGE] will improve [METRIC] by [X]% for [AUDIENCE] because [PRIORITY/MOTIVATION INSIGHT]."

**Example:**
"We hypothesize that leading with security messaging instead of feature messaging will improve enterprise conversion by 15-22% because RFP analysis shows 94% of enterprise buyers list 'security and compliance' as a requirement, while features vary by use case."

---

### Scenario 3: Testing Audience Segmentation

**Template:**
"We hypothesize that [SEGMENT-SPECIFIC VARIANT] will outperform [GENERIC CONTROL] for [SPECIFIC SEGMENT] by [X]% in [METRIC] because [SEGMENT CHARACTERISTIC OR BEHAVIOR]."

**Example:**
"We hypothesize that healthcare-specific landing pages will outperform our generic landing page for healthcare prospects by 25-35% in form completion rate because industry research shows that 73% of healthcare buyers require industry-specific solutions and compliance messaging."

---

### Scenario 4: Testing Conversion Funnel Optimization

**Template:**
"We hypothesize that [FRICTION REDUCTION] at [FUNNEL STAGE] will improve [METRIC] by [X]% because [ANALYTICS INSIGHT OR USER FEEDBACK]."

**Example:**
"We hypothesize that removing the 'Company Size' field from the signup form will increase completion rate by 18-25% because analytics show 43% of users abandon at this field, and post-signup surveys indicate confusion about why company size is required for a free trial."
