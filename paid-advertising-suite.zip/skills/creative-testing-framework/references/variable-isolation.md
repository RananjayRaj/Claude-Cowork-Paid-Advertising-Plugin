# Variable Isolation

Proper variable isolation ensures you know exactly what caused performance changes. This document provides techniques for isolating variables and avoiding confounding factors.

## The Golden Rule of A/B Testing

**Test one variable at a time** (unless doing intentional multivariate testing).

**Why:** If you change multiple things, you can't know which change caused the result.

**Bad Example:**
```
Control: Product image + "Learn More" button + Long copy
Variant: Lifestyle image + "Get Started" button + Short copy
```
If variant wins, what caused it? The image? The button? The copy? Unknown.

**Good Example:**
```
Control: Product image + "Learn More" button + Long copy
Variant: Lifestyle image + "Learn More" button + Long copy
```
If variant wins, you know it's the image type.

---

## What Counts as a Variable?

### Single Variables (Good for A/B testing)

**Visual Elements:**
- Image type (product vs lifestyle)
- Image style (photo vs illustration)
- Video vs static image
- Color scheme
- Layout/whitespace

**Copy Elements:**
- Headline copy
- Body copy length
- Tone (formal vs casual)
- Value proposition framing

**Interactive Elements:**
- CTA button text
- CTA button color
- Form length
- Navigation structure

### Compound Variables (Requires multivariate)

**Examples of what counts as multiple variables:**
- Image + Headline (2 variables)
- CTA text + CTA color (2 variables)
- Headline + Body copy + CTA (3 variables)
- Layout + Color scheme + Copy (3 variables)

---

## Common Isolation Mistakes

### Mistake 1: Changing Copy and Design Together

❌ **Bad:**
```
Control: 
- Headline: "Save Time with Automation"
- Layout: Simple grid
- Image: Product screenshot

Variant:
- Headline: "Automate Your Workflow"
- Layout: Card-based
- Image: Lifestyle photo
```

✅ **Good - Isolate one variable:**
```
Test 1 - Image:
Control: Product screenshot + same headline + same layout
Variant: Lifestyle photo + same headline + same layout

Test 2 - Layout (after Test 1):
Control: Winner from Test 1 + same headline + simple grid
Variant: Winner from Test 1 + same headline + card-based

Test 3 - Headline (after Test 2):
Control: Winner from Test 2 + "Save Time with Automation"
Variant: Winner from Test 2 + "Automate Your Workflow"
```

---

### Mistake 2: Unintentional Variable Changes

❌ **Bad:**
```
Control: Existing page (optimized for desktop, loads in 2s)
Variant: New design (not yet optimized, loads in 5s)
```

**Problem:** Testing design AND page speed simultaneously.

✅ **Good:**
```
Control: Existing page (optimized, 2s load)
Variant: New design (also optimized, 2s load)
```

**Ensure variants are equivalent on all technical factors:**
- Page load speed
- Mobile responsiveness
- Browser compatibility
- Tracking implementation

---

### Mistake 3: Implicit Variables from Context

❌ **Bad:**
```
Control: "Buy Now" button in product screenshot context
Variant: "Buy Now" button in lifestyle image context
```

**Problem:** Button is the same, but *context* around it changed.

✅ **Options:**

**Option A - Test button with same context:**
```
Control: "Buy Now" + product screenshot
Variant: "Get Started" + product screenshot
```

**Option B - Test context with same button:**
```
Control: Product screenshot + "Buy Now"
Variant: Lifestyle image + "Buy Now"
```

---

### Mistake 4: Size/Prominence Changes

❌ **Bad:**
```
Control: Small blue button "Learn More"
Variant: Large red button "Get Started"
```

**Problem:** Changed color, size, AND copy (3 variables).

✅ **Good - Isolate one:**
```
Test 1 - Copy:
Control: Small blue "Learn More"
Variant: Small blue "Get Started"

Test 2 - Color:
Control: Small blue [winner from Test 1]
Variant: Small red [winner from Test 1]

Test 3 - Size:
Control: Small [winner color] [winner copy]
Variant: Large [winner color] [winner copy]
```

---

## Variable Isolation Techniques

### Technique 1: Sequential Testing

**Method:** Test one variable at a time, in sequence.

**Process:**
1. Test Variable A → Find winner
2. Test Variable B on winner from step 1 → Find winner
3. Test Variable C on winner from step 2 → Find winner

**Advantages:**
- Clear causation
- Simpler analysis
- Lower traffic requirements

**Disadvantages:**
- Takes longer (serial, not parallel)
- Might miss interaction effects
- Cumulative changes could affect later tests

**Best for:** Low-traffic sites, learning-focused programs.

**Example:**
```
Week 1-2: Test headlines (A vs B)
Winner: Headline B

Week 3-4: Test images with Headline B (Product vs Lifestyle)
Winner: Lifestyle + Headline B

Week 5-6: Test CTAs with Headline B + Lifestyle (Learn More vs Get Started)
Winner: Get Started + Headline B + Lifestyle
```

---

### Technique 2: Multivariate Testing (MVT)

**Method:** Test multiple variables simultaneously, all combinations.

**Process:**
1. Identify N variables
2. Create all possible combinations
3. Test all combinations against each other

**Combinations formula:** If you have n variables with v variations each:
```
Total combinations = v₁ × v₂ × v₃ × ... × vₙ
```

**Example - 2 variables, 2 variations each:**
```
Variable 1 (Image): Product vs Lifestyle
Variable 2 (CTA): Learn More vs Get Started

Combinations:
A: Product + Learn More
B: Product + Get Started
C: Lifestyle + Learn More
D: Lifestyle + Get Started
```

**Advantages:**
- Test multiple variables simultaneously
- Discover interaction effects
- Faster than sequential (parallel testing)

**Disadvantages:**
- Requires much more traffic
- More complex analysis
- Dilutes traffic across many variants

**Traffic requirement:**
```
2×2 MVT: 4× the traffic of standard A/B test
3×2 MVT: 6× the traffic
3×3 MVT: 9× the traffic
```

**Best for:** High-traffic sites (>100k visitors/month), mature optimization programs.

---

### Technique 3: Fractional Factorial Design

**Method:** Test subset of combinations to reduce traffic needs.

**When to use:** Want multivariate insights but don't have traffic for full MVT.

**Example - Testing 3 variables with 2 levels each:**
```
Full factorial: 2³ = 8 combinations
Fractional: 4 combinations (half-fraction)

Selected combinations:
A: Variable1-A + Variable2-A + Variable3-A
B: Variable1-A + Variable2-B + Variable3-B
C: Variable1-B + Variable2-A + Variable3-B
D: Variable1-B + Variable2-B + Variable3-A
```

**Advantage:** 50% fewer combinations = 50% less traffic needed.

**Disadvantage:** Can't detect all interaction effects.

**Best for:** Moderate traffic sites wanting to test multiple variables.

---

## Controlling for External Variables

External factors that can confound results:

### Time-Based Factors

**Day of week:**
```
Problem: Starting test on Monday, variant A gets Mon-Wed, variant B gets Thu-Sun
Solution: Randomize by user, not by time period
```

**Seasonality:**
```
Problem: Testing Nov-Dec (holiday season) vs Jan-Feb (New Year goals)
Solution: Run tests for complete weeks, avoid holiday periods for baseline tests
```

**Time of day:**
```
Problem: Variant A shown in morning, variant B shown in evening
Solution: Randomize throughout the day, run for full 24-hour cycles
```

---

### Traffic Source Factors

**Paid vs Organic:**
```
Problem: Variant A gets paid traffic, variant B gets organic
Solution: Ensure random split across all traffic sources
```

**Geographic distribution:**
```
Problem: Variant A shown to US traffic, variant B to international
Solution: Maintain same geographic distribution for all variants
```

**Device type:**
```
Problem: Variant A gets more mobile traffic than variant B
Solution: Check traffic splits by device, ensure balanced distribution
```

---

### User State Factors

**New vs returning:**
```
Problem: Variant A shown only to new users
Solution: Randomize across both new and returning users
```

**Logged in vs logged out:**
```
Problem: Different experiences for different user states
Solution: Ensure random assignment within each user state
```

---

## Isolation Checklist

Before launching any test, verify:

**Single Variable Confirmation:**
- [ ] Only one element is different between control and variant
- [ ] All other page elements are identical
- [ ] Technical implementation is equivalent (load time, etc.)
- [ ] Both variants render correctly on all devices/browsers

**Context Consistency:**
- [ ] Same traffic sources go to both variants
- [ ] Same time periods represented in both variants
- [ ] Same user segments in both variants
- [ ] No external factors affecting one variant more than the other

**Measurement Consistency:**
- [ ] Same tracking on all variants
- [ ] Same conversion events defined
- [ ] Same attribution window
- [ ] Same exclusion rules applied

**Documentation:**
- [ ] Variable being tested clearly documented
- [ ] All elements kept constant documented
- [ ] Any known confounds documented

---

## When Multiple Variables Are Acceptable

### Intentional Multivariate Testing

**Acceptable when:**
- Have sufficient traffic (>100k visitors/month)
- Want to test combinations specifically
- Looking for interaction effects
- Have proper MVT analysis plan

---

### Radical Redesigns

**Acceptable when:**
- Testing completely different concepts
- Goal is to learn which direction, not which element
- Plan follow-up isolation tests on winner

**Example:**
```
Control: Current experience (feature-focused, technical)
Variant: Radical redesign (benefit-focused, emotional)

If variant wins → Run isolation tests to identify key drivers
If control wins → Iterate with smaller tests on current design
```

---

### Package Testing

**Acceptable when:**
- Testing pre-defined user experience packages
- Variables are intentionally bundled
- Want to validate entire package vs. piecemeal

**Example:**
```
Control: Standard onboarding (3 steps, detailed)
Variant: Streamlined onboarding package (1 step, minimal)

Package includes: fewer fields + different copy + simplified design
Goal: Validate if "streamlined" philosophy works before optimizing pieces
```

---

## Isolation in Different Contexts

### Ad Creative Testing

**Isolate:**
- Image/video
- Headline
- Body copy
- CTA

**Keep constant:**
- Audience targeting
- Placement
- Landing page
- Ad format
- Budget/bidding strategy

**Watch out for:**
- Learning phase (first few days might be unstable)
- Audience overlap between ad sets
- Frequency differences

---

### Landing Page Testing

**Isolate:**
- Hero image
- Headline
- Value proposition
- CTA placement
- Form length
- Social proof type

**Keep constant:**
- Traffic source
- Load speed
- Mobile responsiveness
- Navigation
- Footer
- Any page elements not being tested

**Watch out for:**
- Scroll depth differences
- Mobile vs desktop differences
- Traffic quality changes

---

### Email Testing

**Isolate:**
- Subject line
- Preview text
- Email layout
- CTA
- Send time (if testing this specifically)

**Keep constant:**
- Sender name
- Send date (if not variable)
- Audience segment
- From email address

**Watch out for:**
- Send time if not controlled
- Deliverability differences
- List fatigue

---

## Advanced: Understanding Interaction Effects

**Interaction effect:** When the impact of one variable depends on another variable's level.

**Example:**
```
Headline A + Image 1: 5% conversion
Headline A + Image 2: 6% conversion  (+1 point)
Headline B + Image 1: 6% conversion  (+1 point)
Headline B + Image 2: 9% conversion  (+4 points)
```

**Interpretation:** Headline B works especially well with Image 2 (interaction effect).

**Additive prediction:** 5% + 1 + 1 = 7%
**Actual result:** 9%
**Interaction effect:** +2 percentage points

**Why this matters:**
- Sequential testing would find both improvements separately (+1 each)
- MVT finds the combination effect (+4 total)
- Sequential approach would miss the synergy

**Decision framework:**
- If no interaction expected: Sequential testing (simpler, less traffic)
- If interaction likely: MVT (captures synergy, needs more traffic)

---

## Troubleshooting Variable Isolation Issues

### "We tested X but Y also changed"

**Audit process:**
1. Document every difference between variants
2. Categorize as intentional or unintentional
3. Assess impact of each unintentional difference
4. Decide: Re-run test cleanly OR qualify results

---

### "Results vary by segment"

**Not always a problem:**
- Segment analysis is valuable
- Different segments can respond differently

**Problem when:**
- One variant got disproportionate segment distribution
- Solution: Check randomization, may need to re-run

---

### "We changed multiple things for good reason"

**Valid reasons:**
- Technical dependencies (can't change A without changing B)
- Design coherence (changing one element requires others to match)
- Radical concept test (intentionally different)

**How to handle:**
- Document what changed and why
- Interpret results as package test
- Plan follow-up isolation tests on winner
- Be clear in reporting: "We tested approach X vs approach Y" not "We tested element A"
