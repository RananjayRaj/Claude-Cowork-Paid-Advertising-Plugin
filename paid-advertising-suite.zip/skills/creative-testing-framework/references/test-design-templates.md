# Test Design Templates

This document provides templates and frameworks for designing rigorous creative A/B tests across different channels and creative types.

## Test Matrix Fundamentals

A test matrix organizes variants systematically to ensure proper variable isolation and comparison.

### Basic 2x1 Test Matrix (Standard A/B Test)

The simplest form: one variable, two versions.

```
┌─────────────┬──────────────┬──────────────┐
│ Variant     │ Variable     │ Expected     │
├─────────────┼──────────────┼──────────────┤
│ A (Control) │ Current      │ Baseline     │
│ B (Test)    │ New version  │ +X% lift     │
└─────────────┴──────────────┴──────────────┘
```

**When to use:** Single variable tests, comparing new vs. current, simple optimizations.

**Example - Ad Image Test:**
```
┌─────────┬────────────────┬──────────┬──────────────┐
│ Variant │ Image Type     │ Audience │ Expected CTR │
├─────────┼────────────────┼──────────┼──────────────┤
│ A       │ Product shot   │ All      │ 2.1% (base)  │
│ B       │ Lifestyle shot │ All      │ 2.7% (+28%)  │
└─────────┴────────────────┴──────────┴──────────────┘
```

---

### 3x1 Test Matrix (A/B/C Test)

One variable, three versions (control + 2 variants).

```
┌─────────────┬──────────────┬──────────────┐
│ Variant     │ Variable     │ Expected     │
├─────────────┼──────────────┼──────────────┤
│ A (Control) │ Current      │ Baseline     │
│ B (Test 1)  │ Version 1    │ +X% lift     │
│ C (Test 2)  │ Version 2    │ +Y% lift     │
└─────────────┴──────────────┴──────────────┘
```

**When to use:** Testing multiple approaches to same variable, identifying best performer from several options.

**Example - Headline Variations:**
```
┌─────────┬────────────────────────────────┬──────────────┐
│ Variant │ Headline                       │ Expected CVR │
├─────────┼────────────────────────────────┼──────────────┤
│ A       │ "Save Time with Automation"    │ 3.2% (base)  │
│ B       │ "Save 10 Hours Per Week"       │ 3.8% (+19%)  │
│ C       │ "Automate Your Workflow Today" │ 3.6% (+13%)  │
└─────────┴────────────────────────────────┴──────────────┘
```

---

### 2x2 Test Matrix (Multivariate - 2 Variables)

Two variables, two levels each = 4 combinations.

```
┌──────────┬────────────┬────────────┐
│          │ Variable 2A│ Variable 2B│
├──────────┼────────────┼────────────┤
│Variable 1A│ A1+A2     │ A1+B2      │
│Variable 1B│ B1+A2     │ B1+B2      │
└──────────┴────────────┴────────────┘
```

**When to use:** Testing interaction effects, optimizing multiple elements simultaneously, finding best combination.

**Example - Image + Headline Combinations:**
```
┌──────────────┬──────────────────┬──────────────────┐
│              │ Headline: Save   │ Headline: Hours  │
├──────────────┼──────────────────┼──────────────────┤
│ Image:       │ Variant A        │ Variant B        │
│ Product      │ Product + Save   │ Product + Hours  │
│              │ Expected: 2.8%   │ Expected: 3.1%   │
├──────────────┼──────────────────┼──────────────────┤
│ Image:       │ Variant C        │ Variant D        │
│ Lifestyle    │ Lifestyle + Save │ Lifestyle + Hours│
│              │ Expected: 3.2%   │ Expected: 3.7%   │
└──────────────┴──────────────────┴──────────────────┘
```

**Analysis approach:**
- Main effect of image: Compare top row vs. bottom row
- Main effect of headline: Compare left column vs. right column
- Interaction effect: Does the best headline depend on which image is used?

---

### 3x2 Test Matrix (Multivariate - Unequal Variables)

Three levels of one variable, two levels of another = 6 combinations.

```
┌──────────┬────────────┬────────────┐
│          │ Variable 2A│ Variable 2B│
├──────────┼────────────┼────────────┤
│Variable 1A│ A1+A2     │ A1+B2      │
│Variable 1B│ B1+A2     │ B1+B2      │
│Variable 1C│ C1+A2     │ C1+B2      │
└──────────┴────────────┴────────────┘
```

**When to use:** One variable has more variation options than another, testing multiple creative approaches with different CTAs.

**Example - Creative Style + CTA:**
```
┌────────────┬──────────────┬──────────────┐
│            │ CTA: Try Free│ CTA: Get Demo│
├────────────┼──────────────┼──────────────┤
│Style: Bold │ Bold + Free  │ Bold + Demo  │
│            │ Exp: 3.2%    │ Exp: 2.9%    │
├────────────┼──────────────┼──────────────┤
│Style: Mini │ Mini + Free  │ Mini + Demo  │
│            │ Exp: 3.5%    │ Exp: 3.1%    │
├────────────┼──────────────┼──────────────┤
│Style: Photo│ Photo + Free │ Photo + Demo │
│            │ Exp: 3.8%    │ Exp: 3.4%    │
└────────────┴──────────────┴──────────────┘
```

---

## Test Design by Channel

### Facebook/Instagram Ad Tests

**Standard Test Structure:**
```markdown
## Test: [Test Name]

**Campaign:** [Campaign name]
**Platform:** Facebook/Instagram
**Objective:** [Conversions | Traffic | Engagement]
**Budget:** $[X] per variant
**Duration:** [X days]

**Audience:**
- Target: [Demographics, interests, behaviors]
- Exclusions: [Any exclusions]
- Audience size: [X - Y] people

**Placement:**
- Feed | Stories | Reels | Explore
- [Any placement exclusions]

**Test Matrix:**
┌─────────┬──────────┬──────────┬──────────┬──────────────┐
│ Variant │ Image    │ Headline │ Body     │ Expected CTR │
├─────────┼──────────┼──────────┼──────────┼──────────────┤
│ A       │ Product  │ Current  │ Current  │ 2.1% (base)  │
│ B       │ Lifestyle│ Current  │ Current  │ 2.7% (+28%)  │
└─────────┴──────────┴──────────┴──────────┴──────────────┘

**Variables:**
- Independent: [Image type]
- Dependent: CTR, CPC, CPM, Conversion Rate, CPA

**Success Criteria:**
- Primary: CTR increase of >15%
- Secondary: CPA decrease or neutral (within 10%)
```

---

### Google Ads (Search) Tests

**Standard Test Structure:**
```markdown
## Test: [Test Name]

**Campaign:** [Campaign name]
**Ad Group:** [Ad group name]
**Keywords:** [Keyword list or theme]
**Match Type:** [Exact | Phrase | Broad]
**Budget:** $[X] per day

**Test Matrix:**
┌─────────┬────────────────┬────────────────┬──────────────┐
│ Variant │ Headline 1     │ Headline 2     │ Expected CTR │
├─────────┼────────────────┼────────────────┼──────────────┤
│ A       │ [Current H1]   │ [Current H2]   │ 4.2% (base)  │
│ B       │ [Variant H1]   │ [Current H2]   │ 5.1% (+21%)  │
└─────────┴────────────────┴────────────────┴──────────────┘

**Ad Copy:**
- Headline 1: [30 chars max]
- Headline 2: [30 chars max]
- Headline 3: [30 chars max]
- Description 1: [90 chars max]
- Description 2: [90 chars max]
- Display URL Path: [15 chars each]

**Variables:**
- Independent: [Headline 1 copy]
- Dependent: CTR, CPC, Quality Score, Conversion Rate, CPA
```

---

### Landing Page Tests

**Standard Test Structure:**
```markdown
## Test: [Test Name]

**Page:** [URL or page name]
**Traffic Source:** [Paid ads | Organic | Email | Social]
**Traffic Volume:** [X visitors per day]
**Duration:** [X days needed for significance]

**Test Matrix:**
┌─────────┬────────────┬──────────────┬──────────────┐
│ Variant │ Hero Copy  │ CTA Button   │ Expected CVR │
├─────────┼────────────┼──────────────┼──────────────┤
│ A       │ Feature    │ Learn More   │ 12.3% (base) │
│ B       │ Benefit    │ Get Started  │ 14.8% (+20%) │
└─────────┴────────────┴──────────────┴──────────────┘

**Page Elements:**
- Hero: [Image/video, headline, subhead, CTA]
- Value Props: [3-4 key benefits]
- Social Proof: [Testimonials, logos, stats]
- Features: [Product features section]
- CTA: [Primary and secondary CTAs]
- Footer: [Links, contact info]

**Variables:**
- Independent: [Specific element(s) being tested]
- Dependent: Conversion rate, bounce rate, time on page, scroll depth

**User Segments to Analyze:**
- New vs. returning visitors
- Mobile vs. desktop
- Traffic source (paid vs. organic)
```

---

### Email Campaign Tests

**Standard Test Structure:**
```markdown
## Test: [Test Name]

**Campaign:** [Campaign name]
**Segment:** [Audience segment]
**List Size:** [X subscribers]
**Send Date:** [Date and time]

**Test Matrix:**
┌─────────┬─────────────────┬──────────────┬──────────────┐
│ Variant │ Subject Line    │ Expected OR  │ Expected CTR │
├─────────┼─────────────────┼──────────────┼──────────────┤
│ A       │ [Current]       │ 22% (base)   │ 3.1% (base)  │
│ B       │ [Variant]       │ 26% (+18%)   │ 3.5% (+13%)  │
└─────────┴─────────────────┴──────────────┴──────────────┘

**Email Elements:**
- Subject Line: [50-60 chars]
- Preview Text: [85-100 chars]
- From Name: [Sender name]
- Header Image: [Yes/No, description]
- Body Copy: [Main message]
- CTA: [Button text and placement]

**Variables:**
- Independent: [Subject line format]
- Dependent: Open rate, click rate, conversion rate, unsubscribe rate

**Sample Size per Variant:** [X subscribers]
```

---

## Sequential Testing Strategy

When you have multiple hypotheses to test, sequence them strategically.

### Priority Matrix

Prioritize tests using Impact × Confidence:

```
High Impact, High Confidence → Test First (Quick wins)
High Impact, Low Confidence → Test Second (High risk/reward)
Low Impact, High Confidence → Test Third (Safe optimizations)
Low Impact, Low Confidence → Test Last (or skip)
```

### Sequential Test Plan Template

```markdown
## Q[X] Testing Roadmap: [Channel/Product]

### Test 1: [High Impact, High Confidence]
**Timeline:** Week 1-2
**Variable:** [X]
**Expected Lift:** [Y]%
**Confidence:** 80%
**Rationale:** [Strong data backing]

### Test 2: [High Impact, High Confidence]
**Timeline:** Week 3-4
**Variable:** [X]
**Expected Lift:** [Y]%
**Confidence:** 75%
**Rationale:** [User research backing]

### Test 3: [High Impact, Medium Confidence]
**Timeline:** Week 5-6
**Variable:** [X]
**Expected Lift:** [Y]%
**Confidence:** 50%
**Rationale:** [Logical hypothesis, untested]

### Learning Goals by End of Quarter:
- [Key insight 1]
- [Key insight 2]
- [Key insight 3]
```

---

## Holdout Group Strategy

For ongoing optimization programs, maintain a holdout group.

**Structure:**
- 90% of traffic: Receives optimized experience (winners from tests)
- 10% of traffic: Receives original control experience

**Purpose:**
- Measure cumulative impact of all optimizations
- Prevent optimization tunnel vision
- Quantify total program value

**Example:**
```
┌─────────────────┬─────────────┬──────────────┐
│ Group           │ % Traffic   │ Experience   │
├─────────────────┼─────────────┼──────────────┤
│ Optimized       │ 90%         │ All winners  │
│ Holdout Control │ 10%         │ Original     │
└─────────────────┴─────────────┴──────────────┘

Measure: Performance difference between groups = Total program lift
```

---

## Test Design Checklist

Before launching any test, verify:

**Hypothesis & Goals:**
- [ ] Clear hypothesis documented
- [ ] Primary metric defined
- [ ] Secondary metrics identified
- [ ] Success criteria established
- [ ] Expected lift estimated

**Test Structure:**
- [ ] Single variable isolated (unless multivariate)
- [ ] Control variant clearly defined
- [ ] All variants properly labeled
- [ ] Test matrix documented

**Technical Setup:**
- [ ] Proper randomization confirmed
- [ ] Traffic split configured correctly
- [ ] Tracking pixels/events verified
- [ ] Test runs on all required devices/browsers
- [ ] QA completed on all variants

**Statistical Planning:**
- [ ] Sample size calculated
- [ ] Test duration estimated
- [ ] Significance level set (typically 95%)
- [ ] Minimum detectable effect determined

**Audience & Scope:**
- [ ] Target audience defined
- [ ] Traffic source(s) identified
- [ ] Any exclusions documented
- [ ] Geographic targeting set

**Documentation:**
- [ ] Test brief created
- [ ] Stakeholders informed
- [ ] Success criteria shared
- [ ] Launch date scheduled
- [ ] Analysis plan prepared

---

## Common Test Design Patterns

### Pattern 1: Progressive Disclosure Testing

Test complexity levels to find the right balance.

**Example: Landing Page Information Hierarchy**
```
Variant A: Minimal (headline + CTA only)
Variant B: Balanced (headline + 3 bullets + CTA)
Variant C: Detailed (headline + paragraphs + features + CTA)
```

**Goal:** Find optimal information density for your audience.

---

### Pattern 2: Message Hierarchy Testing

Test which message element resonates most.

**Example: Hero Section Testing**
```
Variant A: Lead with Problem (pain point first)
Variant B: Lead with Solution (benefit first)
Variant C: Lead with Social Proof (results/testimonials first)
```

**Goal:** Determine most compelling entry point.

---

### Pattern 3: Visual Hierarchy Testing

Test how layout affects attention and action.

**Example: CTA Placement**
```
Variant A: CTA Above Fold (immediate)
Variant B: CTA After Value Props (informed)
Variant C: Multiple CTAs (throughout)
```

**Goal:** Optimize placement for conversions.

---

### Pattern 4: Segmented Testing

Different variants for different audience segments.

**Example: Industry-Specific Landing Pages**
```
Segment: Healthcare → Healthcare-specific value props & imagery
Segment: Finance → Finance-specific value props & imagery
Segment: Retail → Retail-specific value props & imagery
```

**Goal:** Prove segment-specific messaging outperforms generic.

---

## Multivariate Test Decision Framework

**Choose Multivariate When:**
- You have sufficient traffic (>100k visitors/month)
- Variables likely interact with each other
- You need to find optimal combination quickly
- You want to test experience holistically

**Choose Sequential A/B Tests When:**
- Traffic is limited (<100k visitors/month)
- Variables are independent
- You want to isolate individual impact
- You prefer simpler analysis

**Traffic Rule of Thumb:**
- A/B test (2 variants): Need ~1,000 conversions per variant
- A/B/C test (3 variants): Need ~1,500 conversions per variant
- 2x2 multivariate (4 combos): Need ~2,000 conversions per combination
- 3x2 multivariate (6 combos): Need ~3,000 conversions per combination
